#define PUFFERLIB_BUILD_MAIN
#include "retro.h"
#include <unistd.h>
static void check(bool ok,const char* why){if(!ok)throw std::runtime_error(why);}
static std::vector<char> bytes(Nes_Emu* emu){Nes_State s;emu->save_state(&s);Mem_Writer w;retro_check(s.write(w));return {w.data(),w.data()+w.size()};}
int main(){try{
    Dict cfg={};dict_set_str(&cfg,"spawn_levels","all");dict_set(&cfg,"frameskip",4);
    dict_set(&cfg,"archive_enabled",1);dict_set(&cfg,"archive_start",1);dict_set(&cfg,"archive_end",.1);
    dict_set(&cfg,"archive_capacity_mb",1);dict_set(&cfg,"archive_capture_interval",64);
    Env e={};puf_init(&e,&cfg);float obs[OBS_SIZE],action=0,reward=0,done=0;
    e.agents[0]={obs,&action,&reward,&done,nullptr,0};e.spawn_pin=1;e.cur_spawn=0;e.archive->lane=0;
    puf_reset(&e);auto& bank=retro_archive_bank();bank.budget=1000;
    // Reach a playable, rendered state without RAM modification.
    for(int i=0;i<10;i++)puf_step(&e);
    check(retro_playable_area_state(e.emu->low_mem()),"fixture must be playable");
    e.rewarded_levels=1;e.pipe_phase=3; // Reward ledger only; never edit ROM RAM.
    retro_archive_capture(&e);check(bank.cells.size()==1,"capture failed");
    auto held=bank.cells[0].state;auto original=bytes(e.emu);std::vector<float> expected(obs,obs+OBS_SIZE);
    puf_reset(&e);check(e.archive->mode==2&&bytes(e.emu)==original,"restore changed exact ROM state");
    // Episode age/frontier observations intentionally restart, like ordinary resets.
    expected[49]=0;expected[63]=robs_c01(e.x_pos/3200.0f);
    check(!memcmp(obs,expected.data(),OBS_SIZE*sizeof(float)),"restore changed reset observation");
    check(e.rewarded_levels==1&&e.pipe_phase==3,"reward ledger lost");
    check(!memcmp(e.frontiers,held->ledger.frontiers,sizeof(e.frontiers)),"frontier ledger lost");
    check(retro_track_progress(&e)==0&&retro_record_area_transition(&e,e.emu->low_mem())==0,"restore repaid novelty");
    std::string path="/tmp/retro_archive_test_"+std::to_string(getpid())+".gz";
    retro_archive_file(path.c_str(),true,.75);bank.cells.clear();bank.index.clear();
    retro_archive_file(path.c_str(),false);check(bank.cells.size()==1&&bank.resumed_phase==.75,"archive roundtrip lost schedule/cells");
    puf_reset(&e);check(bytes(e.emu)==original,"serialized core state differs");
    // Same controls after restore produce identical core bytes and observations.
    for(int i=0;i<16;i++){action=retro_mask_action(RETRO_BTN_RIGHT|RETRO_BTN_B);puf_step(&e);}
    auto future=bytes(e.emu);std::vector<float> future_obs(obs,obs+OBS_SIZE);
    puf_reset(&e);for(int i=0;i<16;i++)puf_step(&e);
    check(bytes(e.emu)==future&&!memcmp(obs,future_obs.data(),OBS_SIZE*sizeof(float)),"restored rollout diverged");
    auto fingerprint=retro_rom().fingerprint;retro_rom().fingerprint^=1;bool rejected=false;
    try{retro_archive_file(path.c_str(),false);}catch(...){rejected=true;}retro_rom().fingerprint=fingerprint;
    check(rejected,"mismatched ROM archive accepted");
    {FILE* f=fopen(path.c_str(),"wb");fputs("broken",f);fclose(f);}rejected=false;
    try{retro_archive_file(path.c_str(),false);}catch(...){rejected=true;}check(rejected,"corrupt archive accepted");unlink(path.c_str());
    // End phase assigns all nonarchive lanes to full games from 1-1.
    bank.steps=1000;e.archive->lane=.5;e.cur_spawn=20;puf_reset(&e);
    check(e.archive->mode==1&&e.episode_spawn==0&&e.world==1&&e.stage==1,"full-game anneal endpoint wrong");
    bank.steps=0;bank.resumed_phase=0;e.archive->start=.4;e.archive->lane=.95;e.cur_spawn=20;puf_reset(&e);
    check(e.archive->mode==0&&e.episode_spawn==20,"initial level-start lane wrong");
    // Keep an active snapshot alive through bounded-bank eviction/replacement.
    bank.capacity=1;e.archive->lane=0;puf_reset(&e);auto active=e.archive->state;
    for(int i=0;i<200;i++){action=retro_mask_action(RETRO_BTN_RIGHT|RETRO_BTN_B|((i%48>=10)?RETRO_BTN_A:0));puf_step(&e);}
    check(bank.cells.size()<=1&&active&&active->start.world==1,"archive eviction invalidated active state");
    check(bank.mode_steps[2]>0,"archive decision accounting missing");
    // A natural terminal still exposes terminal=1 after automatic restore.
    e.max_frames=e.tick+1;puf_step(&e);check(done==1&&e.tick==0,"archive reset hid terminal boundary");
    puf_close(&e);dict_clear(&cfg);puts("PASS: archive exact state/image, deterministic continuation, reward ledger, persistence/corruption, mixture, eviction lifetime, terminal boundary");return 0;
}catch(const std::exception& e){fprintf(stderr,"FAIL: %s\n",e.what());return 1;}}
