"""PufferLib Kaggriculture submission: native MinGRU policy, NumPy runtime.

This is a direct adapter for the 488-byte observation and five masked action
heads used by the native C trainer. The accompanying checkpoint contains only
our trained PufferLib policy weights.
"""

import os
import sys

import numpy as np


ITEMS = (
    "WHEAT", "CARROT", "TOMATO", "STRAWBERRY", "MELON",
    "EGG", "MILK", "WOOL", "FERTILIZER", "GOOSE", "COW", "SHEEP",
)
CROPS = ITEMS[:5]
PRODUCTS = ITEMS[:9]
ANIMALS = ITEMS[9:]
ITEM_ID = {name: i for i, name in enumerate(ITEMS)}
CROP_ID = {name: i for i, name in enumerate(CROPS)}
ANIMAL_ID = {name: i for i, name in enumerate(ANIMALS)}
SHOP_ID = {name: i for i, name in enumerate((
    "BAKERY", "PIZZA_SHOP", "BRUNCH_SPOT", "YARN_STORE",
    "ICE_CREAM_SHOP", "PET_CAFE", "SMOOTHIE_SHOP", "FARMERS_MARKET",
))}
QUADRANT_BITS = {"NW": 1, "NE": 2, "SW": 4, "SE": 8}
SEED_COST = (10, 20, 50, 100, 80)
ANIMAL_COST = (300, 400, 500)
FIRST_YIELD_DAY = (2, 2, 8, 10, 10)
ANIMAL_STRUCTURE = ("COOP", "PASTURE", "PASTURE")

OBS_SIZE = 488
HIDDEN_SIZE = 32
NUM_LAYERS = 2
HEAD_SIZES = (44, 44, 44, 44, 76)
HEAD_OFFSETS = (0, 44, 88, 132, 176, 252)
CASH_RESERVE = 500
MAX_HANDS = 240
ALL = 0x7FFFFFFF


def _get(obj, key, default=None):
    if obj is None:
        return default
    try:
        return obj.get(key, default)
    except AttributeError:
        return getattr(obj, key, default)


def _u8(value):
    return max(0, min(255, int(value)))


def _u8_scale(value, scale):
    value = int(value)
    if value <= 0:
        return 0
    if value >= scale:
        return 255
    return (value * 255) // scale


def _u8_signed(value, magnitude):
    value = int(value)
    if value <= -magnitude:
        return 0
    if value >= magnitude:
        return 255
    return ((value + magnitude) * 255) // (2 * magnitude)


def _unlocked_mask(farm):
    mask = 0
    for name in _get(farm, "unlocked_quadrants", ()):
        mask |= QUADRANT_BITS.get(name, 0)
    return mask


def _tile_entity(tile):
    if tile is None:
        return 0
    if tile == "LOCKED":
        return 1
    kind = _get(tile, "kind", "")
    if kind == "WEED":
        return 2
    if kind == "PLANT":
        return 5 + CROP_ID.get(_get(tile, "crop", ""), 0)
    if kind in ("COOP", "PASTURE"):
        animal = _get(tile, "animal")
        if animal in ANIMAL_ID:
            return 10 + ANIMAL_ID[animal]
        return 3 if kind == "COOP" else 4
    return 0


def _occupied_animal(tile):
    return (_get(tile, "kind") in ("COOP", "PASTURE")
            and _get(tile, "animal") in ANIMAL_ID)


def _positions(farm):
    return [list(_get(farm, "farmer", (4, 4)))] + [
        list(pos) for pos in _get(farm, "hands", ())
    ]


def _inventory(private, unit_id):
    inventories = _get(private, "inventories", ())
    return inventories[unit_id] if unit_id < len(inventories) else {}


def encode_observation(obs):
    player = int(_get(obs, "player", 0))
    farms = _get(obs, "farms", ())
    me = farms[player]
    opponent = farms[1 - player]
    private = _get(obs, "private", {})
    day = int(_get(obs, "day", 0))
    hour = int(_get(obs, "hour", 0))
    step = int(_get(obs, "step", day * 24 + hour))
    me_money = int(_get(me, "money", 0))
    opp_money = int(_get(opponent, "money", 0))
    own_positions = _positions(me)
    opp_positions = _positions(opponent)
    out = np.zeros(OBS_SIZE, dtype=np.uint8)
    k = 0

    global_features = (
        _u8_scale(me_money, 20000),
        _u8_scale(opp_money, 20000),
        _u8_signed(me_money - opp_money, 20000),
        _u8_scale(step, 720),
        _u8(day), _u8(hour),
        _unlocked_mask(me), _unlocked_mask(opponent),
        _u8(_get(me, "hires_today", 0)),
        _u8(_get(opponent, "hires_today", 0)),
        _u8(len(own_positions)), _u8(len(opp_positions)),
        sum(1 << SHOP_ID[name] for name in _get(_get(obs, "town", {}),
            "unlocked_shops", ()) if name in SHOP_ID),
    )
    out[k:k + 13] = global_features
    k += 13

    for row in _get(me, "tiles", ()):
        for tile in row:
            entity = _tile_entity(tile)
            kind = _get(tile, "kind", "")
            if kind == "PLANT":
                age = day - int(_get(tile, "planted_day", day))
            elif _occupied_animal(tile):
                age = day - int(_get(tile, "placed_day", day))
            else:
                age = 0
            packed = min(15, max(0, int(_get(tile, "yield_units", 0))))
            packed |= int(bool(_get(tile, "watered_today", False))) << 4
            packed |= int(bool(_get(tile, "fed_today", False))) << 5
            packed |= int(bool(_get(tile, "cared_today", False))) << 6
            packed |= int(bool(_get(tile, "fertilizer_available", False))) << 7
            out[k:k + 3] = (entity, _u8(age), packed)
            k += 3

    for row in _get(opponent, "tiles", ()):
        for tile in row:
            out[k] = ((_tile_entity(tile) << 4)
                      | min(15, max(0, int(_get(tile, "yield_units", 0)))))
            k += 1

    shed = _get(private, "shed", {})
    for name in ITEMS:
        out[k] = _u8(_get(shed, name, 0))
        k += 1
    seeds = _get(private, "seeds", {})
    for name in CROPS:
        out[k] = _u8(_get(seeds, name, 0))
        k += 1

    for view in range(4):
        unit_ids = [0] if view == 0 else list(range(view, len(own_positions), 3))
        if unit_ids:
            present = 0
            wheat = 0
            fertilizer = 0
            for unit_id in unit_ids:
                inv = _inventory(private, unit_id)
                for item_id, name in enumerate(ITEMS):
                    count = int(_get(inv, name, 0))
                    if count:
                        present |= 1 << item_id
                    if name == "WHEAT":
                        wheat += count
                    elif name == "FERTILIZER":
                        fertilizer += count
            out[k:k + 7] = (
                _u8(len(unit_ids)),
                sum(own_positions[i][0] for i in unit_ids) // len(unit_ids),
                sum(own_positions[i][1] for i in unit_ids) // len(unit_ids),
                present & 255, present >> 8, _u8(wheat), _u8(fertilizer),
            )
        k += 7

    for view in range(4):
        unit_ids = [0] if view == 0 else list(range(view, len(opp_positions), 3))
        if unit_ids:
            out[k:k + 3] = (
                _u8(len(unit_ids)),
                sum(opp_positions[i][0] for i in unit_ids) // len(unit_ids),
                sum(opp_positions[i][1] for i in unit_ids) // len(unit_ids),
            )
        k += 3

    market = _get(obs, "market", {})
    inventory = _get(market, "inventory", {})
    prices = _get(market, "prices", {})
    for name in PRODUCTS:
        out[k] = _u8_signed(_get(inventory, name, 0), 10000)
        k += 1
    for name in PRODUCTS:
        out[k] = _u8_scale(_get(prices, name, 0), 1000)
        k += 1
    if k != OBS_SIZE:
        raise RuntimeError("Kaggriculture observation ABI mismatch")
    return out


def _shed_adjacent(x, y):
    return (x, y) in ((4, 4), (5, 4), (4, 5), (5, 5))


def _can_move(farm, x, y):
    if not (0 <= x < 10 and 0 <= y < 10):
        return False
    return _get(farm, "tiles", ())[y][x] != "LOCKED"


def _unit_mask(obs, unit_id):
    player = int(_get(obs, "player", 0))
    farm = _get(obs, "farms", ())[player]
    private = _get(obs, "private", {})
    positions = _positions(farm)
    mask = np.zeros(44, dtype=bool)
    mask[0] = True
    if unit_id >= len(positions):
        return mask
    x, y = positions[unit_id]
    tile = _get(farm, "tiles", ())[y][x]
    for action, (dx, dy) in enumerate(((0, -1), (0, 1), (1, 0), (-1, 0)), 1):
        mask[action] = _can_move(farm, x + dx, y + dy)

    adjacent = _shed_adjacent(x, y)
    shed = _get(private, "shed", {})
    inv = _inventory(private, unit_id)
    if adjacent:
        for item_id, name in enumerate(ITEMS):
            mask[5 + item_id] = int(_get(shed, name, 0)) > 0
        mask[17] = any(int(_get(inv, name, 0)) > 0 for name in ITEMS)
    if tile == "LOCKED":
        return mask

    kind = _get(tile, "kind", "")
    if tile is None:
        seeds = _get(private, "seeds", {})
        for crop_id, name in enumerate(CROPS):
            mask[18 + crop_id] = int(_get(seeds, name, 0)) > 0
        mask[26] = True  # BUILD_COOP
        mask[27] = True  # BUILD_PASTURE
    elif kind == "PLANT":
        mask[23] = not bool(_get(tile, "watered_today", False))
        crop = CROP_ID.get(_get(tile, "crop", ""), -1)
        if crop >= 0:
            age = int(_get(obs, "day", 0)) - int(_get(tile, "planted_day", 0))
            mask[24] = (int(_get(tile, "yield_units", 0)) > 0
                        and age >= FIRST_YIELD_DAY[crop])
        mask[25] = int(_get(inv, "FERTILIZER", 0)) > 0
    elif _occupied_animal(tile):
        mask[24] = int(_get(tile, "yield_units", 0)) > 0
        mask[29] = (not bool(_get(tile, "fed_today", False))
                    and int(_get(inv, "WHEAT", 0)) > 0)
        mask[30] = bool(_get(tile, "fertilizer_available", False))
        mask[31] = not bool(_get(tile, "cared_today", False))
    if tile is not None and tile != "LOCKED":
        mask[28] = True  # DIG

    shed_total = sum(int(_get(shed, name, 0)) for name in ITEMS)
    shed_room = adjacent and shed_total < 100
    for item_id, name in enumerate(ITEMS):
        carried = int(_get(inv, name, 0)) > 0
        if item_id >= 9:
            animal_id = item_id - 9
            legal = (carried and kind == ANIMAL_STRUCTURE[animal_id]
                     and _get(tile, "animal") is None)
        else:
            legal = carried and shed_room
        mask[32 + item_id] = legal
    return mask


def _fib(n):
    a, b = 1, 1
    for _ in range(int(n)):
        a, b = b, a + b
    return a


def _market_spec(action_id):
    quantities = (1, 4, 16, -1)
    if action_id == 0:
        return None, None, 1
    if action_id < 21:
        index = action_id - 1
        return "BUY_SEED", index // 4, quantities[index % 4]
    if action_id < 29:
        index = action_id - 21
        return "BUY_PRODUCT", (0, 8)[index // 4], quantities[index % 4]
    if action_id < 38:
        index = action_id - 29
        return "BUY_ANIMAL", 9 + index // 3, (1, 4, 16)[index % 3]
    if action_id < 74:
        index = action_id - 38
        return "SELL", index // 4, quantities[index % 4]
    if action_id == 74:
        return "HIRE", None, 1
    return "BUY_LAND", None, 1


def action_mask(obs):
    player = int(_get(obs, "player", 0))
    farm = _get(obs, "farms", ())[player]
    private = _get(obs, "private", {})
    hands = _get(farm, "hands", ())
    mask = np.zeros(252, dtype=bool)
    mask[0:44] = _unit_mask(obs, 0)
    for cohort in range(3):
        cohort_mask = np.zeros(44, dtype=bool)
        cohort_mask[0] = True
        for hand in range(cohort, len(hands), 3):
            cohort_mask |= _unit_mask(obs, hand + 1)
        mask[44 * (cohort + 1):44 * (cohort + 2)] = cohort_mask

    money = int(_get(farm, "money", 0))
    shed = _get(private, "shed", {})
    prices = _get(_get(obs, "market", {}), "prices", {})
    market_mask = mask[176:]
    for action_id in range(76):
        op, item_id, quantity = _market_spec(action_id)
        legal = False
        if op is None:
            legal = True
        elif quantity == -1 and op != "SELL":
            legal = False
        elif op == "BUY_SEED":
            legal = money - SEED_COST[item_id] * quantity >= CASH_RESERVE
        elif op == "BUY_PRODUCT":
            legal = money - int(_get(prices, ITEMS[item_id], 0)) * quantity >= CASH_RESERVE
        elif op == "BUY_ANIMAL":
            legal = money - ANIMAL_COST[item_id - 9] * quantity >= CASH_RESERVE
        elif op == "SELL":
            legal = int(_get(shed, ITEMS[item_id], 0)) > 0
        elif op == "HIRE":
            legal = (len(hands) < MAX_HANDS
                     and money - _fib(_get(farm, "hires_today", 0)) >= CASH_RESERVE)
        elif op == "BUY_LAND":
            extra = len(_get(farm, "unlocked_quadrants", ())) - 1
            legal = 0 <= extra < 3 and money - (1000, 2000, 4000)[extra] >= CASH_RESERVE
        market_mask[action_id] = legal
    return mask


def _unit_action(action_id):
    if action_id == 0:
        return ["PASS"]
    if action_id < 5:
        return [("NORTH", "SOUTH", "EAST", "WEST")[action_id - 1]]
    if action_id < 17:
        return ["PICKUP", ITEMS[action_id - 5], ALL]
    if action_id == 17:
        return ["DROP"]
    if action_id < 23:
        return ["PLANT", CROPS[action_id - 18]]
    if action_id < 32:
        return [["WATER"], ["HARVEST"], ["FERTILIZE"], ["BUILD_COOP"],
                ["BUILD_PASTURE"], ["DIG"], ["FEED"],
                ["COLLECT_FERTILIZER"], ["CARE"]][action_id - 23]
    return ["PLACE", ITEMS[action_id - 32], ALL]


def decode_actions(obs, actions):
    player = int(_get(obs, "player", 0))
    hands = _get(_get(obs, "farms", ())[player], "hands", ())
    result = {
        "farmer": _unit_action(int(actions[0])),
        "hands": [_unit_action(int(actions[1 + hand % 3]))
                  for hand in range(len(hands))],
        "market": [],
    }
    op, item_id, quantity = _market_spec(int(actions[4]))
    if op == "BUY_SEED":
        result["market"] = [[op, CROPS[item_id], quantity]]
    elif op in ("BUY_PRODUCT", "BUY_ANIMAL", "SELL"):
        if quantity == -1:
            quantity = int(_get(_get(obs, "private", {}), "shed", {}).get(
                ITEMS[item_id], 0))
        result["market"] = [[op, ITEMS[item_id], quantity]]
    elif op is not None:
        result["market"] = [[op]]
    return result


class NativeMinGRU:
    def __init__(self, path):
        flat = np.fromfile(path, dtype=np.float32)
        if flat.size != 29856:
            raise RuntimeError("Unexpected PufferLib checkpoint shape")
        index = 0
        count = HIDDEN_SIZE * OBS_SIZE
        self.encoder = flat[index:index + count].reshape(HIDDEN_SIZE, OBS_SIZE)
        index += count
        count = 253 * HIDDEN_SIZE
        self.decoder = flat[index:index + count].reshape(253, HIDDEN_SIZE)
        index += count
        self.layers = []
        for _ in range(NUM_LAYERS):
            count = 3 * HIDDEN_SIZE * HIDDEN_SIZE
            self.layers.append(flat[index:index + count].reshape(3 * HIDDEN_SIZE,
                                                                  HIDDEN_SIZE))
            index += count
        self.state = np.zeros((NUM_LAYERS, HIDDEN_SIZE), dtype=np.float32)

    @staticmethod
    def _sigmoid(value):
        return 1.0 / (1.0 + np.exp(-np.clip(value, -80.0, 80.0)))

    def reset(self):
        self.state.fill(0)

    def forward(self, obs):
        x = self.encoder @ obs.astype(np.float32)
        for layer_id, weights in enumerate(self.layers):
            combined = weights @ x
            hidden = combined[:HIDDEN_SIZE]
            gate = self._sigmoid(combined[HIDDEN_SIZE:2 * HIDDEN_SIZE])
            candidate = np.empty_like(hidden)
            positive = hidden >= 0
            candidate[positive] = hidden[positive] + 0.5
            candidate[~positive] = self._sigmoid(hidden[~positive])
            state = self.state[layer_id]
            next_state = state + gate * (candidate - state)
            highway = self._sigmoid(combined[2 * HIDDEN_SIZE:])
            x = highway * next_state + (1.0 - highway) * x
            self.state[layer_id] = next_state
        return self.decoder @ x


_CODE_DIR = os.path.dirname(os.path.abspath(sys._getframe().f_code.co_filename))
_MODEL_CANDIDATES = (
    os.path.join(_CODE_DIR, "champion_658m.bin"),
    "/kaggle_simulations/agent/champion_658m.bin",
    os.path.abspath("champion_658m.bin"),
    os.path.abspath(os.path.join(
        "saved", "kaggriculture_hall_of_fame", "champion_658m.bin")),
)
_MODEL_PATH = next((path for path in _MODEL_CANDIDATES if os.path.isfile(path)),
                   _MODEL_CANDIDATES[0])
_MODEL = NativeMinGRU(_MODEL_PATH)
_RNG = np.random.default_rng(73)


def _sample_heads(logits, mask):
    actions = np.zeros(5, dtype=np.int32)
    for head in range(5):
        start, end = HEAD_OFFSETS[head], HEAD_OFFSETS[head + 1]
        legal = np.flatnonzero(mask[start:end])
        values = logits[start:end][legal]
        values = values - np.max(values)
        probabilities = np.exp(values)
        probabilities /= np.sum(probabilities)
        actions[head] = legal[_RNG.choice(legal.size, p=probabilities)]
    return actions


def agent(obs):
    global _RNG
    day = int(_get(obs, "day", 0))
    hour = int(_get(obs, "hour", 0))
    if day == 0 and hour == 0:
        _MODEL.reset()
        _RNG = np.random.default_rng(73 + int(_get(obs, "player", 0)))
    encoded = encode_observation(obs)
    mask = action_mask(obs)
    logits = _MODEL.forward(encoded)[:252]
    return decode_actions(obs, _sample_heads(logits, mask))
