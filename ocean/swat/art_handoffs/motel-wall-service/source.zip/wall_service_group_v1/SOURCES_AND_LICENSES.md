# Sources and licenses

Both exact downloaded handoff archives are preserved in `sources/`. The source grants are CC0-1.0: https://creativecommons.org/publicdomain/zero/1.0/legalcode . Archive license/provenance statements are source claims, not independent legal certification.

1. Exterior hose bib reuse packet: https://drive.google.com/file/d/1JC-h2o-U8DHxAVfmQMO0L2O4OmLPqKMe/view
   Original existing catalog design `env:03_yard_utility/yu03_wall_garden_spigot`, from https://drive.google.com/file/d/1wqsqKXp7vJSA76bE3Wc7y86_yDGtoszW/view . Its unmodified catalog GLB, .blend and scripts are inside the preserved packet. This assembly uses the already-delivered `runtime/wall_garden_spigot_reuse.glb` byte-for-byte, including the existing material consolidation. It creates no further variant.
2. Wall hose hanger packet: https://drive.google.com/file/d/1EJ_mhV-VmwfEjsL6vwaeK1J3yyUG-FhW/view
   Uses the packet's existing `runtime/wall_hose_hanger_LOD1.glb` byte-for-byte. Original LOD0 and LOD1 editable sources, scripts, maps and licenses are preserved inside that exact archive.

Copied source license/provenance summaries are in `records/`; their unchanged originals are also in the source archives. Exact archive hashes and every import hash are recorded in `qa/identity_and_geometry.json`; package file hashes are in `SHA256SUMS.txt`.

New placement data, review construction code and reports in this grouping package are dedicated to CC0-1.0. No extra third-party art or new design asset has been added. Neutral render illumination is review-only.
