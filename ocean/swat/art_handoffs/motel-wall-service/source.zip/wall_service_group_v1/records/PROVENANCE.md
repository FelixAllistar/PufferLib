# Provenance

Source catalog design: `env:03_yard_utility/yu03_wall_garden_spigot`.
Official original archive: https://drive.google.com/file/d/1wqsqKXp7vJSA76bE3Wc7y86_yDGtoszW/view?usp=drivesdk
Name: yard-utility-batch-03.zip; 21,417,817 bytes. Recovered through the connected Google Drive raw-file download on 2026-10-09.
Original runtime member: `03_yard_utility/assets/wall_garden_spigot.glb`.
Original source member: `03_yard_utility/yard_utility.blend`.
Original runtime SHA-256: `0aa13d6c10959d30cf9730977c5a8d7bfbfb8723584c1ebab1f1c1b0740ab260`, matching the catalog.

Original batch LICENSE.txt and manifest.json identify the geometry, generated textures and scripts as original procedural CC0-1.0 artwork without third-party models or textures. Those original records are included unchanged. License: https://creativecommons.org/publicdomain/zero/1.0/legalcode

This handoff reuses that existing CC0 design and supplies a separately named UV/material consolidation plus inspection scripts and QA. No new unique design should be added to the catalog for this variant. The new preparation scripts and reports are also dedicated to CC0-1.0. The original author/license claims are preserved from the archive; they are not independent legal certification.

All included original files are verified against the downloaded ZIP's member bytes. `qa/provenance.json` records the archive and source hashes and the verification result. No files were uploaded or posted during this preparation.
