# Provenance

Created 2026-10-08 for Felix's continued near-realism roadside/maintenance art request.

- Original procedural mesh geometry authored in `source/build_asset.py`; no imported asset mesh.
- Original deterministic texture pixels authored in `source/make_textures.py`, RNG seed 8147. No downloaded texture, photo, logo, font or source image.
- Preview renders generated from the actual exported and reimported GLB. Neutral wall, camera and lights exist only for review.
- Catalog read for duplication avoidance: `catalog_r009_recent_delivery_draft/catalog.json`. Existing reel-cart and spigot entries informed gap selection only; their art was not copied.
- Established local Blender export/helper patterns informed workflow. All files written for this candidate are confined to its new directory, plus its final sibling archive.
- License for all new package work: explicit CC0-1.0 dedication in `LICENSE.txt`.
- No external upload, public publication, engine edit or placement was performed by this worker.
