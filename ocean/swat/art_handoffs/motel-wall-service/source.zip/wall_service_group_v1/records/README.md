# Exterior hose bib: reuse handoff

Decision: REUSE `yu03_wall_garden_spigot`. This is the existing catalog design, not a new unique asset. The original already supplies a compact brass hose bib, a red shutoff-style wheel, a visible steel wall flange, four mounting bolts, and nozzle thread rings.

The original is preserved byte-for-byte. The separately named runtime variant changes only material/UV organization: four source materials become one opaque PBR material with embedded 512 × 512 base-color and ORM images. Geometry, dimensions, pivot, flat normals, and visual design are retained. This is one 512px PBR texture set (two images), not one image total. The atlas resamples the existing texture artwork; it is not an exact pixel-preserving texture copy.

## Files
- `runtime/wall_garden_spigot_reuse.glb`: optional single-material delivery variant
- `source/wall_garden_spigot_reuse.blend`: editable standalone source with original semantic vertex groups
- `source/prepare_reuse.py`: deterministic preparation from the included original source
- `original/03_yard_utility/assets/wall_garden_spigot.glb`: unmodified catalog export
- `original/03_yard_utility/yard_utility.blend`: unmodified original editable batch source
- `original/03_yard_utility/build_yard_utility.py`: unmodified procedural batch generator
- `qa/runtime_audit.json`: independent raw binary QA and original-versus-variant geometry equality
- `qa/anchors.json`: measured wall/nozzle centers and source-derived pipe/wheel references
- `preview/full.png`, `close.png`, `front.png`, `rear.png`: fresh renders of the actual exported/reimported variant

## Verified runtime
1,408 triangles, one mesh primitive, one opaque material. Dimensions X/Y/Z are 0.144 × 0.188093 × 0.228500 metres. GLB is Y-up, front +Z, metres, identity node transform. Rear flange lies on wall plane Z=0. The placement origin is the lower wall-contact-plane centre, not the flange centre. Author the mounting height later using the supplied wall anchor. Source Blender coordinates are Z-up and front -Y.

Wall flange centre is approximately (0, 0.105165, 0) m. Nozzle visual centre is approximately (0, 0.000165, 0.204) m, directed -Y. These are art-reference anchors only. They are not exported gameplay nodes or functional plumbing claims.

Geometry triangle positions match the original GLB at 0.1 micrometre comparison precision. Finite accessors, valid indices, zero zero-area triangles, normalized normals, identity transforms, opaque material, texture dimensions and bounds have been checked. A fresh Blender GLB reimport is rendered for QA. No normal map is used; tangent data is not required or exported.

## Limits
The deliberately low-poly wheel/flange silhouette is visible in close views. The nozzle end is capped art geometry; this reuse pass does not redesign it as working/open plumbing. Atlas filtering can alter fine texture sampling. No collision, LOD, animations, valve operation, water effects, engine placement, gameplay, motion, grip or ground changes are included. Appearance is a review candidate, not user art acceptance.

## Reproduce
Run from this directory's parent with Blender 4.3.2:
`blender -b -t 2 --python-exit-code 1 --python exterior_hose_bib_reuse_v1/source/prepare_reuse.py`
Then run `python exterior_hose_bib_reuse_v1/source/audit_reuse.py` and render using `source/render_glb.py` with Blender.

The original batch source remains untouched. Its original generator rebuilds the wider batch, whereas `prepare_reuse.py` extracts just this source object and performs the material consolidation.
