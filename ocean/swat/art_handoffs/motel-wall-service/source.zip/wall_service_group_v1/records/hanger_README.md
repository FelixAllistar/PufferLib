# Wall-mounted maintenance hose hanger v1

Original static near-realism roadside/motel maintenance dressing candidate. A compact powder-coated steel hanger, wall fasteners, one continuous coiled green 20 mm garden hose and two brass couplers. Intended for a service-wall recess or planted service edge. This is a separate art/source package. No existing ground, perimeter, corridor, delivered prop, placement code or engine configuration was changed.

## Gap and status

The inspected r009 catalog includes `yu03_garden_hose_reel_cart` and `yu03_wall_garden_spigot`, but no compact wall-mounted coiled-hose hanger. This adds that distinct wall dressing option rather than another floor cart, caddy, sprayer or sign. Candidate art review only; not placed, approved by the user, or certified in the native engine.

## Runtime

- `runtime/wall_hose_hanger.glb`: 8,380 triangles, one render mesh, one opaque PBR material/primitive; approximately 1.03 MB.
- Three embedded original 512 x 512 PNG textures: base color, roughness/metallic (ORM file, red remains white), tangent normal.
- Metres, glTF Y-up. Identity `ASSET_ROOT`; wall-contact plane local Z=0; front projects toward local +Z.
- Measured dimensions: 0.44358249 m width × 0.64206181 m height × 0.205 m projection.
- Bounds: min (-0.23858525, -0.53706181, 0); max (0.20499724, 0.104999997, 0.205).
- Root is mounting-plate centre, not the bottom of the hose. Two screw anchors are 0.154 m apart vertically.
- `WALL_CONTACT`: (0,0,0). `MOUNT_UPPER`: (0,0.077,0). `MOUNT_LOWER`: (0,-0.077,0). `SADDLE_CONTACT`: (0,0.060,0.100). All values here are glTF coordinates.

The hose has a continuous 4.75-turn path, separate free leads and small gaps between wraps. The tube is a solid render surface; coupling bores are dark visual recesses, not through-holes. Eight-sided smooth-shaded tube and simplified crimp/coupling detail suit a modest static environment prop. No deforming hose, fluid simulation, destruction or runtime interactions are supplied. Native material appearance depends on engine lighting and texture interpretation.

## Optional collision, kept separate

`runtime/OPTIONAL_coarse_solid_proxy.glb` is a single closed convex 12-triangle box at the same origin. It is deliberately conservative and fills the central hose opening. It is NOT hollow-precision collision. It is not registered or enabled anywhere. Prefer render-only for ordinary dressing; engine owners must opt in, and must not use the box for precision projectile, hand, line-of-sight or hollow-space tests. Do not let this optional envelope alter clear corridors or supported traversal. No collision is built into the render GLB.

## Source and reproduction

`source/wall_hose_hanger.blend` keeps the named editable components and packed images. Source uses Blender Z-up with the wall at Y=0 and front toward -Y. Runtime is generated with Blender's Y-up conversion.

Tested toolchain: Blender 4.3.2; Python 3 with numpy and Pillow for deterministic texture generation. From the package directory:

    python source/make_textures.py
    blender -b --python source/build_asset.py
    blender -b --python source/build_proxy.py
    python source/audit_glb.py
    blender -b --python source/audit_source.py

The build recreates the editable Blender file, the runtime GLB, reimports that actual GLB and renders four previews. Scripts resolve paths relative to this package; no remote downloads, repository or engine dependencies. Construction is reproducible; byte identity across Blender versions, timestamps and render hardware is not promised. Do not run concurrent rebuilds into the same folder.

## QA and visual review

`qa/runtime_audit.json` records actual exported bounds, index checks, finite values, identity root, embedded textures, anchors and runtime primitive count. `qa/geometry.json` records export/reimport geometry; zero degenerate faces and zero nonmanifold edges after a 1 µm geometric weld. Raw imported UV/normal seams intentionally split vertices and are not holes. Separate closed parts overlap at manufactured joints. No broad mesh self-intersection certification or native engine tests were run.

`preview/full.png`, `front.png`, `mount_close.png` and `coupling_close.png` show the actual reimported final runtime GLB under neutral offline lighting. The wall and lights are preview-only. An initial outgoing-tail tangent kink was corrected before final review; texture and silhouette checks include full and close views. Final review details are in `qa/visual_review.md`.

Engine owners retain responsibility for art acceptance, mounting to a suitable wall, final transforms, corridor clearance, LOD/culling, physics, support, collision policy and native tests. Existing delivered ground stays pinned.

## Rights

All geometry, textures, scripts and previews in this folder are newly authored original work. No downloaded third-party art, logos, photos, asset geometry or fonts are incorporated. See `LICENSE.txt` for the explicit CC0-1.0 grant and `PROVENANCE.md` for the record.

## Separate LOD1 follow-up

`runtime/wall_hose_hanger_LOD1.glb` is a separate 2,896-triangle option (65.4% fewer triangles), with editable `source/wall_hose_hanger_LOD1.blend` and reproducible `source/build_lod1.py`. LOD0's GLB, Blender source and construction script were preserved byte-for-byte; the pin check is in `qa/lod0_pinned_hashes.json` and `qa/lod_comparison.json`.

LOD1 retains every hose wrap and both free leads, the wall plate, saddle, retaining lip, ribs, fasteners and coupler silhouettes. It reduces hose samples and tube cross-section and omits tiny crimp rings and hardware bevels. This is a distant/small-screen-size mesh, with deliberately more visible faceting in close views. It is not a replacement for LOD0 close-ups. Bounds differ by less than 0.21 mm per dimension. Material definitions, embedded texture bytes, origin and all four mounting/contact anchors are identical. One primitive/material remains.

To rebuild LOD1 without touching LOD0:

    blender -b --python source/build_lod1.py
    python source/audit_lod1_glb.py
    blender -b --python source/audit_lod1_source.py

`python source/compare_lods.py` verifies the current delivered pair and original LOD0 file pins. Source .blend timestamp bytes may change after a deliberate full source rebuild, so original-release hash pins are not a cross-version regeneration guarantee. No LOD-switch component or engine distance threshold is installed; the engine team should choose a screen-size transition after testing. Actual reimported LOD1 review images are under `preview/lod1/`.

## Bright exterior material caution

The runtime material is opaque and non-emissive. The original basecolor's mean linear luminance is approximately 0.065 for the hose and 0.138 for the powder coating, with neither near white. `qa/material_response.json` records the texture measurements and exported material. Materials were left unchanged rather than blindly darkened in response to a report of strong exterior exposure on other perimeter/gravel assets. Neutral studio previews are not acceptance under native exterior exposure, tone mapping or lighting. Inspect this exact asset in its intended outdoor lighting before making material changes.
