# Wall service grouping: stored hose beside a tap

Local assembly candidate using two already-delivered CC0 assets. No new art geometry, resizing, texture changes, functional connection or world placement. Native integration and user art acceptance remain unverified.

## Import

Import exactly the two files in `imports/`, preserving metres and each original pivot. Parent them to a local grouping root and apply `placement.json` translations in glTF axes (+X right, +Y up, +Z outward). Rotations are identity and scales are 1. The root is the original hanger wall-plate centre; the common rear wall is local Z=0. Choose world position and mounting height later.

- Hanger LOD1: local translation (0,0,0), 2,896 triangles.
- Hose bib: local translation (0.322,-0.10516507104039192,0), 1,408 triangles.
- Total: 4,304 triangles, two original primitives/materials. Five embedded 512×512 maps total. None enlarged or rebaked.
- Overall envelope: 632.421 mm wide × 641.871 mm high × 228.500 mm projection.
- Conservative horizontal separation between whole-asset bounds: 45.039 mm. This proves the two assets do not intersect; it is not an exact closest-point distance or required service clearance.
- Wall mounting centres are 322 mm apart at equal local height. Hanger screw references are 154 mm apart vertically. Tap bolt axes are 88×85 mm apart at the original flange front, 40 mm outward from rear wall.

The wall is a reference plane only. No room, mounting-height choice, hidden connector, extra fastener, plumbing, collision or runtime LOD switching is included. Capped tap and separate stored hose are deliberately not connected.

## Review and editable files

`wall_service_group_review.blend` is the editable local assembly of the actual imported GLBs with two parent instances. Original standalone .blend files, procedural scripts and higher-detail hanger LOD0 remain unchanged inside the preserved source archives. The review .blend includes clearly named REVIEW_ONLY cameras/lights and a neutral world. No lights are baked into either import or its maps. The three rendered previews show actual imported geometry; `measured_views.png` is a separate annotated front/side measurement sheet.

Existing LOD1 chosen for a compact, ordinary viewing-distance group: it preserves every coil, both loose leads and coupler silhouettes, and its simplified facets sit consistently beside the already faceted tap. Close inspection still shows the six-sided tube and simplified hardware. This choice is not a claim that LOD1 replaces the preserved LOD0 for close-up use.

## Source contact limits: important

Source mounting markers are visual alignment references, not proof of anchorage, loading, connection, collision or structural capacity. Fresh measurements from the original LOD1 editable source found:
- Backplate rear surface at Z=0; plate thickness 8 mm. Existing screw and washer centres agree with Y=±77 mm references. Screw geometry does not enter the wall.
- Saddle begins at Z=17 mm: 9 mm ahead of the plate front. Support ribs begin at Z=12 mm: a 4 mm AABB gap from the plate front. These original separations remain unchanged.
- The Blender BVH comparison reports 216 candidate triangle-overlap pairs between hose and saddle. A sampled vertex-to-opposite-surface minimum is approximately 0.0661 mm. The pair count is not a penetration depth, full intersection certification, stable-support test or physical contact validation. The source does not establish a clean engineered hose/saddle contact.
- The tap nozzle is capped art geometry; hanger coupler bores are visual dark recesses. There are no functional sockets or connecting hose.

This package validates the new grouping's local wall alignment, positive inter-prop gap and exact source identities. It does not repair the inherited contact details or certify physical integration.

## Rebuild and verify

Tested Blender 4.3.2 and Python 3 with numpy/Pillow. No downloads, repository, engine or absolute source paths required. From any folder:

    python /path/to/package/source/audit.py
    blender -b -t 4 --python-exit-code 1 --python /path/to/package/source/rebuild_review.py
    blender -b -t 2 --python-exit-code 1 --python /path/to/package/source/inspect_preserved_hanger.py
    python /path/to/package/source/annotate_views.py

The review rebuild never rewrites import GLBs. Rebuilding source geometry is unnecessary and would defeat strict byte identity. The included original archives remain the authoritative bytes. Blender source/review file bytes are not expected to be stable across saves; compare geometry and imports instead.

See `qa/identity_and_geometry.json` for fresh raw GLB bounds/material/image data, full archive hashes, original manifest verification and exact archive-member-to-import equality. `qa/fresh_blender_reimport.json` independently checks import bounds and triangle counts. `qa/source_geometry_measured.json` records original component bounds and the scoped contact test. `qa/portable_rebuild.json` records the relocated rebuild check.
