# Actual import review

Reviewed fresh front, right-side, perspective and separate measured views on 2026-10-11. Group reads as a coiled stored hose beside a static tap. No connecting hose or plumbing is suggested. Both rear references meet the same local wall plane, the horizontal bounds have a positive 45.039 mm separation, and original faceting/material character remains evident. LOD1 is appropriate for this compact ordinary-distance review, not a close-up fidelity upgrade.

The right-side image intentionally superposes the two assets in projection; they are separated along X in the actual assembly. Its dashed wall line appears only in the measured sheet. Source rear/support gaps and candidate hose/saddle overlaps are documented, not repaired or treated as load-bearing proof. Studio lighting is not native engine/exterior acceptance. No native engine, physics, interaction, structural capacity or plumbing tests were run.
