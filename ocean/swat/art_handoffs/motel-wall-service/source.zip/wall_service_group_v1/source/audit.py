"""Read-only source-to-import identity and geometry audit. Python 3 + numpy + Pillow."""
import json,struct,hashlib,zipfile,tarfile,io
from pathlib import Path
import numpy as np
from PIL import Image
R=Path(__file__).resolve().parents[1]
def sha(b):return hashlib.sha256(b).hexdigest()
def read_glb(p):
 b=p.read_bytes();magic,ver,ln=struct.unpack_from('<4sII',b);assert magic==b'glTF' and ver==2 and ln==len(b)
 jl,jt=struct.unpack_from('<II',b,12);j=json.loads(b[20:20+jl]);off=20+jl;bl,bt=struct.unpack_from('<II',b,off);bin=b[off+8:off+8+bl]
 def arr(i):
  a=j['accessors'][i];v=j['bufferViews'][a['bufferView']];dt={5126:'<f4',5125:'<u4',5123:'<u2',5121:'u1'}[a['componentType']];n={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4}[a['type']];offset=v.get('byteOffset',0)+a.get('byteOffset',0);stride=v.get('byteStride',np.dtype(dt).itemsize*n)
  return np.ndarray((a['count'],n),dtype=dt,buffer=bin,offset=offset,strides=(stride,np.dtype(dt).itemsize)).copy()
 for n in j['nodes']:
  if 'mesh' in n or 'children' in n:
   assert n.get('translation',[0,0,0])==[0,0,0] and n.get('rotation',[0,0,0,1])==[0,0,0,1] and n.get('scale',[1,1,1])==[1,1,1] and 'matrix' not in n
 points=[];tri=0;prims=0
 for mesh in j['meshes']:
  for p in mesh['primitives']:
   assert p.get('mode',4)==4;v=arr(p['attributes']['POSITION']);inds=arr(p['indices']);assert np.isfinite(v).all() and inds.max()<len(v);points.extend(v);tri+=len(inds)//3;prims+=1
 images=[]
 for im in j['images']:
  bv=j['bufferViews'][im['bufferView']];raw=bin[bv.get('byteOffset',0):bv.get('byteOffset',0)+bv['byteLength']];sz=Image.open(io.BytesIO(raw)).size;assert sz==(512,512);images.append({'name':im.get('name'),'size':sz,'sha256':sha(raw)})
 v=np.array(points);return {'sha256':sha(b),'bytes':len(b),'bounds_min_m':v.min(0).tolist(),'bounds_max_m':v.max(0).tolist(),'triangles':tri,'primitives':prims,'materials':j['materials'],'images':images,'nodes':j['nodes']}
spec=[('bib','exterior_hose_bib_reuse_v1_CC0.zip','runtime/wall_garden_spigot_reuse.glb','wall_garden_spigot_reuse.glb'),('hanger','motel-wall-hose-hanger-v1.tar.gz','motel_wall_hose_hanger_v1/runtime/wall_hose_hanger_LOD1.glb','wall_hose_hanger_LOD1.glb')]
out={'source_members_checked':{},'imports':{}}
for key,archive,member,imp in spec:
 p=R/'sources'/archive
 if archive.endswith('.zip'):
  z=zipfile.ZipFile(p);get=z.read;names=z.namelist();pre=''
 else:
  z=tarfile.open(p);get=lambda n:z.extractfile(n).read();names=z.getnames();pre='motel_wall_hose_hanger_v1/'
 checks=get(pre+'SHA256SUMS.txt').decode().splitlines();count=0
 for line in checks:
  if not line.strip():continue
  hash,name=line.split(None,1);name=name.lstrip('*');assert sha(get(pre+name))==hash,(archive,name);count+=1
 raw=(R/'imports'/imp).read_bytes();assert raw==get(member)
 out['source_members_checked'][key]={'archive':archive,'archive_sha256':sha(p.read_bytes()),'archive_bytes':p.stat().st_size,'internal_manifest_files_passed':count,'import_member':member,'import_bytes_equal':True}
 out['imports'][key]=read_glb(R/'imports'/imp)
p=json.loads((R/'placement.json').read_text());mins=[];maxs=[]
for o in p['instances']:
 a=out['imports'][o['id']];t=np.array(o['translation_m']);mi=np.array(a['bounds_min_m'])+t;ma=np.array(a['bounds_max_m'])+t;mins.append(mi);maxs.append(ma);o['measured_assembly_bounds_min_m']=mi.tolist();o['measured_assembly_bounds_max_m']=ma.tolist()
lo=np.min(mins,axis=0);hi=np.max(maxs,axis=0)
out['assembly']={'bounds_min_m':lo.tolist(),'bounds_max_m':hi.tolist(),'dimensions_m':(hi-lo).tolist(),'x_separation_lower_bound_m':float(mins[0][0]-maxs[1][0]),'triangles':sum(a['triangles']for a in out['imports'].values()),'primitives':sum(a['primitives']for a in out['imports'].values())};assert out['assembly']['x_separation_lower_bound_m']>0
(R/'qa/identity_and_geometry.json').write_text(json.dumps(out,indent=2));(R/'placement.json').write_text(json.dumps(p,indent=2));print(json.dumps(out['assembly'],indent=2));print('SOURCE IDENTITY AND RAW GEOMETRY AUDIT PASSED')
