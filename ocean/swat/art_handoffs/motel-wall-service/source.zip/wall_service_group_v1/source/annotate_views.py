"""Separate dimension sheet using actual orthographic renders; no asset image edits."""
from PIL import Image,ImageDraw,ImageFont
from pathlib import Path
import json
R=Path(__file__).resolve().parents[1];q=json.loads((R/'qa/identity_and_geometry.json').read_text())['assembly']
I=Image.new('RGB',(1800,1200),'#f4f5f4');d=ImageDraw.Draw(I)
font='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
f=lambda n:ImageFont.truetype(font,n)
ink='#172c34';accent='#157f96';white='#ffffff';line='#77dcee'
d.text((60,30),'STORED HOSE + TAP  /  LOCAL MOUNTING GUIDE',font=f(33),fill=ink)
d.text((60,83),'Original imports, metres, +Y up, +Z outward. No world mounting height or functional hose connection.',font=f(21),fill=ink)
for label,name,x in [('FRONT  /  looking toward wall','front',80),('RIGHT SIDE  /  outward projects left','side',920)]:
 I.paste(Image.open(R/'preview'/f'{name}.png').convert('RGB').resize((800,800)),(x,180));d.text((x,140),label,font=f(23),fill=ink)
s=800/.82
front=lambda x,y:(80+400+(x-.07778957)*s,180+400-(y+.21593536)*s)
side=lambda z,y:(920+400+(.11-z)*s,180+400-(y+.21593536)*s)
def seg(a,b):d.line([a,b],fill=line,width=2)
def cross(p):x,y=p;seg((x-7,y),(x+7,y));seg((x,y-7),(x,y+7))
def horiz(x1,x2,y,text):
 seg((x1,y),(x2,y));seg((x1,y-8),(x1,y+8));seg((x2,y-8),(x2,y+8));box=d.textbbox((0,0),text,font=f(20));w=box[2];d.rectangle((.5*(x1+x2)-w/2-5,y-29,.5*(x1+x2)+w/2+5,y-3),fill='#173039');d.text((.5*(x1+x2)-w/2,y-29),text,font=f(20),fill=white)
lo=q['bounds_min_m'];hi=q['bounds_max_m'];x1,yb=front(lo[0],lo[1]);x2,yt=front(hi[0],hi[1]);horiz(x1,x2,951,'632.421 mm overall')
seg((x1,yb),(x1,958));seg((x2,yt),(x2,958));seg((95,yt),(95,yb));seg((88,yt),(102,yt));seg((88,yb),(102,yb))
d.text((102,600),'641.871 mm',font=f(19),fill=white)
for x,y in [(0,0),(0,.077),(0,-.077),(.322,0)]:cross(front(x,y))
a=front(0,0);b=front(.322,0);horiz(a[0],b[0],305,'322 mm mounting centres');seg(a,(a[0],305));seg(b,(b[0],305))
xg1,_=front(.20496131479740143,0);xg2,_=front(.25000000309944154,0)
seg((xg1,338),(xg1,375));seg((xg2,338),(xg2,375));seg((xg1,350),(xg2,350));seg(((xg1+xg2)/2,350),(760,410));d.text((608,417),'45.039 mm min. X gap',font=f(18),fill=white)
wx,_=side(0,0)
for yy in range(220,950,16):d.line((wx,yy,wx,yy+8),fill=line,width=2)
d.text((wx+15,240),'WALL',font=f(21),fill=white);d.text((wx+15,270),'Z = 0',font=f(21),fill=white)
a,_=side(.22849999368190765,0);horiz(a,wx,951,'228.500 mm projection')
d.text((60,1012),'Reference only: both rear faces align to Z=0. Hanger screw references: Y = ±77 mm (154 mm apart).',font=f(22),fill=ink)
d.text((60,1052),'Gap is a conservative bounding-envelope separation, not exact closest distance or required service access.',font=f(21),fill=ink)
d.text((60,1092),'Inherited saddle/rib contacts are not structurally validated. Tap is capped; stored hose remains disconnected.',font=f(21),fill=ink)
d.text((60,1132),'4,304 triangles • 2 unchanged import GLBs • original 512 px maps • no added support or plumbing geometry',font=f(21),fill=ink)
I.save(R/'preview/measured_views.png')
