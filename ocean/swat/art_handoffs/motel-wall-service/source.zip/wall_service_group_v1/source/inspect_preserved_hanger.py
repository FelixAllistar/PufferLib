import bpy,json,tarfile,tempfile
from pathlib import Path
from mathutils.bvhtree import BVHTree
R=Path(__file__).resolve().parents[1]
tmp=tempfile.TemporaryDirectory()
with tarfile.open(R/'sources/motel-wall-hose-hanger-v1.tar.gz') as archive:
 data=archive.extractfile('motel_wall_hose_hanger_v1/source/wall_hose_hanger_LOD1.blend').read()
blend=Path(tmp.name)/'source.blend';blend.write_bytes(data)
bpy.ops.wm.open_mainfile(filepath=str(blend))
def xyz(v):return [v.x,v.z,-v.y]
rows=[]
for o in bpy.context.scene.objects:
 if o.type=='MESH':
  vs=[o.matrix_world@v.co for v in o.data.vertices];a=[xyz(v)for v in vs]
  rows.append({'name':o.name,'min':[min(v[i]for v in a)for i in range(3)],'max':[max(v[i]for v in a)for i in range(3)]})
h=bpy.data.objects['Continuous loosely dressed garden hose'];s=bpy.data.objects['Curved steel support saddle']
def bvh(o):return BVHTree.FromPolygons([o.matrix_world@v.co for v in o.data.vertices],[list(p.vertices)for p in o.data.polygons])
bs,bh=bvh(s),bvh(h)
near=[]
for a,b in [(h,bs),(s,bh)]:
 for v in a.data.vertices:
  p=a.matrix_world@v.co;q,n,i,d=b.find_nearest(p)
  near.append((d,xyz(p),xyz(q)))
(R/'qa/source_geometry_measured.json').write_text(json.dumps({'components':rows,'hose_saddle_vertex_surface_minimum':min(near),'hose_saddle_bvh_candidate_overlap_pairs':len(bs.overlap(bh))},indent=2))
