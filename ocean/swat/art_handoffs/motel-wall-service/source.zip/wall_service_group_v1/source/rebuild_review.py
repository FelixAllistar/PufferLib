"""Portable review build from unchanged imports. Blender 4.3.2. Never exports or edits GLBs."""
import bpy,json,sys
from pathlib import Path
from mathutils import Vector
R=Path(__file__).resolve().parents[1];p=json.loads((R/'placement.json').read_text())
bpy.ops.wm.read_factory_settings(use_empty=True);s=bpy.context.scene;s.unit_settings.system='METRIC';s.unit_settings.scale_length=1
root=bpy.data.objects.new('WALL_SERVICE_GROUP_LOCAL_ROOT',None);s.collection.objects.link(root)
root['scope']='Local review grouping only. Stored hose near tap. No structural or plumbing integration.'
subjects=[]
for inst in p['instances']:
 before=set(s.objects);bpy.ops.import_scene.gltf(filepath=str(R/inst['file']));new=set(s.objects)-before
 holder=bpy.data.objects.new(inst['id']+'_UNCHANGED_IMPORT_ROOT',None);s.collection.objects.link(holder);holder.parent=root
 for o in new:
  if o.parent not in new:o.parent=holder
 holder.location=(inst['translation_m'][0],-inst['translation_m'][2],inst['translation_m'][1]);holder['source_file']=inst['file'];holder['original_scale_preserved']=True
 subjects.extend(o for o in new if o.type=='MESH')
bpy.context.view_layer.update()
vs=[o.matrix_world@v.co for o in subjects for v in o.data.vertices];xyz=[(v.x,v.z,-v.y)for v in vs]
q={'fresh_import_meshes':len(subjects),'bounds_min_m':[min(v[i]for v in xyz)for i in range(3)],'bounds_max_m':[max(v[i]for v in xyz)for i in range(3)],'triangles':0}
for o in subjects:o.data.calc_loop_triangles();q['triangles']+=len(o.data.loop_triangles)
assert q['triangles']==4304
(R/'qa/fresh_blender_reimport.json').write_text(json.dumps(q,indent=2))
s.render.engine='CYCLES';s.cycles.samples=64;s.cycles.use_denoising=False;s.render.resolution_x=1000;s.render.resolution_y=1000;s.render.resolution_percentage=100
s.world=bpy.data.worlds.new('REVIEW_ONLY_neutral_world');s.world.use_nodes=True;s.world.node_tree.nodes['Background'].inputs[0].default_value=(.18,.20,.21,1);s.world.node_tree.nodes['Background'].inputs[1].default_value=.55
s.view_settings.view_transform='AgX';s.view_settings.exposure=0
cen=Vector((.07778957,-.11,-.21593536))
for loc,energy,size in [((-1,-2,1.6),220,1.8),((1.6,-1,.5),130,1.3),((.1,.7,1.5),150,1.2)]:
 bpy.ops.object.light_add(type='AREA',location=loc);o=bpy.context.object;o.name='REVIEW_ONLY_'+o.name;o.data.energy=energy;o.data.shape='DISK';o.data.size=size;o.rotation_euler=(cen-o.location).to_track_quat('-Z','Y').to_euler()
for name,loc,scale in [('front',(.07778957,-2,-.21593536),.82),('side',(2,-.11,-.21593536),.82),('perspective',(1,-1.8,.6),.85)]:
 bpy.ops.object.camera_add(location=loc);c=bpy.context.object;c.name='REVIEW_ONLY_'+name;c.data.type='ORTHO';c.data.ortho_scale=scale;c.rotation_euler=(cen-c.location).to_track_quat('-Z','Y').to_euler();s.camera=c
 if '--no-render' not in sys.argv:
  s.render.filepath=str(R/'preview'/f'{name}.png');bpy.ops.render.render(write_still=True)
s.camera=bpy.data.objects['REVIEW_ONLY_perspective']
for im in bpy.data.images:
 if im.source=='FILE' and not im.packed_file:im.pack()
bpy.ops.wm.save_as_mainfile(filepath=str(R/'wall_service_group_review.blend'))
print('PORTABLE REVIEW REBUILD PASSED',q)
