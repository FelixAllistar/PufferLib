import json, pathlib, hashlib
P=pathlib.Path(__file__).resolve().parent.parent;p=json.load(open(P/'proposal.json'));a=p['assets'];checks={}
def near(x,y):return abs(x-y)<1e-8
for name,v in a.items():
 b=v['proposed_aabb_source_m'];o=v['original']['measured_aabb_source_m'];checks[name+'_preserves_full_original_bounds_2um']=all(abs(b[k][i]-o[k][i])<2e-6 for k in range(2) for i in range(3))
 checks[name+'_panes_sizes_and_enclosure']=all(all(near(q['size_xyz_m'][i],q['aabb_source_m'][1][i]-q['aabb_source_m'][0][i]) and b[0][i]<=q['aabb_source_m'][0][i]<q['aabb_source_m'][1][i]<=b[1][i] for i in range(3)) for q in v['proposed_panes'])
 rt=v['retention'];g=rt['glass_y_interval'];ga=rt['gasket_y_intervals'];li=rt['rigid_lip_y_intervals'];checks[name+'_face_stack']=near(li[0][1],ga[0][0]) and near(ga[0][1],g[0]) and near(g[1],ga[1][0]) and near(ga[1][1],li[1][0]) and all(near(hi-lo,.002) for lo,hi in ga+li)
r=a['room_window_insert'];rp=r['proposed_panes'];f=r['frame'];rt=r['retention'];c=r['curtain'];j=f['preserved_envelopes']['jamb_x_intervals'];m=f['preserved_envelopes']['mullion_xyz_bounds'];g0,g1=[q['aabb_source_m'] for q in rp]
checks['room_horizontal_bites_12mm']=all(near(x,.012) for x in [j[0][1]-g0[0][0],g0[1][0]-m[0][0],m[1][0]-g1[0][0],g1[1][0]-j[1][0]])
checks['room_web_side_clearance_1mm']=near(rt['center_web_x_interval'][0]-g0[1][0],.001) and near(g1[0][0]-rt['center_web_x_interval'][1],.001)
checks['room_vertical_bites_12mm']=near(f['proposed_bottom_rail_z_interval'][1]-g0[0][2],.012) and near(g0[1][2]-f['preserved_envelopes']['top_rail_z_interval'][0],.012)
checks['room_setting_floor_within_lower_rail']=f['proposed_bottom_rail_z_interval'][0]<.035<.038 and near(.038-.035,.003)
checks['room_gaps']=near(c['surface_envelope_y_interval'][0]-g0[1][1],.0465) and near(c['surface_envelope_y_interval'][0]-m[1][1],.0047) and near(r['proposed_aabb_source_m'][1][1]-c['surface_envelope_y_interval'][1],.0147) and near(c['z_interval'][0]-f['sill']['bounds'][1][2],.0355)
checks['room_rod_clears_mullion_9mm']=near(.04-.006-m[1][1],.009)
l=a['lobby_glazed_facade'];lf=l['frame']; spans=lf['horizontal_clear_spans_x'];rails=lf['proposed_horizontal_z_intervals'];checks['lobby_all_bites_12mm']=True
for q in l['proposed_panes']:
 lo,hi=q['aabb_source_m'];sp=spans[0 if 'left' in q['id'] else 1];bottom,top=(rails[0],rails[1]) if 'lower' in q['id'] else (rails[1],rails[2]);checks['lobby_all_bites_12mm'] &= all(near(x,.012) for x in [sp[0]-lo[0],hi[0]-sp[1],bottom[1]-lo[2],hi[2]-top[0]])
checks['lobby_midrail_pockets_leave_10mm_web']=near((.758-.003)-(.742+.003),.010)
checks['lobby_block_floors_3mm']=near(.068-.065,.003) and near(.758-.755,.003)
checks['lobby_doorway_width_height']=near(l['doorway']['clear_bounds_source_m'][1][0]-l['doorway']['clear_bounds_source_m'][0][0],1.27) and near(l['doorway']['clear_bounds_source_m'][1][2],2.4)
checks['lobby_panes_and_rails_outside_doorway']=min(q['aabb_source_m'][0][0] for q in l['proposed_panes'])>-.67 and min(sp[0] for sp in spans)>-.67
import math
checks['ring_x_stations_at_fold_mean_y']=all(abs(math.sin(10*math.pi*(x-(-.9 if x<0 else .52))/.38))<1e-10 for x in c['ring_x_centers_m'])
checks['ring_contacts_rod_top']=near(1.229+.007,1.230+.006)
checks['socket_engagement_5mm']=near(abs(c['rod']['axis_endpoints'][1][0])-.950,.005)
checks['main_cloth_below_ring_wire']=c['z_interval'][1]<1.220
checks['loop_top_rod_clearance_1_4mm']=near(1.230-.006-c['sewn_loop_z_envelope'][1],.0014)
checks['bracket_bounds_within_frozen_envelope']=all(all(r['proposed_aabb_source_m'][0][i]<=b[0][i]<=b[1][i]<=r['proposed_aabb_source_m'][1][i] for i in range(3)) for k,b in c['hardware_bounds_source_m'].items() if 'bracket' in k)
assert all(checks.values()),checks
report={'status':'Numeric intervals pass; hardware and actual profiles require separate mesh validation. No exported replacement inspected.','checks':checks};print(json.dumps(report,indent=2));pathlib.Path(__file__).with_name('report.json').write_text(json.dumps(report,indent=2))
