import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
import numpy as np
from pathlib import Path
import argparse
parser=argparse.ArgumentParser(description='Draw original proposal diagrams; no 3D asset operations.')
parser.add_argument('--output-dir',type=Path,default=Path(__file__).resolve().parent)
args=parser.parse_args();out=args.output_dir;out.mkdir(parents=True,exist_ok=True)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10})
blue='#2b9fc0';metal='#8a918b';cloth='#bf7f59';wood='#b49a69'
def rect(ax,x,y,w,h,c,**kw): ax.add_patch(Rectangle((x,y),w,h,facecolor=c,edgecolor='#343c3d',lw=.7,**kw))
fig,axs=plt.subplots(2,1,figsize=(13,9),constrained_layout=True)
a=axs[0]
for x in [-1000,960]:rect(a,x,-60,40,120,metal)
rect(a,-14,-65,28,90,metal)
for lo,hi in [(-975,-960),(-14,-1),(1,14),(960,975)]: rect(a,lo,-25.2,hi-lo,10.4,'white')
for x,w in [(-972,970),(2,970)]:rect(a,x,-23.2,w,6.4,blue)
for l,r in [(-900,-520),(520,900)]:
 x=np.linspace(l,r,180); a.plot(x,40+10*np.sin((x-l)/(r-l)*10*np.pi),color=cloth,lw=2)
a.axhline(65,color='#999',ls='--',lw=.8);a.axhline(-185,color='#999',ls='--',lw=.8)
a.annotate('46.5 mm minimum\nglass → cloth',xy=(-730,29.7),xytext=(-620,85),arrowprops={'arrowstyle':'->'},ha='center')
a.text(0,-115,'EXTERIOR −Y',ha='center');a.text(0,89,'ROOM +Y',ha='center');a.text(0,-178,'Sill front limit Y=−185 (sill is below cut)',ha='center')
a.set(xlim=(-1110,1110),ylim=(-200,132),xlabel='Local X (mm)',ylabel='Local Y (mm)',title='ROOM · top-down at mid glass height | depth exaggerated')
a.text(-1040,119,'Frozen full width 2070 · 6.4 glass · gray profile / blue glass / tan cloth',fontsize=9)
a=axs[1]
for x in [-2000,-670,620,1940]:rect(a,x,-60,60,120,metal)
for lo,hi in [(-625,-610),(620,635),(665,680),(1940,1955)]: rect(a,lo,14.8,hi-lo,10.4,'white')
for x,w in [(-622,1254),(668,1284)]:rect(a,x,16.8,w,6.4,blue)
a.annotate('',xy=(-1940,-18),xytext=(-670,-18),arrowprops={'arrowstyle':'<->'})
a.text(-1305,4,'1270 CLEAR\nleft doorway',ha='center',va='bottom');a.text(650,-38,'Glazing has no curtains',ha='center')
a.text(0,-100,'EXTERIOR −Y',ha='center');a.text(0,95,'ROOM +Y',ha='center')
a.set(xlim=(-2140,2140),ylim=(-125,125),xlabel='Local X (mm)',ylabel='Local Y (mm)',title='LOBBY · top-down through upper panes | depth exaggerated')
fig.suptitle('BRIAR COURT · proposed local plan sections',fontsize=18,fontweight='bold')
fig.savefig(out/'topdown.png',dpi=170);fig.savefig(out/'topdown.svg');plt.close(fig)
fig,axs=plt.subplots(1,3,figsize=(16,10),gridspec_kw={'width_ratios':[1.1,1.1,1.5]},constrained_layout=True)
a=axs[0]
rect(a,-185,-8.5,250,33,wood);rect(a,-60,24.5,120,25.5,metal);rect(a,-60,1250,120,50,metal)
for z,h in [(35,15),(1250,15)]:rect(a,-25.2,z,10.4,h,'white')
rect(a,-23.2,38,6.4,1224,blue);rect(a,29.7,60,20.6,1159,cloth)
a.plot(40,1230,'o',ms=7,color='#555');a.annotate('Ø12 rod + rings',xy=(40,1230),xytext=(85,1160),arrowprops={'arrowstyle':'->'},fontsize=9)
a.annotate('Thin folded cloth\n0.6 gauge; 20.6 envelope',xy=(50,680),xytext=(83,770),arrowprops={'arrowstyle':'->'},fontsize=9)
a.annotate('46.5 clear',xy=(29.7,450),xytext=(-140,510),arrowprops={'arrowstyle':'->'},fontsize=10)
a.text(-177,1110,'EXTERIOR',fontsize=9);a.text(88,1060,'ROOM',fontsize=9)
a.set(xlim=(-205,280),ylim=(-55,1360),xlabel='Local Y (mm)',ylabel='Local Z (mm)',title='ROOM · vertical section\nthrough cloth and pane')
a=axs[1]
for z,h in [(0,80),(730,40),(2340,60)]:rect(a,-60,z,120,h,metal)
rect(a,-90,2400,180,400,wood)
for z,h in [(65,15),(730,15),(755,15),(2340,15)]:rect(a,14.8,z,10.4,h,'white')
for z,h in [(68,674),(758,1594)]:rect(a,16.8,z,6.4,h,blue)
a.annotate('Four panes total\nTwo shown in this cut',xy=(23,1600),xytext=(70,1880),arrowprops={'arrowstyle':'->'},fontsize=9)
a.annotate('Middle rail has\nseparate pockets',xy=(25,750),xytext=(-165,1080),arrowprops={'arrowstyle':'->'},fontsize=9)
a.text(-155,2540,'Timber header',fontsize=9);a.text(-150,190,'Floor Z=0',fontsize=9)
a.set(xlim=(-180,250),ylim=(-60,2900),xlabel='Local Y (mm)',ylabel='Local Z (mm)',title='LOBBY · vertical section\nhead/base now reach supports')
a=axs[2]
# Glazing retention schematic detail: the exact face-depth stack, edge is horizontal.
# Room pane bottom is Z38; sightline Z50; pocket floor Z35.
rect(a,-23.2,38,6.4,36,blue)
rect(a,-25.2,38,2,12,'#354f45');rect(a,-16.8,38,2,12,'#354f45')
rect(a,-27.2,35,2,15,metal);rect(a,-14.8,35,2,15,metal)
rect(a,-27.2,33,14.4,2,metal);rect(a,-25,35,10,3,'#354f45')
a.annotate('6.4 glass',xy=(-20,66),xytext=(-37,75),arrowprops={'arrowstyle':'->'})
a.annotate('2 gasket\neach face',xy=(-24.2,45),xytext=(-43,56),arrowprops={'arrowstyle':'->'},fontsize=10)
a.annotate('Removable\ninterior stop',xy=(-13.8,45),xytext=(-7,58),arrowprops={'arrowstyle':'->'},fontsize=10)
a.annotate('3 setting block\ncontacts glass bottom',xy=(-20,36.5),xytext=(-40,22),arrowprops={'arrowstyle':'->'},fontsize=10)
a.annotate('',xy=(-9,38),xytext=(-9,50),arrowprops={'arrowstyle':'<->'});a.text(-7.5,42,'12 bite',fontsize=9)
a.text(-45,83,'EXTERIOR −Y                  ROOM +Y',fontsize=9)
a.set(xlim=(-47,10),ylim=(15,88),xlabel='Local Y (mm)',ylabel='Local Z (mm)',title='ROOM · enlarged sill pocket\nexact contact stack; illustrative profile')
for a in axs:a.grid(alpha=.12)
fig.suptitle('BRIAR COURT · sections and retention detail',fontsize=18,fontweight='bold')
fig.get_layout_engine().set(rect=(0,0.04,1,.96))
fig.text(.5,.01,'PROPOSAL ONLY · axes use different scales · gaskets omitted in wide views, detailed at right · JSON is dimensional authority',ha='center',fontsize=10)
fig.savefig(out/'sections.png',dpi=170);fig.savefig(out/'sections.svg');plt.close(fig)
print('Wrote original proposal diagrams')
