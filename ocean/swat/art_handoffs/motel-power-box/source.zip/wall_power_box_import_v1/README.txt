POWER BOX 01 — ONE SOURCE-FAITHFUL SHELTERED SERVICE-WALL CANDIDATE

Runtime: imports/power_box_01_rear_centered_1k.glb
4,388,152 bytes; 21,272 triangles; two source meshes; one source material.
This is relatively dense for a small detail. It is NOT automatically accepted for
an Xbox 360-style or other constrained performance budget. No reduction, LOD,
engine test, collision setup or installed placement has been performed.

SELECTION
Poly Haven Power Box 01, by Rico Cilliers (Modeling & Texturing), with Yann Kervran
credited for Rigging by the existing source manifest. CC0 1.0.
https://polyhaven.com/a/power_box_01
https://polyhaven.com/license
The source glTF has a separately posed door and body, but no skin or animation.
Treat this import as static. This bundle does not substantiate a runtime rig.

The 4,404-triangle Utility Box 01 was inspected from the same original archive.
It measures 0.5200 wide x 1.1203 high x 0.4320 deep (metres) and has a vented
pedestal-style base, roof and finished rear. It is not selected as a small wall
detail. The chosen Power Box is physically smaller but has more geometry.
No new source acquisition was used; the source archive was recovered from Drive.

SCALE AND PLACEMENT REFERENCE
Right-handed glTF coordinates, Y up, metres. Source geometry and scale unchanged.
+Z points out from a proposed wall. X is centered on the BODY bounding box;
Y remains at the source body's vertical center. The complete open-door pose is
asymmetric. The sole new parent is PowerBox_RearEnvelopeCentered, translating
source coordinates by [-0.0022541657090187073, 0, 0.04748108983039856] metres.
Original nodes, source door quaternion and translations remain byte-for-byte
identical as JSON values beneath this parent.

The proposed rear-envelope placement plane is exported Z=0, corresponding to
source Z=-0.04748108983039856 m. This is a GEOMETRIC reference, not a verified
mounting face, fastener specification, physical wall or anchor location.
No geometry lies behind this plane. Do not use it as an installation instruction.
Source weatherproofing and real mounting requirements are unknown; use as a
visual sheltered maintenance/service-wall candidate only.

MEASURED ENVELOPES (metres)
Body: 0.3455065 width x 0.5031428 height x 0.0945064 depth.
Whole shipped open pose: 0.4613243 width x 0.5031428 height x 0.3989851 depth.
Export whole min XYZ: [-0.2885710, -0.2515714, 0].
Export whole max XYZ: [ 0.1727533,  0.2515714, 0.3989851].
The body projects 94.506 mm forward of the reference; the fixed open door reaches
398.985 mm forward, and extends 115.818 mm left beyond the body's envelope.
These are fixed-pose geometric clearances, not door sweep or working clearances.
Do not close/repose the source door and assume these numbers still apply.

Rear rim-like geometry has 44 triangles within 1 micrometre of the rear plane,
with summed triangle area 0.0223784 m2; 134 source body vertices are within 1 mm.
A broad rear-facing/recessed patch is approximately 20.426 mm in front of that
plane. These measurements describe modeled surfaces only, not gauge, physical
thickness, standoff hardware or verified load-bearing contact. The exact patch
bounds and parallel-plane measurements are in qa/body_parallel_planes.json.

SOURCE COMPONENTS AND PBR
node 0 power_box_01_door / mesh 0 Plane: 1,416 triangles, 1,256 stored vertices.
node 1 power_box_01_box / mesh 1 Cube.002: 19,856 triangles, 19,196 stored vertices.
Both primitives use material 0 power_box_01. This is a mixed enclosure/breaker
material, not separately verified metal, polymer or dielectric assignments. No
physical substrate, conductivity or material-gauge inference is supplied. No
semantic material splits have been invented. Body-side breaker and hinge-like
geometry remains in the source body mesh; the open door remains separate.
No separately verified wall-attachment bracket, anchor, bolt, or mounting-hole
set has been identified. Visible fastener-like marks are not certified hardware.
Do not infer their function, physical substrate, material gauge or anchor points.

Original material definitions are preserved exactly, including doubleSided=true.
texture 0: OpenGL tangent-space normal, image 0; non-color.
texture 1: base color, image 1; sRGB.
texture 2: packed ARM, image 2; G=roughness, B=metallic; non-color.
Metallic/roughness factors remain glTF defaults of 1. The R channel is retained
but the source has no occlusionTexture binding; none was invented. No TANGENT
accessor was authored, so engine importers may generate tangents.

Each original 2K JPEG was deterministically reduced to 1K PNG:
- Color: IEC sRGB decode, exact 2x2 linear-light average, sRGB encode
- ARM: exact 2x2 linear non-color channel average, no repaint or roughness bias
- Normal: decode OpenGL vectors, normalize source, 2x2 average, renormalize
  result, encode RGB
Final quantization uses nearest-even numpy rint, clipped to RGB8. No sharpening,
texture replacement, invented grime or albedo rebake. Original albedo may carry
source shading. Runtime has one embedded GLB, no external texture dependencies
and no alternative runtime exports. derived_textures contains the reproducible
images embedded in that GLB, not an alternative model.

SOURCE RETENTION AND LICENSE
source/power_box_01 retains the original glTF, geometry BIN and 2K JPEGs intact.
provenance/original_pack_manifest.json contains the original pack's identities,
authors, source URLs and source-file SHA-256 hashes; only the selected asset's
files are bundled. Source files are validated against those hashes on rebuild.
The prior archive README records publisher MD5 verification at acquisition;
this rebuild independently verifies SHA-256, not a live publisher MD5 lookup.
provenance/source_archive_receipt.json records recovered original archive hash,
size and Drive identity. The large source ZIP itself is not required for rebuild.
CC0 legal text is included. Existing seating, trashbag, tool chest, chair and
procedural assets were not changed or replaced.

REBUILD AND QA
Python 3.12, numpy 2.3.5, Pillow 12.3.0 were used. From this extracted bundle:
  python scripts/build.py
  python scripts/measure_planes.py
For actual final-GLB Blender import/render inspection (Blender 4.3.2 used):
  blender -b -t 4 --python scripts/render.py
The builder verifies all source-file hashes; original geometry buffer prefix;
all position/normal/UV/index accessors; original mesh/material/texture/sampler
JSON; original child nodes; referenced indices, finite coordinates, bounds;
and embedded image bytes against deterministic texture outputs.
qa/portable_rebuild.json records an independent clean-extraction rebuild.
Renders show the actual exported GLB from front/back/side and straight front/back.
Review floor, lighting and cameras are not in the runtime GLB. See visual_review.

Three 1K RGB8 maps have 9 MiB uncompressed base pixels; RGBA8 import could use
12 MiB base / about 16 MiB full mips, before engine overhead and copies.
These are estimates, not measured VRAM. No GPU compression or target-engine
performance has been tested. The mesh is source-faithful, not budget certified.
