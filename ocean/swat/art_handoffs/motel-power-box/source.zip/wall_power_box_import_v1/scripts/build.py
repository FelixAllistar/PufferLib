import json,hashlib,copy,struct,io
from pathlib import Path
import numpy as np
from PIL import Image
from gltf_utils import accessor,measure,bounds,sha
R=Path(__file__).resolve().parents[1]
# Read only bundled source/provenance. Never overwrite originals.
receipt=json.loads((R/'provenance/source_archive_receipt.json').read_text())
for directory in ['derived_textures','imports','qa']:(R/directory).mkdir(parents=True,exist_ok=True)
meta=next(x for x in json.loads((R/'provenance/original_pack_manifest.json').read_text()) if x['id']=='power_box_01'); audit=[]
for f in meta['files']:
 raw=(R/'source'/f['path']).read_bytes();assert len(raw)==f['bytes'] and sha(raw)==f['sha256'];audit.append(dict(f,verified_against_bundled_manifest=True))
p=R/'source/power_box_01/power_box_01_2k.gltf';orig=json.loads(p.read_text());ob=(p.parent/'power_box_01.bin').read_bytes();d=copy.deepcopy(orig);b=ob
before=bounds(measure(orig,ob));lo=np.array(before['min_xyz_m']);hi=np.array(before['max_xyz_m']);offset=np.array([-(measure(orig,ob)[1]['min_xyz_m'][0]+measure(orig,ob)[1]['max_xyz_m'][0])/2,0.,-lo[2]])
roots=d['scenes'][0]['nodes'];d['scenes'][0]['nodes']=[len(d['nodes'])];d['nodes'].append({'name':'PowerBox_RearEnvelopeCentered','translation':offset.tolist(),'children':roots})
def down(a):return a.reshape(1024,2,1024,2,3).mean(axis=(1,3))
images=[]
for im in d['images']:
 uri=im.pop('uri');raw=(p.parent/uri).read_bytes();a=np.asarray(Image.open(io.BytesIO(raw)).convert('RGB'),dtype=np.float64)/255;assert a.shape==(2048,2048,3)
 if '_diff_' in uri:
  linear=np.where(a<=.04045,a/12.92,((a+.055)/1.055)**2.4);v=down(linear);out=np.where(v<=.0031308,12.92*v,1.055*v**(1/2.4)-.055);method='IEC sRGB decode, exact 2x2 area mean in linear light, IEC sRGB encode'
 elif '_nor_gl_' in uri:
  v=a*2-1;v/=np.maximum(np.linalg.norm(v,axis=2,keepdims=True),1e-12);v=down(v);v/=np.maximum(np.linalg.norm(v,axis=2,keepdims=True),1e-12);out=v*.5+.5;method='Decode OpenGL tangent normals to [-1,1], normalize source vectors, exact 2x2 area mean, normalize resultant vectors, encode RGB'
 else:out=down(a);method='Linear non-color ARM exact 2x2 area mean; no roughness bias or repaint'
 quant=np.clip(np.rint(out*255),0,255).astype('uint8');name=Path(uri).name.replace('_2k.jpg','_1k.png');dest=R/'derived_textures'/name;Image.fromarray(quant).save(dest,compress_level=9);rr=dest.read_bytes();assert sha(rr)!=sha(raw)
 b+=b'\0'*(-len(b)%4);im['bufferView']=len(d['bufferViews']);im['mimeType']='image/png';d['bufferViews'].append({'buffer':0,'byteOffset':len(b),'byteLength':len(rr)});b+=rr
 item={'source_uri':uri,'source_sha256':sha(raw),'source_bytes':len(raw),'derived_path':'derived_textures/'+name,'derived_sha256':sha(rr),'derived_bytes':len(rr),'dimensions':[1024,1024],'method':method,'source_mean_rgb':a.mean((0,1)).tolist(),'derived_mean_rgb':(quant/255).mean((0,1)).tolist()}
 if '_nor_gl_' in uri:
  lengths=np.linalg.norm(quant/255*2-1,axis=2);item['quantized_vector_length_range']=[float(lengths.min()),float(lengths.max())]
 images.append(item)
b+=b'\0'*(-len(b)%4);d['buffers']=[{'byteLength':len(b)}];j=json.dumps(d,separators=(',',':')).encode();j+=b' '*(-len(j)%4);glb=struct.pack('<III',0x46546c67,2,28+len(j)+len(b))+struct.pack('<II',len(j),0x4e4f534a)+j+struct.pack('<II',len(b),0x004e4942)+b
out=R/'imports/power_box_01_rear_centered_1k.glb';out.write_bytes(glb)
# Reopen actual final GLB, not in-memory source.
r=out.read_bytes();magic,version,total=struct.unpack_from('<III',r);assert (magic,version,total)==(0x46546c67,2,len(r));jl,jt=struct.unpack_from('<II',r,12);actual=json.loads(r[20:20+jl]);bl,bt=struct.unpack_from('<II',r,20+jl);bb=r[28+jl:];assert bl==len(bb) and jt==0x4e4f534a and bt==0x004e4942
assert bb[:len(ob)]==ob
for key in ['meshes','materials','textures','samplers','accessors','asset']:assert actual[key]==orig[key]
assert actual['nodes'][:-1]==orig['nodes'];assert actual['bufferViews'][:len(orig['bufferViews'])]==orig['bufferViews'];assert not any('uri' in x for x in actual['images']+actual['buffers'])
audit_access=[]
for i in range(len(orig['accessors'])):
 a=accessor(orig,ob,i);c=accessor(actual,bb,i);assert np.array_equal(a,c) and np.isfinite(c).all();audit_access.append({'index':i,'count':len(a),'sha256_decoded_bytes':sha(a.tobytes()),'identical':True})
for im,ex in zip(actual['images'],images):
 v=actual['bufferViews'][im['bufferView']];assert sha(bb[v['byteOffset']:v['byteOffset']+v['byteLength']])==ex['derived_sha256']

from gltf_utils import matrix
components=[]
for ni,n in enumerate(orig['nodes']):
 p0=orig['meshes'][n['mesh']]['primitives'][0];a=accessor(orig,ob,p0['attributes']['POSITION']).astype('float64');idx=accessor(orig,ob,p0['indices']).ravel();m=matrix(n);world=(np.c_[a,np.ones(len(a))]@m.T)[:,:3];q=world+offset;tri=q[idx.reshape(-1,3)];area2=np.linalg.norm(np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]),axis=1)
 components.append({'node_index':ni,'source_node':n,'source_mesh':orig['meshes'][n['mesh']]['name'],'material_index':0,'vertices':len(a),'triangles':len(idx)//3,'all_vertices_referenced':len(np.unique(idx))==len(a),'zero_area_triangles':int((area2==0).sum()),'source_bounds_xyz_m':[world.min(0).tolist(),world.max(0).tolist()],'export_bounds_xyz_m':[q.min(0).tolist(),q.max(0).tolist()]})
after=bounds(measure(actual,bb));assert after['triangles']==21272 and abs(after['min_xyz_m'][2])<1e-12
# Planar triangles on the geometric rear envelope, no claim that they are anchor faces.
p0=orig['meshes'][1]['primitives'][0];body=accessor(orig,ob,p0['attributes']['POSITION']).astype('float64')+offset;indices=accessor(orig,ob,p0['indices']).ravel().reshape(-1,3);tr=body[indices];mask=np.max(np.abs(tr[:,:,2]),axis=1)<1e-6;faces=tr[mask];surface_area=float(np.linalg.norm(np.cross(faces[:,1]-faces[:,0],faces[:,2]-faces[:,0]),axis=1).sum()/2)
rear={'plane_export_z_m':0.,'plane_source_z_m':float(lo[2]),'definition':'Plane at minimum source body Z. Geometric rear envelope, not verified mounting surface or anchor specification.','coplanar_triangles_within_1_micrometre':int(mask.sum()),'coplanar_area_m2':surface_area,'body_vertex_z_quantiles_m':np.quantile(body[:,2],[0,.01,.1,.5,.9,.99,1]).tolist(),'vertices_within_1mm_of_plane':int((body[:,2]<=.001).sum())}
report={'source':meta['source'],'authors':meta['authors'],'license':meta['license'],'license_url':meta['license_url'],'source_archive':receipt,'source_files':audit,'source_bounds':before,'exported_bounds':after,'translation_xyz_m':offset.tolist(),'coordinate_system':'glTF right handed Y up, metres. Original scale preserved. +Z points out from proposed wall; X horizontally body-centered; Y vertically body-centered.','components':components,'material_0':actual['materials'][0],'material_mapping':'Both source meshes use material 0 power_box_01. Source primitive and node identities retained; no new component/material splits. Body includes case, breaker and hinge-related source geometry; door remains separately posed. Hardware/substrate identity beyond observable geometry is unverified.','pbr_semantics':'Base color texture index 1 sRGB; normal index 0 OpenGL tangent-space; packed ARM index 2 G roughness B metallic, both factors default 1. R preserved but source has no occlusionTexture binding; no AO binding added. Double-sided true retained. No source TANGENT accessor; importer may generate tangents.','geometry':{'original_buffer_bytes':len(ob),'byte_exact_source_geometry_prefix':True,'accessors':audit_access},'mounting_reference':rear,'clearance':{'fixed_open_pose_front_projection_from_rear_plane_m':after['max_xyz_m'][2],'body_front_projection_m':components[1]['export_bounds_xyz_m'][1][2],'door_projection_z_min_max_m':[components[0]['export_bounds_xyz_m'][0][2],components[0]['export_bounds_xyz_m'][1][2]],'door_left_overhang_beyond_body_m':components[1]['export_bounds_xyz_m'][0][0]-components[0]['export_bounds_xyz_m'][0][0],'note':'Bounds describe only shipped static pose, not a swept door-opening clearance or safe access requirement. Rear minimum is zero, so no geometry goes behind reference plane. No additional clearance or mounting standoff invented.'},'images':images,'glb_bytes':len(r),'glb_sha256':sha(r),'memory_estimates':{'three_RGB8_1k_base_bytes':3*1024*1024*3,'three_RGBA8_1k_base_bytes':3*1024*1024*4,'three_RGBA8_full_mips_approx_bytes':3*1024*1024*4*4/3,'notes':'Not measured runtime VRAM; engine compression, mips, generated tangents and overhead vary.'},'limits':['No verified wall bolts, anchors, mounting holes, wall substrate, load capacity, sheet gauge or physical thickness.','No new geometry, braces, conduits, supports, colliders, LODs, animation or engine integration. Source open-door pose stays static.','Rendered visible fastener-like marks may be texture or geometric details; not certified mounting hardware.','No weatherproofing or electrical safety claim. Best treated as visual sheltered service-wall detail.','Review cameras, lights and floor are external only and are not inside GLB.','Original albedo can contain captured shading; no perfect de-lighting claim.']}
(R/'qa/verification.json').write_text(json.dumps(report,indent=2));print(json.dumps({'bounds':after,'glb_bytes':len(r),'glb_sha256':sha(r),'translation':offset.tolist(),'rear':rear},indent=2))
