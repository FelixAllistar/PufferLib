import json,sys,numpy as np
from pathlib import Path
from gltf_utils import accessor
root=Path(__file__).resolve().parents[1];p=root/'source/power_box_01';d=json.loads((p/'power_box_01_2k.gltf').read_text());b=(p/'power_box_01.bin').read_bytes();a=accessor(d,b,4).astype(float);i=accessor(d,b,7).reshape(-1,3);t=a[i];ar=np.linalg.norm(np.cross(t[:,1]-t[:,0],t[:,2]-t[:,0]),axis=1)/2;flat=np.ptp(t[:,:,2],axis=1)<1e-6
zs=np.round(t[:,:,2].mean(1),6);out=[]
for z in np.unique(zs[flat]):
 mask=flat & (zs==z);area=ar[mask].sum()
 if area>.001:out.append({'source_z_m':float(z),'export_z_m':float(z+.04748108983039856),'area_m2':float(area),'triangles':int(mask.sum()),'xyz_bounds':[t[mask].reshape(-1,3).min(0).tolist(),t[mask].reshape(-1,3).max(0).tolist()]})
(root/'qa/body_parallel_planes.json').write_text(json.dumps({'note':'Triangle patch areas geometrically parallel to XY, grouping Z rounded to 1 micrometre. Not physical sheet gauges, contact/load-bearing faces, or verified attachment geometry.','planes':out},indent=2));print(json.dumps(sorted(out,key=lambda x:-x['area_m2'])[:5],indent=2))
