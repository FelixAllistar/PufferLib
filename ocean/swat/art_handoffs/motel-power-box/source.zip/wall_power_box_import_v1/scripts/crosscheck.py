from pathlib import Path
import json,numpy as np
R=Path(__file__).resolve().parents[1];v=json.loads((R/'qa/verification.json').read_text());b=json.loads((R/'qa/blender_import_verification.json').read_text())['power_box_01'];rows=[]
for c in v['components']:
 x=next(x for x in b['meshes'] if x['name']==c['source_node']['name']);lo,hi=np.array(c['export_bounds_xyz_m']);expected_lo=np.array([lo[0],-hi[2],lo[1]]);expected_hi=np.array([hi[0],-lo[2],hi[1]]);delta=float(max(np.max(np.abs(np.array(x['min_xyz_m'])-expected_lo)),np.max(np.abs(np.array(x['max_xyz_m'])-expected_hi))));assert delta<1e-6;assert x['triangles']==c['triangles'] and x['vertices']==c['vertices'];rows.append({'name':x['name'],'max_bound_difference_m':delta,'triangles_match':True,'vertices_match':True})
assert len(b['images'])==3 and all(i['dimensions']==[1024,1024] and i['packed'] for i in b['images']);(R/'qa/crosscheck.json').write_text(json.dumps({'passed':True,'blender_version':b['blender_version'],'components':rows,'three_packed_1k_images':True},indent=2));print('PASS')
