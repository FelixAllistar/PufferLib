# Briar Court realistic maintenance candidates

Four original Poly Haven CC0 assets, downloaded 2026-10-10 with 2K glTF PBR materials. All original files were verified against publisher MD5 hashes; SHA-256 values are in manifest.json.

Recommended cohesive set from The Shed: Metal Tool Chest, Plastic Monobloc Chair 01, Power Box 01. Utility Box 01 is an optional additional candidate from Hidden Alley. No existing game assets were changed.

Sources: https://polyhaven.com/collections/the_shed and https://polyhaven.com/collections/hidden_alley
License: https://polyhaven.com/license (CC0; commercial reuse and redistribution permitted without attribution). Authors and exact dimensions/mesh counts recorded in manifest.json.

Import original glTF files at their stored meter scale. Textures include diffuse, OpenGL normal, packed ambient-occlusion/roughness/metallic. The power box and tool chest source pages advertise rigs, but the glTF export should be treated as static until articulation is verified in the destination engine. Collision, LOD and game integration remain to be done. No photogrammetry claim is made: these are original realistic PBR modeled assets.

Official website previews elsewhere in the research directory are QA references only and are NOT part of the CC0 asset download or the deliverable ZIP. Newly rendered previews are made from these actual downloaded assets.
