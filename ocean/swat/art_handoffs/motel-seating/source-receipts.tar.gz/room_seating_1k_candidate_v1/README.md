# Briar Court seating: separate 1K runtime texture-budget candidate

Review candidate only. No accepted asset, source file, engine integration, geometry, material assignment, transform, pivot, sampler or scene hierarchy was changed. Original 2K imports remain the fallback. These are existing Poly Haven furniture assets, with downsampled textures, not repainted or generated furniture.

## Contents and exact sizes

| Asset | Triangles / primitives | Original 2K GLB | Separate 1K GLB |
|---|---|---:|---:|
| modern_arm_chair_01 | 8,916 / 2 materials | 9,219,972 bytes | 4,516,812 bytes |
| vintage_day_bed | 2,715 / 1 mixed material | 8,806,840 bytes | 4,718,392 bytes |
| Total | 11,631 / 3 | 18,026,812 bytes | 9,235,204 bytes |

Chair frame and upholstery keep their original two primitives. Daybed wood, upholstery and feet remain one mixed primitive. No semantic split was invented. The chair source describes warm oak and black leather cushions. “fabric_detail” render filenames mean upholstery detail and do not assert that the chair is fabric.

## Logical texture budget, not measured performance

Nine unique maps total: six chair maps and three daybed maps. This is the shared unique texture allocation for both assets, not an allocation per placed instance. Repeated instances can share these resources if the engine caches them; unique material or texture duplicates could allocate more. Assuming RGBA8, full residency, and complete mip chains through 1×1:

- Original 2K: 201,326,580 bytes, approximately 192 MiB (chair 128 MiB, daybed 64 MiB).
- Candidate 1K: 50,331,636 bytes, approximately 48 MiB (chair 32 MiB, daybed 16 MiB).
- Approximately 75% lower logical texture allocation under these assumptions.
- Optional selection: 1K chair (~32 MiB) plus original 2K daybed (~64 MiB) totals ~96 MiB shared unique RGBA8 full-mip allocation. This is a selection from the existing packages, not a new mixed package or an accepted automatic LOD policy.

These are pixel-count calculations, not measured GPU VRAM, FPS, peak RAM or target-engine profiling. PNG is disk encoding, not GPU compression. Runtime compression, mip streaming/residency, generated tangents, CPU copies, importer overhead and per-resource padding are unmeasured. GLBs contain only the full-resolution image; the destination engine must generate its mip chain. No BC7/ASTC/KTX2 conversion was performed.

## Deterministic texture recipe

All original embedded JPEGs are decoded once to RGB; output is lossless 8-bit RGB PNG, compression level 9, optimize false, no ICC metadata. Two repeated builds produce identical GLB SHA-256 values with the recorded Python, NumPy and Pillow versions.

Each 2048×2048 image becomes exactly 1024×1024 using a 2×2 area mean, without sharpening:

- Base color: decode IEC sRGB into linear light, average, convert to IEC sRGB, round to nearest 8-bit. Import this map as sRGB.
- ARM: linear arithmetic average independently in R/G/B. Source R=AO remains present but deliberately UNBOUND because the source glTF has no occlusionTexture. G=roughness and B=metallic retain their original binding. Import this image as non-color/linear.
- OpenGL tangent normal: decode RGB UNORM into [-1,1], normalize each source vector, average 2×2, renormalize, encode RGB UNORM. +Y orientation unchanged. Import as normal/non-color. This is ordinary normalized-vector downsampling, not a roughness-compensated normal-variance workflow; glancing highlight changes remain possible.

Quantization clips to [0,255] and uses NumPy rint. PNG’s lossless encoding prevents an additional JPEG lossy pass, but cannot restore information already lost in the source JPEG or during downsampling. Image MIME changes to image/png; all materials, texture references and samplers remain exact copies. No baked AO or material tweaks were introduced.

## QA and visual comparison

`qa/validation.json` records every original and derived image’s dimensions, MIME, byte size and distinct SHA-256; decoded derived RGB hashes; exact accessor comparison; index-range checks; triangle counts; original/candidate GLB hashes; and unchanged transformed bounds. Every non-image bufferView and all geometry bytes are preserved exactly. All accessors are finite, in buffer range, and equal to the original. Material/texture/image/sampler references resolve. `qa/independent_verification.json` cross-checks source geometry and source image hashes independently, including preserved unbound AO content.

`renders/` contains actual exported 2K versus 1K GLBs imported into Blender, with paired close front/back and upholstery/wood detail views. Same cameras, world, lighting, 24-sample Cycles seed, no denoising, AgX, and 1000×900 resolution for both versions. The floor and lights are review staging and are not embedded. These renders are visual evidence, not engine or physical testing. `qa/blender_comparison.json` records imported image sizes and camera matching.

Quality recommendation is in `qa/visual_review.md`. Keep the 2K option for hero inspection if finish detail matters. No collider, collision, physical stability or engine-performance validation is implied.

## Frozen originals and provenance

- [Original verified seating import backup (2K)](https://drive.google.com/file/d/139CgHyyKTQvbtnZ5QKVrRudeiDK4REyw/view)
- [Original source backup](https://drive.google.com/file/d/12jZ50cqpWrWQCnmQlAsymlOm1rO5Plyv/view)
- Original assets: [Modern Arm Chair 01](https://polyhaven.com/a/modern_arm_chair_01), Vibrant Nordic; [Vintage Day Bed](https://polyhaven.com/a/vintage_day_bed), Aron Łyczek.
- [Poly Haven license](https://polyhaven.com/license): CC0. The source metadata, original manifest and readable license are preserved in `provenance/`.

This package intentionally does not duplicate 2K GLBs or the original source ZIP. The original import/source backups remain authoritative. Source archive bytes and SHA-256 are recorded in `provenance/source_archive.json`; original GLB hashes are in `qa/validation.json`.

## Rebuild

Extract the original seating backup so `room_seating_imports_v1/` is a sibling of this candidate directory. For independent source verification, extract the source backup into sibling `worn_room_recovery/source/worn_room_furnishings_v1/`. Scripts require Python, NumPy, Pillow, and Blender for rendering. Runtime versions are recorded in QA.

Run `python scripts/build_candidate.py`, `python scripts/verify_candidate.py`, and `blender -b -t 8 --python scripts/render_compare.py` from this candidate directory. Candidate GLBs are self-contained; rebuilding and original comparison need the external frozen backups. `checksums.sha256` covers the candidate package files.
