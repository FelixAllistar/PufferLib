# Visual review: 2K originals versus 1K candidates

## Recommendation

- Chair: reasonable 1K trial for ordinary room staging in the shown views. Leather folds, seam/wear marks, warm wood character and back-panel grain remain credible. Fine leather grain and wood pores are visibly smoother in the detail pair. Keep the original 2K for close hero inspection and glancing-light checks.
- Daybed: 1K remains credible at the shown whole-prop front/back size, but is a weaker close-inspection choice. The floral cloth weave, pillow weave and small wood markings visibly soften in the detail views. Keep 2K for near-camera owner-suite inspection where this finish detail matters; treat 1K as a room-distance candidate only.
- A conservative mixed selection is 1K chair plus original 2K daybed: approximately 96 MiB shared unique RGBA8 full-mip allocation (32 + 64 MiB). No extra mix package was created, and no automatic LOD policy is accepted.
- No claim of visual equivalence or a measured speedup. No asset has been integrated or substituted. Actual engine camera distance, screen resolution, lighting and mip filtering must decide the runtime selection.

## What was inspected

All eight matched comparisons: chair and daybed, each front, back, upholstery detail, and wood/edge detail. Each pair is rendered from the actual 2K JPEG GLB and actual 1K lossless-PNG candidate, with identical camera, lighting, resolution, renderer and seed. The wooden-edge daybed close-up also shows the pillow prominently, making its high-frequency loss easy to see.

Macro color and folds remain consistent. The normal-map resize retains broad curvature but loses fine surface relief. Source ARM R stays present but unbound, so no new ambient-occlusion darkening is introduced. No invented repainting, color grading, photo compositing, or geometry additions were used.

These are 24-sample, non-denoised Cycles comparisons; some path noise remains and should not be mistaken for surface texture or a precise quality metric. Numerical image differences are informational, not an acceptance threshold. JPEG contact/pair sheets are conveniences; inspect the full original PNG render pairs for detailed decisions. Chair front/back are close-framed, with small extremities clipped by framing; geometry/bounds preservation is separately verified, not inferred from this crop.

## Selection constraints

The daybed retains its original single mixed primitive/material; wood, cloth and feet cannot independently select texture resolution through material assignment without an additional change outside this candidate. Chair frame and upholstery remain the original two material primitives. This package provides whole-prop 1K variants only, not a mixed-resolution or compressed variant.

Logical full-mip RGBA8 estimate is approximately 48 MiB for all nine unique candidate maps, shared across both asset types if the engine reuses their resources. This is not a per-instance texture allocation. Original 2K fallback is approximately 192 MiB under the same assumptions. Neither figure is measured VRAM, FPS, import RAM or engine profiling.
