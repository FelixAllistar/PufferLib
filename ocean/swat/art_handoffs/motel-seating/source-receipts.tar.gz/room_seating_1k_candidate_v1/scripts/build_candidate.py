import json,struct,copy,io,hashlib,platform
from pathlib import Path
import numpy as np
from PIL import Image, __version__ as pillow_version
from gltf_utils import accessor,measure,bounds
ROOT=Path(__file__).resolve().parents[1]; ORIGINAL=ROOT.parent/'room_seating_imports_v1/imports'
def sha(b):return hashlib.sha256(b).hexdigest()
def read(p):
 raw=p.read_bytes();magic,ver,total=struct.unpack_from('<III',raw);assert(magic,ver,total)==(0x46546c67,2,len(raw));n,t=struct.unpack_from('<II',raw,12);assert t==0x4e4f534a;d=json.loads(raw[20:20+n]);bn,bt=struct.unpack_from('<II',raw,20+n);assert bt==0x004e4942;binary=raw[28+n:];assert len(binary)==bn;return d,binary,raw
report={'recipe':{'filter':'Exact 2x2 area mean, float64, no sharpening','base_color':'Decode IEC sRGB to linear RGB, area average, encode IEC sRGB','arm':'Linear channel-wise area average; R=source AO retained but unbound, G=roughness, B=metallic','normal':'Decode RGB UNORM to [-1,1], normalize source vectors, average 2x2, normalize result, encode RGB UNORM; OpenGL +Y retained','quantization':'nearest 8-bit via numpy.rint, clip [0,255]','encoding':'RGB PNG lossless compress_level=9, optimize=False; no ICC metadata','versions':{'python':platform.python_version(),'numpy':np.__version__,'pillow':pillow_version}},'assets':[]}
for aid,expected in [('modern_arm_chair_01',8916),('vintage_day_bed',2715)]:
 original=ORIGINAL/(aid+'_floor_centered_2k.glb');d,b,raw=read(original);new=copy.deepcopy(d);imageviews={im['bufferView'] for im in d['images']};start=min(d['bufferViews'][i]['byteOffset'] for i in imageviews);out=b[:start];rows=[]
 for i,im in enumerate(d['images']):
  v=d['bufferViews'][im['bufferView']];data=b[v['byteOffset']:v['byteOffset']+v['byteLength']];img=Image.open(io.BytesIO(data));assert img.size==(2048,2048);pixels=np.asarray(img.convert('RGB'),dtype=np.float64)/255;name=im['name'];kind='normal' if 'nor_gl' in name else 'base_color' if 'diff' in name else 'arm'
  if kind=='base_color':pixels=np.where(pixels<=.04045,pixels/12.92,((pixels+.055)/1.055)**2.4)
  if kind=='normal':
   pixels=pixels*2-1;pixels/=np.maximum(np.linalg.norm(pixels,axis=2,keepdims=True),1e-20)
  small=pixels.reshape(1024,2,1024,2,3).mean(axis=(1,3))
  if kind=='base_color':small=np.where(small<=.0031308,small*12.92,1.055*np.maximum(small,0)**(1/2.4)-.055)
  if kind=='normal':
   norm=np.linalg.norm(small,axis=2,keepdims=True);assert norm.min()>1e-8;small=small/norm*.5+.5
  quant=np.clip(np.rint(small*255),0,255).astype('uint8');buf=io.BytesIO();Image.fromarray(quant,'RGB').save(buf,format='PNG',compress_level=9,optimize=False);derived=buf.getvalue();assert sha(data)!=sha(derived)
  out+=b'\0'*(-len(out)%4);new['bufferViews'][im['bufferView']]={'buffer':0,'byteOffset':len(out),'byteLength':len(derived)};out+=derived;new['images'][i]['mimeType']='image/png';rows.append({'index':i,'name':name,'kind':kind,'original':{'bytes':len(data),'sha256':sha(data),'mime':'image/jpeg','dimensions':[2048,2048]},'derived':{'bytes':len(derived),'sha256':sha(derived),'decoded_rgb_sha256':sha(quant.tobytes()),'mime':'image/png','dimensions':[1024,1024]}})
 out+=b'\0'*(-len(out)%4);new['buffers']=[{'byteLength':len(out)}];j=json.dumps(new,separators=(',',':')).encode();j+=b' '*(-len(j)%4);glb=struct.pack('<III',0x46546c67,2,28+len(j)+len(out))+struct.pack('<II',len(j),0x4e4f534a)+j+struct.pack('<II',len(out),0x004e4942)+out;dest=ROOT/'imports'/(aid+'_floor_centered_1k_candidate.glb');dest.write_bytes(glb);nd,nb,nraw=read(dest)
 for k in set(d)-{'images','buffers','bufferViews'}:assert nd[k]==d[k],k
 for i,v in enumerate(d['bufferViews']):
  if i not in imageviews:assert nd['bufferViews'][i]==v and nb[v.get('byteOffset',0):v.get('byteOffset',0)+v['byteLength']]==b[v.get('byteOffset',0):v.get('byteOffset',0)+v['byteLength']]
 ars=[]
 for i,a in enumerate(nd['accessors']):
  v=nd['bufferViews'][a['bufferView']];arr=accessor(nd,nb,i);old=accessor(d,b,i);assert np.array_equal(arr,old) and np.isfinite(arr).all();stride=v.get('byteStride',arr.dtype.itemsize*arr.shape[1]);assert a.get('byteOffset',0)+(a['count']-1)*stride+arr.dtype.itemsize*arr.shape[1]<=v['byteLength'];ars.append({'index':i,'count':a['count'],'decoded_sha256':sha(arr.tobytes()),'exact_match':True})
 for mesh in nd['meshes']:
  for p in mesh['primitives']:
   assert p.get('mode',4)==4 and 0<=p['material']<len(nd['materials']);pos=accessor(nd,nb,p['attributes']['POSITION']);idx=accessor(nd,nb,p['indices']);assert idx.min()>=0 and idx.max()<len(pos) and idx.size%3==0
   for ai in p['attributes'].values():assert len(accessor(nd,nb,ai))==len(pos)
 for m in nd['materials']:
  assert 'occlusionTexture' not in m
  for slot in [m['normalTexture'],m['pbrMetallicRoughness']['baseColorTexture'],m['pbrMetallicRoughness']['metallicRoughnessTexture']]:
   tx=nd['textures'][slot['index']];assert 0<=tx['source']<len(nd['images']);assert 0<=tx['sampler']<len(nd['samplers'])
 for im,row in zip(nd['images'],rows):
  v=nd['bufferViews'][im['bufferView']];ib=nb[v['byteOffset']:v['byteOffset']+v['byteLength']];ii=Image.open(io.BytesIO(ib));assert ii.size==(1024,1024) and ii.format=='PNG' and sha(ib)==row['derived']['sha256']
 bo=bounds(measure(nd,nb));assert bo==bounds(measure(d,b)) and bo['triangles']==expected;assert original.read_bytes()==raw
 report['assets'].append({'asset':aid,'original_file':str(original.relative_to(ROOT.parent)),'candidate_file':str(dest.relative_to(ROOT)),'original_bytes':len(raw),'candidate_bytes':len(glb),'original_sha256':sha(raw),'candidate_sha256':sha(glb),'geometry_prefix_bytes':start,'geometry_prefix_sha256':sha(nb[:start]),'bounds':bo,'primitives':len(nd['meshes'][0]['primitives']),'accessors':ars,'images':rows,'checks':'All original nodes, transforms, pivots, scenes, meshes, material routing, samplers and accessors unchanged. All geometry bufferViews byte-exact; indices valid; all image dimensions, MIME and hashes verified. Source AO R retained; no occlusion slot added.'})
report['logical_texture_memory_not_measured']={'allocation_scope':'Shared nine unique maps across both assets, not per placed instance; runtime resource sharing is engine-dependent','format_assumption':'9 fully resident RGBA8 textures, each complete square mip chain through 1x1; no compression, overhead or runtime residency model','original_2k_bytes':9*4*sum(4**i for i in range(12)),'candidate_1k_bytes':9*4*sum(4**i for i in range(11)),'original_approx_mib':192,'candidate_approx_mib':48,'reduction_percent':75,'caveat':'Logical estimate only, not measured VRAM, FPS, import RAM, engine performance or GPU compression. PNG is file encoding, not GPU compression.'}
(ROOT/'qa/validation.json').write_text(json.dumps(report,indent=2));print(json.dumps([{k:a[k] for k in ['asset','original_bytes','candidate_bytes']} for a in report['assets']],indent=2))
