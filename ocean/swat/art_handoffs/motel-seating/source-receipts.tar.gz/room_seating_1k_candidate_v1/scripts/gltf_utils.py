import json,struct,hashlib,copy
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parent
SRC=ROOT/'source/worn_room_furnishings_v1/originals'; OUT=ROOT/'output'
def sha(b):return hashlib.sha256(b).hexdigest()
def accessor(d,b,i):
 a=d['accessors'][i];v=d['bufferViews'][a['bufferView']];dt={5126:'<f4',5123:'<u2',5125:'<u4',5121:'u1'}[a['componentType']];n={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4}[a['type']];offset=v.get('byteOffset',0)+a.get('byteOffset',0);return np.ndarray((a['count'],n),dtype=dt,buffer=b,offset=offset,strides=(v.get('byteStride',np.dtype(dt).itemsize*n),np.dtype(dt).itemsize)).copy()
def matrix(n):
 if 'matrix' in n:return np.array(n['matrix']).reshape(4,4).T
 x,y,z,w=n.get('rotation',[0,0,0,1]);m=np.eye(4);m[:3,:3]=np.array([[1-2*(y*y+z*z),2*(x*y-z*w),2*(x*z+y*w)],[2*(x*y+z*w),1-2*(x*x+z*z),2*(y*z-x*w)],[2*(x*z-y*w),2*(y*z+x*w),1-2*(x*x+y*y)]])@np.diag(n.get('scale',[1]*3));m[:3,3]=n.get('translation',[0]*3);return m
def measure(d,b):
 rows=[]
 def walk(i,parent):
  n=d['nodes'][i];m=parent@matrix(n)
  if 'mesh' in n:
   pts=[];tri=0
   for p in d['meshes'][n['mesh']]['primitives']:
    a=accessor(d,b,p['attributes']['POSITION']);pts.append((np.c_[a,np.ones(len(a))]@m.T)[:,:3]);idx=accessor(d,b,p['indices']).ravel();assert idx.max()<len(a);assert np.isfinite(a).all();assert len(idx)%3==0;tri+=len(idx)//3
   pts=np.concatenate(pts);lo=pts.min(0);hi=pts.max(0);rows.append({'node':n['name'],'mesh':d['meshes'][n['mesh']]['name'],'triangles':tri,'material_indices':[p['material'] for p in d['meshes'][n['mesh']]['primitives']],'min_xyz_m':lo.tolist(),'max_xyz_m':hi.tolist(),'dimensions_width_height_depth_m':(hi-lo).tolist()})
  for ch in n.get('children',[]):walk(ch,m)
 for i in d['scenes'][d.get('scene',0)]['nodes']:walk(i,np.eye(4))
 return rows
def bounds(rows):
 lo=np.min([r['min_xyz_m'] for r in rows],0);hi=np.max([r['max_xyz_m'] for r in rows],0);return {'min_xyz_m':lo.tolist(),'max_xyz_m':hi.tolist(),'dimensions_width_height_depth_m':(hi-lo).tolist(),'triangles':sum(r['triangles'] for r in rows)}
