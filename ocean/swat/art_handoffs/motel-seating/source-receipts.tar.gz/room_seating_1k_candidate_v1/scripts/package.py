from pathlib import Path
import hashlib,zipfile,json
root=Path(__file__).resolve().parents[1]
files=sorted(p for p in root.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.name!='checksums.sha256')
(root/'checksums.sha256').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.relative_to(root).as_posix()+'\n' for p in files))
out=root.parent/'briar_court_seating_1k_candidate_v1.zip'
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(files+[root/'checksums.sha256']):z.write(p,p.relative_to(root.parent))
with zipfile.ZipFile(out) as z:
 assert z.testzip() is None
 for line in (root/'checksums.sha256').read_text().splitlines():
  h,n=line.split('  ',1);assert hashlib.sha256(z.read(root.name+'/'+n)).hexdigest()==h
print(json.dumps({'archive':str(out),'bytes':out.stat().st_size,'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'checksum_entries':len(files),'zip_crc_and_all_manifest_hashes':'PASS'},indent=2))
