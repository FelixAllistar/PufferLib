from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import json,numpy as np
root=Path(__file__).resolve().parents[1];font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',26);metrics=[]
for aid in ['modern_arm_chair_01','vintage_day_bed']:
 sheets=[]
 for view in ['front','back','fabric_detail','wood_detail']:
  paths=[root/'renders'/(aid+'_'+view+'_'+v+'.png') for v in ['2k','1k']]
  if not all(p.exists() for p in paths):continue
  ims=[Image.open(p).convert('RGB') for p in paths];a,b=[np.asarray(im,dtype=float) for im in ims];delta=a-b;metrics.append({'asset':aid,'view':view,'RGB8_mean_absolute_difference':float(np.abs(delta).mean()),'RGB8_RMSE':float(np.sqrt(np.square(delta).mean())),'note':'Render difference is not a perceptual acceptance test; stochastic path changes can add noise.'})
  sheet=Image.new('RGB',(2000,954),'#15191e');draw=ImageDraw.Draw(sheet)
  for x,im,label in [(0,ims[0],'Original 2K'),(1000,ims[1],'Candidate 1K')]:sheet.paste(im,(x,54));draw.text((x+20,12),aid+' · '+view+' · '+label,font=font,fill='white')
  sheet.save(root/'renders'/(aid+'_'+view+'_comparison.jpg'),quality=95,subsampling=0);sheets.append(sheet)
 if len(sheets)==4:
  contact=Image.new('RGB',(800,1528),'#15191e')
  for i,s in enumerate(sheets):contact.paste(s.resize((800,382)),(0,i*382))
  contact.save(root/'renders'/(aid+'_comparison_contact.jpg'),quality=94,subsampling=0)
(root/'qa/render_differences.json').write_text(json.dumps(metrics,indent=2))
