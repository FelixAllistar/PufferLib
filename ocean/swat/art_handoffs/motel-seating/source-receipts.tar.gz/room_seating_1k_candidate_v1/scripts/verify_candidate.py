import json,struct,hashlib,io
from pathlib import Path
from PIL import Image
import numpy as np
ROOT=Path(__file__).resolve().parents[1];SRC=ROOT.parent/'worn_room_recovery/source/worn_room_furnishings_v1';r=json.loads((ROOT/'qa/validation.json').read_text());checks=[]
def h(b):return hashlib.sha256(b).hexdigest()
def parse(p):
 b=p.read_bytes();assert struct.unpack_from('<III',b)==(0x46546c67,2,len(b));n,t=struct.unpack_from('<II',b,12);assert t==0x4e4f534a;j=json.loads(b[20:20+n]);bn,bt=struct.unpack_from('<II',b,20+n);assert bt==0x004e4942 and bn==len(b)-28-n;return j,b[28+n:]
for a in r['assets']:
 p=ROOT.parent/a['original_file'];q=ROOT/a['candidate_file'];assert h(p.read_bytes())==a['original_sha256'] and h(q.read_bytes())==a['candidate_sha256'];d,b=parse(p);n,z=parse(q);base=SRC/'originals'/a['asset'];s=json.loads((base/(a['asset']+'_2k.gltf')).read_text());geo=(base/s['buffers'][0]['uri']).read_bytes();assert b[:len(geo)]==z[:len(geo)]==geo
 for k in ['accessors','nodes','scenes','meshes','materials','textures','samplers']:assert n[k]==d[k]
 for m in n['materials']:assert 'occlusionTexture' not in m
 for im,old,row in zip(n['images'],s['images'],a['images']):
  original=(base/old['uri']).read_bytes();assert h(original)==row['original']['sha256'];v=n['bufferViews'][im['bufferView']];raw=z[v['byteOffset']:v['byteOffset']+v['byteLength']];pic=Image.open(io.BytesIO(raw));assert pic.size==(1024,1024) and pic.format=='PNG' and im['mimeType']=='image/png';assert h(raw)==row['derived']['sha256'] and h(np.asarray(pic).tobytes())==row['derived']['decoded_rgb_sha256']
  if row['kind']=='arm':
   # Independently verify all three channels, explicitly including source AO R.
   arr=np.asarray(Image.open(io.BytesIO(original)).convert('RGB'),dtype=np.float64);avg=np.rint(arr.reshape(1024,2,1024,2,3).mean(axis=(1,3))).astype('uint8');actual=np.asarray(pic);assert np.max(np.abs(avg.astype(int)-actual.astype(int)))<=1
 checks.append({'asset':a['asset'],'original_source_geometry_equal':True,'all_nine_original_map_hashes_match_source':True,'derived_images_decoded_and_hash_verified':True,'arm_including_unbound_ao_max_rounding_difference_lsb':1})
(ROOT/'qa/independent_verification.json').write_text(json.dumps(checks,indent=2));print('Independent source/geometry/images verification PASS')
