import bpy,json,pathlib
from mathutils import Vector
root=pathlib.Path(__file__).resolve().parents[1];out=root/'renders';reports={}
for aid in ['modern_arm_chair_01','vintage_day_bed']:
 for version,file in [('2k',root.parent/'room_seating_imports_v1/imports'/(aid+'_floor_centered_2k.glb')),('1k',root/'imports'/(aid+'_floor_centered_1k_candidate.glb'))]:
  bpy.ops.wm.read_factory_settings(use_empty=True);bpy.ops.import_scene.gltf(filepath=str(file));meshes=[o for o in bpy.context.scene.objects if o.type=='MESH'];scene=bpy.context.scene
  pts=[o.matrix_world@v.co for o in meshes for v in o.data.vertices];lo=Vector([min(v[i] for v in pts) for i in range(3)]);hi=Vector([max(v[i] for v in pts) for i in range(3)]);center=(lo+hi)/2;span=max(hi-lo)
  reports[aid+'_'+version]={'blender_version':bpy.app.version_string,'triangles':sum(len(o.data.polygons) for o in meshes),'images':[{'name':im.name,'size':list(im.size)} for im in bpy.data.images if im.type=='IMAGE'],'views':[]}
  scene.world=bpy.data.worlds.new('ReviewWorld');scene.world.use_nodes=True;scene.world.node_tree.nodes['Background'].inputs[0].default_value=(.14,.16,.18,1);scene.world.node_tree.nodes['Background'].inputs[1].default_value=.55
  bpy.ops.mesh.primitive_plane_add(size=20,location=(center.x,center.y,lo.z-.001));floor=bpy.context.object;mat=bpy.data.materials.new('ReviewFloor');mat.diffuse_color=(.12,.14,.16,1);floor.data.materials.append(mat)
  for pos,power,size in [((2,-3,4),600,3),((-3,-1,2),300,3),((0,3,3),500,2)]:
   bpy.ops.object.light_add(type='AREA',location=center+Vector(pos)*span);l=bpy.context.object;l.data.energy=power*span*span;l.data.size=size*span;l.rotation_euler=(center-l.location).to_track_quat('-Z','Y').to_euler()
  bpy.ops.object.camera_add();cam=bpy.context.object;cam.data.type='ORTHO';scene.camera=cam
  views=[('front',center,(1.5,-2.5,1.15),1.4),('back',center,(-1.5,2.5,1.15),1.4)]
  # Detail cameras use world targets derived solely from unchanged bounds.
  if aid=='modern_arm_chair_01':views += [('fabric_detail',Vector((center.x,center.y,lo.z+(hi.z-lo.z)*.65)),(1,-3,1.3),.52),('wood_detail',Vector((center.x+(hi.x-lo.x)*.32,center.y-(hi.y-lo.y)*.18,lo.z+(hi.z-lo.z)*.38)),(1.5,-3,1),.42)]
  else:views += [('fabric_detail',Vector((center.x,center.y,lo.z+(hi.z-lo.z)*.69)),(1,-3,2),.42),('wood_detail',Vector((center.x+(hi.x-lo.x)*.34,center.y-(hi.y-lo.y)*.32,lo.z+(hi.z-lo.z)*.48)),(1.5,-3,1.4),.36)]
  scene.render.engine='CYCLES';scene.cycles.samples=24;scene.cycles.seed=0;scene.cycles.use_animated_seed=False;scene.cycles.use_denoising=False;scene.render.resolution_x=1000;scene.render.resolution_y=900;scene.render.resolution_percentage=100;scene.render.image_settings.file_format='PNG';scene.view_settings.view_transform='AgX';scene.render.threads_mode='FIXED';scene.render.threads=8
  for name,target,offset,scale in views:
   cam.data.ortho_scale=span*scale;cam.location=target+Vector(offset)*span;cam.rotation_euler=(target-cam.location).to_track_quat('-Z','Y').to_euler();scene.render.filepath=str(out/(aid+'_'+name+'_'+version+'.png'));reports[aid+'_'+version]['views'].append({'view':name,'camera_location':list(cam.location),'target':list(target),'ortho_scale':cam.data.ortho_scale});bpy.ops.render.render(write_still=True)
(root/'qa/blender_comparison.json').write_text(json.dumps(reports,indent=2))
