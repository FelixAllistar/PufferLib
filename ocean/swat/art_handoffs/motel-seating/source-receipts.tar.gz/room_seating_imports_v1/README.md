# Briar Court: original seating imports, v1

Two additive, self-contained GLB props from the already downloaded Poly Haven 2K originals. No new downloads, scene replacements, decimation, texture resizing, repainting, fabricated furniture details, colliders or engine settings. Existing nightstand, suitcase and other accepted packages remain untouched.

## Imports and intended placement

| Import | Source author | Triangles | Actual width × depth × height, meters | GLB bytes |
| --- | --- | ---: | --- | ---: |
| imports/modern_arm_chair_01_floor_centered_2k.glb | Vibrant Nordic | 8,916 | 0.820344418 × 0.986561686 × 1.022852057 | 9,219,972 |
| imports/vintage_day_bed_floor_centered_2k.glb | Aron Łyczek | 2,715 | 1.972555220 × 0.854776144 × 1.127346540 | 8,806,840 |

The chair source describes a warm oak frame and black leather cushions. The daybed is an OPTIONAL owner/long-stay furnishing, not a standard guest bed replacement. Descriptions are source/visual character, not verified physical material specifications. Review the actual export renders before selecting for the room's era and style.

All dimensions are full transformed vertex bounds of actual exported GLBs, not source metadata alone. Every position is referenced by indices. glTF is right-handed Y-up in meters. Import at scale 1 if the destination engine uses meters; do not independently scale child meshes. These units have not been checked against physical objects.

## Preservation and pivot policy

The GLBs are lossless containers, built directly from original glTF JSON and binary data. A new parent node encloses each source scene. Original mesh/node names, local transforms, index/accessor data, normals, UVs, materials, textures and samplers are unchanged. Original JPEG image bytes are embedded verbatim. Original geometry binary bytes occupy the unchanged beginning of each GLB binary chunk; appended image views and alignment padding follow them.

The parent centers the full horizontal AABB and moves its minimum Y to floor Y=0. No geometry or child transform is baked or edited.

| Asset | Parent X, Y, Z translation in meters | Export bounds minimum XYZ | Export bounds maximum XYZ |
| --- | --- | --- | --- |
| Chair | −0.003363475204, −0.000381595368, +0.082170888782 | −0.410172209144, 0, −0.493280842900 | +0.410172209144, 1.022852056747, +0.493280842900 |
| Daybed | −0.000001460314, +0.000006462074, +0.042065232992 | −0.986277610064, 0, −0.427388072014 | +0.986277610064, 1.127346540428, +0.427388072014 |

## Source components and material mapping

Chair source node 0 `modern_arm_chair_01` references mesh 0 `Cube.007`:
- Primitive 0: `modern_arm_chair_01_legs`, 5,608 triangles, 3,884 vertices; position/normal/UV accessors 0/1/2, index accessor 3. This is the original frame/legs material grouping, not an authored separate leg rig.
- Primitive 1: `modern_arm_chair_01_pillow`, 3,308 triangles, 1,967 vertices; position/normal/UV accessors 4/5/6, index accessor 7.

Daybed source node 0 `vintage_day_bed` references mesh 0 `bed.001`, primitive 0: `vintage_day_bed`, 2,715 triangles, 2,000 vertices; position/normal/UV accessors 0/1/2, index accessor 3. Frame, upholstery and feet are not separately authored node/primitive components; semantic separability has not been invented.

Each material retains its three original 2048×2048 JPEGs: diffuse/base color, OpenGL normal, and ARM. Original glTF uses ARM G for roughness and B for metallic; it does NOT author an occlusionTexture binding. We preserve that behavior rather than adding one. Every material/texture/image index, URI and image hash appears in the asset verification JSON. No normal-map flip or material reinterpretation is baked into the deliverable.

## Floor relationship, not physics validation

The floor plane is defined only by the lowest mesh vertex. Chair frame minimum height is 0; its cushion primitive minimum is 0.347104781 m. Daybed's single primitive minimum is 0. All source geometry remains intact.

A geometric sample audit finds four spatial groups near the floor for each prop. Method: unique transformed export vertices within 20 mm of floor, connected by horizontal distances of at most 80 mm. Chair group minimum heights are 0, 0.000000437, 0.000000437 and 0 m; 80 total unique vertices are within 1 mm of the floor. Daybed group minimum heights range from 0 to 0.000012382 m; 32 total unique vertices are within 1 mm. Exact group coordinates and bounds are in each QA JSON. These are vertex groups, not collision surfaces, real contact patches or physical support/stability tests. Tiny nonzero differences are preserved, not flattened.

Unknown: mass, center of mass, load rating, physical stability, real-world exact materials, measured seat/mattress usable dimensions, comfort and clearance requirements. No collider or engine-performance claim. AABB dimensions must not be interpreted as usable sleeping area.

## Memory estimates, not profiler measurements

| Asset | Original geometry buffer | JPEG payload | RGBA8 base textures | RGBA8 approximate full mip chain | Hypothetical BC7 full mip chain |
| --- | ---: | ---: | ---: | ---: | ---: |
| Chair | 240,728 bytes | 8,975,800 bytes | 96 MiB | 128 MiB | 32 MiB |
| Daybed | 80,292 bytes | 8,724,620 bytes | 48 MiB | 64 MiB | 16 MiB |

RGBA8 assumes 4 bytes per pixel; full mip estimates use ×4/3. BC7 assumes 1 byte per base pixel and offline transcoding, which has NOT been performed. JPEG disk size is not GPU texture memory. Geometry estimates exclude importer object overhead, generated tangents, vertex duplication, runtime draw data and CPU copies. Engine VRAM, import peak RAM and performance are unmeasured. Blender render logs describe that review process only and are not target-game profiling.

## QA evidence and review renders

- `qa/*_verification.json`: verified original SHA-256/MD5 values, full actual bounds, accessor hashes, index ranges, primitive maps, image bytes and estimated memory.
- `qa/blender_import_verification.json`: independent Blender import, triangle counts, loaded image dimensions and bounds. Blender uses Z-up: X=glTF X, Y=−glTF Z, Z=glTF Y.
- `qa/crosscheck.json`: independent Blender counts and bounds compared with the GLB parser.
- `renders/*_front.png`, `renders/*_back.png`: actual GLBs rendered in Blender with neutral studio floor and lighting. Front is glTF +Z / Blender −Y; reverse is the opposite. Review staging is not embedded in GLBs.
- `checksums.sha256`: hashes of deliverables and evidence.

Build scripts are included, but the rebuild is NOT self-contained: original source files are external dependencies. The GLB imports themselves are self-contained.

Verified original archive: https://drive.google.com/file/d/12jZ50cqpWrWQCnmQlAsymlOm1rO5Plyv/view

Place this package directory `room_seating_imports_v1` beside a directory named `worn_room_recovery`. Download the linked archive and extract its top-level `worn_room_furnishings_v1` directory into `worn_room_recovery/source/`. The resulting source manifest must be at `../worn_room_recovery/source/worn_room_furnishings_v1/manifest.json` relative to this package, and the original files under that directory's `originals/modern_arm_chair_01/` and `originals/vintage_day_bed/`. Match the downloaded archive SHA-256 against `provenance/source_archive.json` before rebuilding. Avoid an extra duplicate directory level when extracting.

Rebuild also requires Python with numpy/Pillow and Blender. Run `python scripts/build_seating.py`, `python scripts/measure_floor_samples.py`, `blender -b --python scripts/render_seating.py`, then `python scripts/crosscheck.py`. The source ZIP is intentionally not duplicated here.

## Sources and license

Both sources are CC0-1.0 per archived source provenance. Author credit is retained even though CC0 does not require attribution.
- Modern Arm Chair 01: https://polyhaven.com/a/modern_arm_chair_01
- Vintage Day Bed: https://polyhaven.com/a/vintage_day_bed
- Poly Haven license: https://polyhaven.com/license
- CC0 legal text: https://creativecommons.org/publicdomain/zero/1.0/

`provenance/` contains original metadata, file records and license snapshot. The original source manifest includes its other source-package entries for provenance only; those assets are not imports in this package. Source hashes are checked against the archived downloaded manifest, not represented as a fresh online verification.
