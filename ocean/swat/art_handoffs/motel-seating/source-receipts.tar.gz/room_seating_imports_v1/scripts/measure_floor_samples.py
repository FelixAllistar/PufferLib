import sys,json,numpy as np,struct
from pathlib import Path
from gltf_utils import accessor
root=Path(__file__).resolve().parents[1]
for aid in ['modern_arm_chair_01','vintage_day_bed']:
 p=root/'qa'/(aid+'_verification.json');r=json.loads(p.read_text());raw=(root/'imports'/(aid+'_floor_centered_2k.glb')).read_bytes();jn=struct.unpack_from('<I',raw,12)[0];g=json.loads(raw[20:20+jn]);b=raw[28+jn:]
 pts=np.concatenate([accessor(g,b,pr['attributes']['POSITION']) for m in g['meshes'] for pr in m['primitives']]).astype(float)+r['added_parent_translation_xyz_m'];near=np.unique(pts[pts[:,1]<=.02],axis=0);remaining=set(range(len(near)));groups=[]
 while remaining:
  seed=remaining.pop();component={seed};queue=[seed]
  while queue:
   i=queue.pop();ns={j for j in remaining if np.linalg.norm(near[i,[0,2]]-near[j,[0,2]])<=.08};remaining-=ns;component|=ns;queue+=list(ns)
  a=near[list(component)];groups.append({'vertices':len(a),'min_xyz_m':a.min(0).tolist(),'max_xyz_m':a.max(0).tolist(),'minimum_vertex_height_m':float(a[:,1].min()),'vertices_within_1mm':int(np.count_nonzero(a[:,1]<=.001))})
 r['near_floor_spatial_groups']={'method':'Actual exported GLB: unique world vertices at Y <= 0.020 m, clustered by transitive horizontal XZ distance <= 0.080 m. Geometric sample groups only; not semantic foot topology, surface contacts or support certification.','groups':sorted(groups,key=lambda x:x['min_xyz_m'])};p.write_text(json.dumps(r,indent=2))
