import sys, json, struct, copy, hashlib, io
from pathlib import Path
import numpy as np
from PIL import Image
from gltf_utils import accessor, matrix, measure, bounds, sha
ROOT=Path(__file__).resolve().parents[1]; SRC=ROOT.parent/'worn_room_recovery/source/worn_room_furnishings_v1'
manifest=json.loads((SRC/'manifest.json').read_text()); reports=[]
for aid,expected in [('modern_arm_chair_01',8916),('vintage_day_bed',2715)]:
 meta=next(a for a in manifest['assets'] if a['id']==aid)
 audit=[]
 for f in meta['files']:
  raw=(SRC/f['path']).read_bytes(); assert sha(raw)==f['sha256']; assert hashlib.md5(raw).hexdigest()==f['source_md5']; audit.append(dict(f,actual_bytes=len(raw),verified=True))
 p=SRC/'originals'/aid/(aid+'_2k.gltf'); original=json.loads(p.read_text()); d=copy.deepcopy(original); original_binary=(p.parent/d['buffers'][0]['uri']).read_bytes(); b=original_binary
 before=bounds(measure(d,b)); lo=np.array(before['min_xyz_m']);hi=np.array(before['max_xyz_m']);offset=-(lo+hi)/2;offset[1]=-lo[1]
 for scene in d['scenes']:
  roots=list(scene['nodes']);scene['nodes']=[len(d['nodes'])];d['nodes'].append({'name':aid+'_FloorCentered','translation':offset.tolist(),'children':roots})
 imgs=[]
 for i,im in enumerate(d['images']):
  uri=im.pop('uri');raw=(p.parent/uri).read_bytes();b+=b'\0'*((-len(b))%4);im['bufferView']=len(d['bufferViews']);d['bufferViews'].append({'buffer':0,'byteOffset':len(b),'byteLength':len(raw)});b+=raw
  img=Image.open(io.BytesIO(raw));imgs.append({'image_index':i,'name':im['name'],'source_uri':uri,'bytes':len(raw),'sha256':sha(raw),'width':img.width,'height':img.height,'source_mode':img.mode})
 b+=b'\0'*((-len(b))%4);d['buffers']=[{'byteLength':len(b)}];j=json.dumps(d,separators=(',',':')).encode();j+=b' '*((-len(j))%4)
 glb=struct.pack('<III',0x46546c67,2,28+len(j)+len(b))+struct.pack('<II',len(j),0x4e4f534a)+j+struct.pack('<II',len(b),0x004e4942)+b
 out=ROOT/'imports'/(aid+'_floor_centered_2k.glb');out.write_bytes(glb)
 r=out.read_bytes();magic,version,total=struct.unpack_from('<III',r);assert magic==0x46546c67 and version==2 and total==len(r);jn,jt=struct.unpack_from('<II',r,12);assert jt==0x4e4f534a;actual=json.loads(r[20:20+jn]);bn,bt=struct.unpack_from('<II',r,20+jn);actualb=r[28+jn:];assert bt==0x004e4942 and bn==len(actualb)
 assert actualb[:len(original_binary)]==original_binary
 for key in ['meshes','materials','accessors','textures','samplers','asset']:assert actual[key]==original[key]
 assert actual['nodes'][:len(original['nodes'])]==original['nodes'];assert actual['bufferViews'][:len(original['bufferViews'])]==original['bufferViews']
 assert not any('uri' in x for x in actual['buffers']+actual['images'])
 for im,ex in zip(actual['images'],imgs):
  v=actual['bufferViews'][im['bufferView']];assert sha(actualb[v['byteOffset']:v['byteOffset']+v['byteLength']])==ex['sha256']
 accessors=[]
 for i,a in enumerate(original['accessors']):
  ar=accessor(actual,actualb,i);ori=accessor(original,original_binary,i);assert np.array_equal(ar,ori) and np.isfinite(ar).all();accessors.append({'accessor_index':i,'count':a['count'],'type':a['type'],'componentType':a['componentType'],'decoded_array_sha256':sha(ar.tobytes()),'byte_exact':True})
 primitives=[];allpts=[]
 for ni,n in enumerate(original['nodes']):
  if 'mesh' not in n:continue
  assert not any(k in n for k in ['rotation','scale','translation','matrix','children']), 'Handle arbitrary node hierarchy explicitly if present.'
  for pi,pr in enumerate(original['meshes'][n['mesh']]['primitives']):
   assert pr.get('mode',4)==4
   pts=accessor(actual,actualb,pr['attributes']['POSITION']).astype('float64')+offset;idx=accessor(actual,actualb,pr['indices']).ravel();assert idx.min()>=0 and idx.max()<len(pts) and len(idx)%3==0
   assert len(np.unique(idx))==len(pts),'Unreferenced vertices require separate referenced bounds'
   allpts.append(pts);pl=pts.min(0);ph=pts.max(0);near=pts[pts[:,1]<=0.001+1e-10]
   a=pts[idx.reshape(-1,3)];area2=np.linalg.norm(np.cross(a[:,1]-a[:,0],a[:,2]-a[:,0]),axis=1)
   primitives.append({'node_index':ni,'node_name':n['name'],'mesh_index':n['mesh'],'mesh_name':original['meshes'][n['mesh']]['name'],'primitive_index':pi,'material_index':pr['material'],'material_name':original['materials'][pr['material']]['name'],'attributes':pr['attributes'],'index_accessor':pr['indices'],'triangles':len(idx)//3,'vertices':len(pts),'bounds_min_xyz_m':pl.tolist(),'bounds_max_xyz_m':ph.tolist(),'minimum_height_above_floor_m':float(pl[1]),'unique_vertices_within_1mm_floor':len(np.unique(near,axis=0)),'near_floor_vertex_coordinates_xyz_m':np.unique(near,axis=0).tolist(),'exact_zero_area_triangles':int(np.count_nonzero(area2==0))})
 after=bounds(measure(actual,actualb));assert after['triangles']==expected and abs(after['min_xyz_m'][1])<1e-10
 material_maps=[]
 for mi,ma in enumerate(actual['materials']):
  entries=[]
  for label,v in [('normal',ma.get('normalTexture')),('base_color',ma['pbrMetallicRoughness'].get('baseColorTexture')),('metallic_roughness',ma['pbrMetallicRoughness'].get('metallicRoughnessTexture')),('occlusion',ma.get('occlusionTexture'))]:
   if v:entries.append({'slot':label,'texture_index':v['index'],'image_index':actual['textures'][v['index']]['source']})
  material_maps.append({'material_index':mi,'name':ma['name'],'maps':entries,'note':'ARM source is used by original glTF only for roughness G and metallic B. No occlusionTexture is authored; it is deliberately not added.'})
 px=sum(im['width']*im['height'] for im in imgs);mib=1048576
 report={'id':aid,'author':meta['authors'],'license':meta['license'],'source':meta['source'],'license_url':meta['license_url'],'source_file_audit':audit,'coordinate_system':'glTF right-handed Y-up, meters; dimensions reported as X width, Y height, Z depth. Blender render/report uses X width, Y depth, Z height.','original_bounds':before,'exported_bounds':after,'added_parent_translation_xyz_m':offset.tolist(),'parent_policy':'Only scene-root parent translation added. Original nodes/transforms, accessors, meshes, material definitions, texture/sampler mappings and geometry/image bytes preserved. No baking, decimation, resizing, repainting or re-export via Blender.','primitives':primitives,'accessor_validation':accessors,'materials':material_maps,'images':imgs,'glb_bytes':len(r),'glb_sha256':sha(r),'memory_estimates_not_profiler_results':{'geometry_source_buffer_bytes':len(original_binary),'jpeg_encoded_image_bytes':sum(i['bytes'] for i in imgs),'RGBA8_texture_base_mib':px*4/mib,'RGBA8_full_mip_chain_approx_mib':px*4*4/3/mib,'BC7_all_textures_full_mips_approx_mib':px*4/3/mib,'notes':'GPU memory depends on engine formats, compression, mip residency, sampler and material handling. BC7 estimate assumes offline transcode that has NOT been performed. Original geometry buffer excludes importer overhead, tangents/vertex duplication, draw data and CPU copies. Actual VRAM and peak import RAM unmeasured.'},'checks':{'original_binary_prefix_identical':True,'source_file_sha256_and_md5_verified':True,'all_accessors_identical_and_finite':True,'indices_in_range':True,'all_vertices_referenced':True,'original_nodes_materials_meshes_texture_sampler_definitions_unchanged':True,'image_bytes_identical':True,'self_contained_no_external_uris':True,'triangle_count_matches':True},'physical_limitations':'Floor is the lowest mesh vertex plane, not a measured contact surface. Near-floor coordinates are geometric samples only. Weight, load rating, center of mass, stability, exact real-world materials and upholstery dimensions are unknown. No collider, collision fidelity, wall-clearance or physical-support validation claimed. Source units interpreted as meters, no physical object measured.','intended_use':'Optional owner/long-stay furnishing; not a standard guest bed replacement.' if aid=='vintage_day_bed' else 'Optional worn-room lounge seating; visual placement only.'}
 (ROOT/'qa'/(aid+'_verification.json')).write_text(json.dumps(report,indent=2));reports.append(report)
(ROOT/'qa/summary.json').write_text(json.dumps([{'id':r['id'],'bounds':r['exported_bounds'],'triangles':r['exported_bounds']['triangles'],'glb_bytes':r['glb_bytes'],'translation':r['added_parent_translation_xyz_m'],'primitives':[{'name':p['material_name'],'triangles':p['triangles'],'floor_min':p['minimum_height_above_floor_m'],'near_floor_unique':p['unique_vertices_within_1mm_floor']} for p in r['primitives']]} for r in reports],indent=2))
print((ROOT/'qa/summary.json').read_text())
