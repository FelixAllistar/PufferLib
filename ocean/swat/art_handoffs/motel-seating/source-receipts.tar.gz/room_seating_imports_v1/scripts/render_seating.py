import bpy,json,pathlib
from mathutils import Vector
root=pathlib.Path(__file__).resolve().parents[1];out=root/'renders';reports={}
for asset,file in [(aid,root/'imports'/(aid+'_floor_centered_2k.glb')) for aid in ['modern_arm_chair_01','vintage_day_bed']]:
 bpy.ops.wm.read_factory_settings(use_empty=True);bpy.ops.import_scene.gltf(filepath=str(file));meshes=[o for o in bpy.context.scene.objects if o.type=='MESH'];rows=[]
 for o in meshes:
  o.data.calc_loop_triangles();pts=[o.matrix_world@v.co for v in o.data.vertices];lo=Vector([min(v[i] for v in pts) for i in range(3)]);hi=Vector([max(v[i] for v in pts) for i in range(3)]);rows.append({'name':o.name,'triangles':len(o.data.loop_triangles),'vertices':len(o.data.vertices),'materials':[m.name for m in o.data.materials],'min_xyz_m':list(lo),'max_xyz_m':list(hi)})
 reports[asset]={'blender_version':bpy.app.version_string,'coordinates':'Blender Z-up; X width, Y depth, Z height','meshes':rows,'images':[{'name':im.name,'dimensions':list(im.size),'packed':bool(im.packed_file)} for im in bpy.data.images if im.type=='IMAGE']}
 scene=bpy.context.scene;scene.world=bpy.data.worlds.new('ReviewWorld');scene.world.use_nodes=True;scene.world.node_tree.nodes['Background'].inputs[0].default_value=(.14,.16,.18,1);scene.world.node_tree.nodes['Background'].inputs[1].default_value=.55
 groups=[(asset+'_front',meshes,(1.5,-2.5,1.15)),(asset+'_back',meshes,(-1.5,2.5,1.15))]
 for name,group,offset in groups:
  for o in meshes:o.hide_render=o not in group
  pts=[o.matrix_world@v.co for o in group for v in o.data.vertices];lo=Vector([min(v[i] for v in pts) for i in range(3)]);hi=Vector([max(v[i] for v in pts) for i in range(3)]);center=(lo+hi)/2;span=max(hi-lo)
  added=[];bpy.ops.mesh.primitive_plane_add(size=20,location=(center.x,center.y,lo.z-.001));floor=bpy.context.object;added.append(floor);mat=bpy.data.materials.new('ReviewFloor');mat.diffuse_color=(.12,.14,.16,1);floor.data.materials.append(mat)
  for pos,power,size in [((2,-3,4),600,3),((-3,-1,2),300,3),((0,3,3),500,2)]:
   bpy.ops.object.light_add(type='AREA',location=center+Vector(pos)*span);l=bpy.context.object;added.append(l);l.data.energy=power*span*span;l.data.size=size*span;l.rotation_euler=(center-l.location).to_track_quat('-Z','Y').to_euler()
  bpy.ops.object.camera_add();cam=bpy.context.object;added.append(cam);cam.data.type='ORTHO';cam.data.ortho_scale=span*1.7;scene.camera=cam;cam.location=center+Vector(offset)*span;cam.rotation_euler=(center-cam.location).to_track_quat('-Z','Y').to_euler()
  scene.render.engine='CYCLES';scene.cycles.samples=24;scene.cycles.use_denoising=False;scene.render.resolution_x=1000;scene.render.resolution_y=900;scene.render.resolution_percentage=100;scene.render.image_settings.file_format='PNG';scene.view_settings.view_transform='AgX';scene.render.filepath=str(out/(name+'.png'));bpy.ops.render.render(write_still=True)
  for o in added:bpy.data.objects.remove(o,do_unlink=True)
(root/'qa/blender_import_verification.json').write_text(json.dumps(reports,indent=2))
