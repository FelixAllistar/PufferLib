import json,numpy as np
from pathlib import Path
r=Path(__file__).resolve().parents[1];bl=json.loads((r/'qa/blender_import_verification.json').read_text());out=[]
for aid in ['modern_arm_chair_01','vintage_day_bed']:
 a=json.loads((r/'qa'/(aid+'_verification.json')).read_text());b=bl[aid];lo=np.min([m['min_xyz_m'] for m in b['meshes']],axis=0);hi=np.max([m['max_xyz_m'] for m in b['meshes']],axis=0);g=a['exported_bounds'];gl=np.array(g['min_xyz_m']);gh=np.array(g['max_xyz_m']);exlo=np.array([gl[0],-gh[2],gl[1]]);exhi=np.array([gh[0],-gl[2],gh[1]]);err=max(abs(lo-exlo).max(),abs(hi-exhi).max());tris=sum(m['triangles'] for m in b['meshes']);assert err<1e-6 and tris==g['triangles'];assert len(b['images'])==len(a['images']);assert all(x['dimensions']==[2048,2048] for x in b['images'])
 out.append({'id':aid,'independent_import_triangles':tris,'maximum_bound_disagreement_m':float(err),'bounds_tolerance_m':1e-6,'image_count':len(b['images']),'all_images_2048_square':True,'passed':True})
(r/'qa/crosscheck.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
