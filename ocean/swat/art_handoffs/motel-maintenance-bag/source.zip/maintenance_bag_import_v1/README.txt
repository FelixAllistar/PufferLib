MAINTENANCE PROP: POLY HAVEN TRASHBAG — SINGLE 1K IMPORT

Use imports/trashbag_floor_centered_1k.glb. One self-contained glTF 2.0 GLB,
4,482 triangles, 2,482 source accessor vertices, one mesh primitive/material.
3,134,116 bytes (2.989 MiB). No extra runtime variants.

SIZE AND ORIGIN
W × D × H: 0.5280700624 × 0.4628930092 × 0.5749993846 metres.
glTF XYZ: width × height × depth; original right-handed Y-up metre scale.
Exported bounds XYZ:
  minimum (-0.2640350312, 0, -0.2314465046)
  maximum (+0.2640350312, 0.5749993846, +0.2314465046)
One scene-root parent translates by
  (-0.003564551473, +0.001454167068, +0.008373320103) metres.
No rotation/scale, geometry baking, remeshing, decimation or UV change.
The origin is the XZ bounding-box center at minimum mesh-vertex Y=0.
This is a geometric floor relation, not a verified contact patch or stability.

SOURCE AND LICENSE
Trashbag by Benny Weimer, Poly Haven, CC0-1.0.
https://polyhaven.com/a/trashbag
https://polyhaven.com/license
The original glTF, BIN and three 2K JPGs are included unchanged under source/.
Their bytes were re-extracted from the existing licensed source archive,
then checked against its SHA-256 and MD5 manifest. No new source acquisition.
provenance/ contains captured metadata, file API evidence, CC0 text, original
manifest and source-only preview. The original manifest includes other assets;
only trashbag is included here. All exact hashes are in qa/verification.json
and checksums.sha256. The outer ZIP hash is supplied separately.

TEXTURES / PBR
Three 1024 × 1024 RGB8 lossless PNG derivatives, also embedded in the GLB:
- Color: exact 2×2 area mean after IEC sRGB decode, then sRGB re-encode.
- ARM: linear channel averaging; no roughness bias or repaint.
- OpenGL tangent normal: decode and normalize source vectors, average,
  normalize again and encode. 8-bit quantization causes tiny length errors.
Lossless refers to PNG storage; the resized images are derivatives and the
source images were JPEG. Source and derived hashes remain distinct.
Original material JSON is unchanged: double-sided, metallicFactor=0;
normal texture 0, base-color texture 1, metallic/roughness texture 2.
ARM green is roughness; blue is retained but metallicFactor stays zero.
Source has NO occlusionTexture binding: retained ARM red is not newly bound.
No source tangent accessor; the rendering engine generates tangents.
One node trashbag → mesh Plane.006 → primitive 0 → material trashbag.
Visible body and tied closure share that source primitive/material. No
independent tie, exposed waste, polymer or separate substrate is invented.
The source is intentionally shiny. Retain its gloss character and judge
highlights in engine lighting; this is not a uniformly matte plastic prop.

COSTS AND LIMITS
Source geometry buffer: 106,316 bytes before importer overhead.
Three RGB8 textures: 9 MiB base; RGBA8 upload: 12 MiB base, about 16 MiB with
full mip chains. Hypothetical BC7: about 4 MiB with full mips; NOT transcoded.
Actual GPU memory/CPU import peaks are unmeasured and depend on the engine.
No collider, LOD, damage setup or placement. Engine owns those decisions.
Bag polymer/gauge, contents, mass and closure construction are unverified.
No stability, collision fidelity, support or gameplay-route claim is made.
No lights, cameras or room lighting have been baked into the exported GLB.
Existing source albedo may contain captured shading; perfect de-lighting is
not claimed. Review floor/camera/lights exist only in the render script.

VERIFICATION / REVIEW
qa/verification.json records source-to-export checks, exact accessors and
indices, transformed bounds, material mapping and source/derived SHA-256.
qa/blender_import_verification.json independently records Blender import.
renders/ shows the actual exported GLB front, back and material close-up.
Front/back denote review views, not a manufacturer-defined front direction.
provenance/original_source_preview.png is separate from derivative renders.
scripts/ documents deterministic build and review. From any clean extraction,
run: python scripts/build.py
Requires Python 3, NumPy and Pillow; no network or original archive required.
The build reads bundled source/provenance only and never writes originals.
Clean-extraction rebuild verified byte-identical GLB and derived PNGs; details
and tested dependency versions are in qa/portable_rebuild.json.
No upload or engine scene change performed.
