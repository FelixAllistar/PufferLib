import json,hashlib,copy,struct,io
from pathlib import Path
import numpy as np
from PIL import Image
from gltf_utils import accessor,measure,bounds,sha
R=Path(__file__).resolve().parents[1]
# Read only bundled source/provenance. Never overwrite originals.
receipt=json.loads((R/'provenance/source_archive_receipt.json').read_text())
for directory in ['derived_textures','imports','qa']:(R/directory).mkdir(parents=True,exist_ok=True)
meta=next(x for x in json.loads((R/'provenance/manifest.json').read_text())['assets'] if x['id']=='trashbag'); audit=[]
for f in meta['files']:
 raw=(R/'source'/f['path']).read_bytes();assert len(raw)==f['bytes'] and sha(raw)==f['sha256'] and hashlib.md5(raw).hexdigest()==f['md5_verified'];audit.append(dict(f,verified_against_bundled_manifest=True))
p=R/'source/originals/trashbag/trashbag_2k.gltf';orig=json.loads(p.read_text());ob=(p.parent/'trashbag.bin').read_bytes();d=copy.deepcopy(orig);b=ob
before=bounds(measure(orig,ob));lo=np.array(before['min_xyz_m']);hi=np.array(before['max_xyz_m']);offset=-(lo+hi)/2;offset[1]=-lo[1]
roots=d['scenes'][0]['nodes'];d['scenes'][0]['nodes']=[len(d['nodes'])];d['nodes'].append({'name':'Trashbag_FloorCentered','translation':offset.tolist(),'children':roots})
def down(a):return a.reshape(1024,2,1024,2,3).mean(axis=(1,3))
images=[]
for im in d['images']:
 uri=im.pop('uri');raw=(p.parent/uri).read_bytes();a=np.asarray(Image.open(io.BytesIO(raw)).convert('RGB'),dtype=np.float64)/255;assert a.shape==(2048,2048,3)
 if '_diff_' in uri:
  linear=np.where(a<=.04045,a/12.92,((a+.055)/1.055)**2.4);v=down(linear);out=np.where(v<=.0031308,12.92*v,1.055*v**(1/2.4)-.055);method='IEC sRGB decode, exact 2x2 area mean in linear light, IEC sRGB encode'
 elif '_nor_gl_' in uri:
  v=a*2-1;v/=np.maximum(np.linalg.norm(v,axis=2,keepdims=True),1e-12);v=down(v);v/=np.maximum(np.linalg.norm(v,axis=2,keepdims=True),1e-12);out=v*.5+.5;method='Decode OpenGL tangent normals to [-1,1], normalize source vectors, exact 2x2 area mean, normalize resultant vectors, encode RGB'
 else:out=down(a);method='Linear non-color ARM exact 2x2 area mean; no roughness bias or repaint'
 quant=np.clip(np.rint(out*255),0,255).astype('uint8');name=Path(uri).name.replace('_2k.jpg','_1k.png');dest=R/'derived_textures'/name;Image.fromarray(quant).save(dest,compress_level=9);rr=dest.read_bytes();assert sha(rr)!=sha(raw)
 b+=b'\0'*(-len(b)%4);im['bufferView']=len(d['bufferViews']);im['mimeType']='image/png';d['bufferViews'].append({'buffer':0,'byteOffset':len(b),'byteLength':len(rr)});b+=rr
 item={'source_uri':uri,'source_sha256':sha(raw),'source_bytes':len(raw),'derived_path':'derived_textures/'+name,'derived_sha256':sha(rr),'derived_bytes':len(rr),'dimensions':[1024,1024],'method':method,'source_mean_rgb':a.mean((0,1)).tolist(),'derived_mean_rgb':(quant/255).mean((0,1)).tolist()}
 if '_nor_gl_' in uri:
  lengths=np.linalg.norm(quant/255*2-1,axis=2);item['quantized_vector_length_range']=[float(lengths.min()),float(lengths.max())]
 images.append(item)
b+=b'\0'*(-len(b)%4);d['buffers']=[{'byteLength':len(b)}];j=json.dumps(d,separators=(',',':')).encode();j+=b' '*(-len(j)%4);glb=struct.pack('<III',0x46546c67,2,28+len(j)+len(b))+struct.pack('<II',len(j),0x4e4f534a)+j+struct.pack('<II',len(b),0x004e4942)+b
out=R/'imports/trashbag_floor_centered_1k.glb';out.write_bytes(glb)
# Reopen actual final GLB, not in-memory source.
r=out.read_bytes();magic,version,total=struct.unpack_from('<III',r);assert (magic,version,total)==(0x46546c67,2,len(r));jl,jt=struct.unpack_from('<II',r,12);actual=json.loads(r[20:20+jl]);bl,bt=struct.unpack_from('<II',r,20+jl);bb=r[28+jl:];assert bl==len(bb) and jt==0x4e4f534a and bt==0x004e4942
assert bb[:len(ob)]==ob
for key in ['meshes','materials','textures','samplers','accessors','asset']:assert actual[key]==orig[key]
assert actual['nodes'][:-1]==orig['nodes'];assert actual['bufferViews'][:len(orig['bufferViews'])]==orig['bufferViews'];assert not any('uri' in x for x in actual['images']+actual['buffers'])
audit_access=[]
for i in range(len(orig['accessors'])):
 a=accessor(orig,ob,i);c=accessor(actual,bb,i);assert np.array_equal(a,c) and np.isfinite(c).all();audit_access.append({'index':i,'count':len(a),'sha256_decoded_bytes':sha(a.tobytes()),'identical':True})
for im,ex in zip(actual['images'],images):
 v=actual['bufferViews'][im['bufferView']];assert sha(bb[v['byteOffset']:v['byteOffset']+v['byteLength']])==ex['derived_sha256']
pts=accessor(actual,bb,0).astype('float64')+offset;idx=accessor(actual,bb,3).ravel();assert idx.min()>=0 and idx.max()<len(pts) and len(idx)//3==4482;assert len(np.unique(idx))==len(pts)
tri=pts[idx.reshape(-1,3)];area2=np.linalg.norm(np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]),axis=1);after=bounds(measure(actual,bb));assert abs(after['min_xyz_m'][1])<1e-12
report={'source':meta['source'],'author':meta['author'],'license':meta['license'],'license_url':meta['license_source'],'source_archive_sha256':receipt['sha256'],'source_archive_note':'Recorded initial extraction provenance; this rebuild validates bundled files against manifest without requiring archive access','source_files':audit,'source_bounds':before,'exported_bounds':after,'dimensions_width_depth_height_m':[after['dimensions_width_height_depth_m'][0],after['dimensions_width_height_depth_m'][2],after['dimensions_width_height_depth_m'][1]],'translation_xyz_m':offset.tolist(),'coordinate_system':'glTF right handed Y up, metres. Source scale unchanged; dimensions X width/Y height/Z depth. Not physically measured.','geometry':{'vertices':len(pts),'triangles':len(idx)//3,'original_geometry_buffer_bytes':len(ob),'byte_exact_source_geometry_prefix':True,'accessors':audit_access,'all_vertices_referenced':True,'indices_in_range':True,'zero_area_triangles':int((area2==0).sum()),'vertices_within_1mm_floor':np.unique(pts[pts[:,1]<=.001],axis=0).tolist()},'mapping':{'node_0':'trashbag','mesh_0':'Plane.006','primitive_0':'One source primitive, material 0 trashbag; includes visible bag and tied closure in the same mesh/material. No independent tie or waste substrate assignment.','material_0':actual['materials'][0],'semantics':'Original definitions preserved. Double-sided; metallicFactor 0. Normal OpenGL tangent RGB; base color sRGB; ARM G roughness. No authored occlusionTexture; R retained but not newly bound. B retained but metallicFactor 0 remains. No source TANGENT accessor; renderer generates tangents.'},'images':images,'glb_bytes':len(r),'glb_sha256':sha(r),'memory_estimates':{'RGB8_base_bytes':3*1024*1024*3,'RGBA8_base_bytes':3*1024*1024*4,'RGBA8_full_mips_approx_bytes':3*1024*1024*4*4/3,'BC7_full_mips_approx_bytes':3*1024*1024*4/3,'notes':'Estimates only, not measured VRAM. No BC7 transcode performed. Engine importer overhead, CPU copies, generated tangents, mip residency and compression vary.'},'limits':['Floor relation means minimum transformed vertex Y=0, not proven contact footprint or stability.','Original source is intentionally shiny; highlights remain responsive to lighting. No arbitrary roughness dulling.','Polymer, gauge, weight, contents and separate closure construction are unverified.','No collider, damage setup, placement or room-light baking. Engine owns placement, damage and collision.','No new lights or cameras exist in GLB; review lights and floor are external only. Existing source albedo may contain captured shading; no claim of perfect de-lighting.']}
(R/'qa/verification.json').write_text(json.dumps(report,indent=2));print(json.dumps({'bounds':after,'glb_bytes':len(r),'glb_sha256':sha(r),'translation':offset.tolist()},indent=2))
