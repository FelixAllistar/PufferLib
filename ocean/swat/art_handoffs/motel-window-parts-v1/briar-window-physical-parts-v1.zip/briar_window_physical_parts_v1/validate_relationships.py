"""Independent runtime-only convex-interior overlap witnesses, stdlib Python 3."""
import json,struct,math
from pathlib import Path
p=Path(__file__).resolve().parent;d=json.loads((p/'physical_parts.json').read_text());rel=json.loads((p/'relationships.json').read_text())
def positions(name):
 raw=(p/'reference_originals/assets'/f'{name}.glb').read_bytes();off=12;chunks={}
 while off<len(raw):
  n,t=struct.unpack_from('<II',raw,off);chunks[t]=raw[off+8:off+8+n];off+=8+n
 j=json.loads(chunks[0x4e4f534a]);b=chunks[0x004e4942]
 def acc(i):
  a=j['accessors'][i];v=j['bufferViews'][a['bufferView']];fmt='<'+{5126:'f',5125:'I',5123:'H',5121:'B'}[a['componentType']]*{'SCALAR':1,'VEC3':3}[a['type']];sz=struct.calcsize(fmt)
  return [struct.unpack_from(fmt,b,v.get('byteOffset',0)+a.get('byteOffset',0)+k*v.get('byteStride',sz)) for k in range(a['count'])]
 result={}
 for mi,m in enumerate(j['meshes']):
  for pi,pr in enumerate(m['primitives']):
   vs=[(x,-z,y) for x,y,z in acc(pr['attributes']['POSITION'])];ii=[v[0] for v in acc(pr['indices'])];result[mi,pi]=[[vs[k] for k in ii[i:i+3]] for i in range(0,len(ii),3)]
 return result
sub=lambda a,b:[x-y for x,y in zip(a,b)]
dot=lambda a,b:sum(x*y for x,y in zip(a,b))
cross=lambda a,b:[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]]
def margin(c,w,ts):
 center=c['source_center_xyz_m'];dist=[]
 for m in c['triangle_mappings']:
  for start,end in m['triangle_ranges_half_open']:
   for tri in ts[m['mesh_index'],m['primitive_index']][start:end]:
    a,b,e=tri;n=cross(sub(b,a),sub(e,a));ln=math.sqrt(dot(n,n));assert ln>0;n=[x/ln for x in n]
    if dot(n,sub(center,a))>0:n=[-x for x in n]
    dist.append(-dot(n,sub(w,a)))
 return min(dist)
cs={c['component_id']:c for a in d['assets'] for c in a['components']};ts=positions('room_window_insert');checks=[]
for r in rel['relationships']:
 a,b=cs[r['a']],cs[r['b']];w=[(max(a['source_aabb_xyz_m'][0][k],b['source_aabb_xyz_m'][0][k])+min(a['source_aabb_xyz_m'][1][k],b['source_aabb_xyz_m'][1][k]))/2 for k in range(3)]
 ma,mb=margin(a,w,ts),margin(b,w,ts);assert min(ma,mb)>2e-6
 checks.append(dict(a=r['a'],b=r['b'],source_xyz_interior_witness_m=w,minimum_inward_face_distance_m=min(ma,mb)))
print(json.dumps(dict(passed=True,method='A strictly interior common point satisfies every oriented convex-solid triangle half-space of both unchanged original GLB components. These are generator-evidenced convex beveled boxes. This proves positive volume overlap, not only AABB intersection.',checks=checks),indent=2))
