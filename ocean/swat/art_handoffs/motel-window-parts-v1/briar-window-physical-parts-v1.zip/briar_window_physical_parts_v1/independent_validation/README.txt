Independent verification of original window physical-part mapping.
Requires Blender, Python 3, NumPy, and SciPy for relationship validation.
Run from this folder, substituting ORIGINAL_DIR and PACKET_DIR:
blender -b -t 1 --python-exit-code 1 --python export_source.py -- ORIGINAL_DIR source.json
python verify.py ORIGINAL_DIR PACKET_DIR source.json
python relationships.py PACKET_DIR source.json

Export reads original Blender only. Verification independently parses original GLBs, checks recorded hashes, CSV/JSON cell equality, connected-island membership, source materials/tags/AABBs, primitive-local exact coverage, position and UV corners, directed polygon boundaries, and signed area conservation. Overlap validation uses independently reconstructed source convex hulls. Scripts write report.json and relationships_report.json beside themselves. source.json is a derived read-only extraction for checks, not replacement art. No original inputs are written.
