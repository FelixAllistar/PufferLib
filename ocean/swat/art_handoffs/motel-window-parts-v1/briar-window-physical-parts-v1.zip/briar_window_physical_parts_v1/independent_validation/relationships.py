import json,sys,numpy as np
from scipy.spatial import ConvexHull
from pathlib import Path
base,source=map(Path,sys.argv[1:]); d=json.load(open(base/'physical_parts.json'));s=json.load(open(source));r=json.load(open(base/'relationships.json'));cs={c['component_id']:c for a in d['assets'] for c in a['components']}
def pts(c):return np.array(s[c['original_object_name']]['vertices'])[c['source_vertex_indices']]
def overlap(c,b):
 aa=np.array(c['source_aabb_xyz_m']);bb=np.array(b['source_aabb_xyz_m']);lo=np.maximum(aa[0],bb[0]);hi=np.minimum(aa[1],bb[1]);witness=(lo+hi)/2
 assert np.all(hi>lo)
 # Source vertex convex hull halfspaces differ from primitive-range logic; every source solid is convex.
 residual=[]
 for cc in [c,b]:
  eq=ConvexHull(pts(cc)).equations;maxv=float(np.max(eq[:,:3]@witness+eq[:,3]));assert maxv<0;residual.append(maxv)
 return (hi-lo).tolist(),min(-x for x in residual)
checks=[]
for rel in r['relationships']:
 c,b=cs[rel['a']],cs[rel['b']];extent,margin=overlap(c,b);assert np.allclose(extent,rel['aabb_overlap_xyz_m'],atol=1e-12);checks.append({'a':rel['a'],'b':rel['b'],'witness_interior_margin_m':margin})
lob=next(a for a in d['assets'] if a['asset_id']=='lobby_glazed_facade');panes=[c for c in lob['components'] if c['render_material']=='MC15_glass'];rails=[c for c in lob['components'] if c['original_part_name']=='glazed_panels' and c['render_material']=='MC15_cream']
for c in rails:
 for b in panes:
  extent,margin=overlap(c,b);assert abs(extent[1]-.0155)<1e-6;checks.append({'a':c['component_id'],'b':b['component_id'],'witness_interior_margin_m':margin})
report={'strict_interior_overlap_checks':len(checks),'checks':checks}; print(json.dumps(report,indent=2));(Path(__file__).parent/'relationships_report.json').write_text(json.dumps(report,indent=2))
