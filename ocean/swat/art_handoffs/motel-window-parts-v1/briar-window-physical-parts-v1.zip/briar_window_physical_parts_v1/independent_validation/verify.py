import json,csv,struct,hashlib,collections,itertools,sys
from pathlib import Path
import numpy as np
ROOT,P,SOURCE=map(Path,sys.argv[1:]); d=json.load(open(P/'physical_parts.json')); source=json.load(open(SOURCE))
for path,want in d['source_hashes'].items(): assert hashlib.sha256((ROOT/path).read_bytes()).hexdigest()==want,path
csvrows=list(csv.DictReader(open(P/'physical_parts.csv'))); records=[{'asset_id':a['asset_id'],**c} for a in d['assets'] for c in a['components']]
assert len(csvrows)==len(records)==75
for cr,jr in zip(csvrows,records):
 assert cr.keys()==jr.keys()
 for k,v in jr.items(): assert cr[k]==(json.dumps(v) if isinstance(v,(list,dict)) or v is None else str(v)),(k,cr[k],v)
report={'hashes_verified':len(d['source_hashes']),'csv_json_rows':len(records),'assets':[]}
for a in d['assets']:
 name=a['asset_id'];s=source[name]; raw=(ROOT/'assets'/f'{name}.glb').read_bytes(); magic,version,length=struct.unpack_from('<III',raw); assert magic==0x46546c67 and version==2 and length==len(raw)
 jlen,jtype=struct.unpack_from('<II',raw,12); j=json.loads(raw[20:20+jlen]); offset=20+jlen;blen,btype=struct.unpack_from('<II',raw,offset); binary=raw[offset+8:offset+8+blen]
 def accessor(ai):
  acc=j['accessors'][ai];bv=j['bufferViews'][acc['bufferView']];dt={5126:'<f4',5125:'<u4',5123:'<u2',5121:'u1'}[acc['componentType']];n={'SCALAR':1,'VEC2':2,'VEC3':3}[acc['type']];sz=np.dtype(dt).itemsize;return np.ndarray((acc['count'],n),dtype=dt,buffer=binary,offset=bv.get('byteOffset',0)+acc.get('byteOffset',0),strides=(bv.get('byteStride',sz*n),sz)).copy()
 assert np.allclose(s['matrix_world'],np.eye(4),atol=0)
 for node in j['nodes']: assert not set(node)&{'matrix','rotation','scale','translation'}
 xyz=np.array(s['vertices']); transformed=xyz[:,[0,2,1]]*np.array([1,1,-1]);components=a['components']; vertex_owners={}; polygon_owners={};maxerr=0; polytris=collections.defaultdict(list)
 for ci,c in enumerate(components):
  vs=c['source_vertex_indices'];pis=c['source_polygon_indices'];assert len(set(vs))==len(vs)
  for v in vs: assert v not in vertex_owners;vertex_owners[v]=ci
  for pi in pis: assert pi not in polygon_owners;polygon_owners[pi]=ci;assert set(s['polygons'][pi])<=set(vs);assert s['polymats'][pi]==c['render_material']
  assert {g for v in vs for g in s['groups'][v]}=={c['original_part_name']}
  points=xyz[vs];assert np.allclose([points.min(0),points.max(0)],c['source_aabb_xyz_m'],atol=1e-12)
  assert abs((points.max(0)-points.min(0))[1]-c['modeled_depth_y_m'])<1e-12
  assert c['physical_fabrication_thickness_m'] is None
  if c['render_material'] in ['MC15_teal','MC15_cream']: assert c['physical_material'] is None
 assert sorted(vertex_owners)==list(range(len(xyz))) and sorted(polygon_owners)==list(range(len(s['polygons'])))
 # Independently compute graph components, checking each supplied island connected and isolated.
 adj=collections.defaultdict(set)
 for x,y in s['edges']:adj[x].add(y);adj[y].add(x);assert vertex_owners[x]==vertex_owners[y]
 for c in components:
  visited=set(); stack=[c['source_vertex_indices'][0]]
  while stack:
   v=stack.pop()
   if v in visited: continue
   visited.add(v);stack.extend(adj[v]-visited)
  assert visited==set(c['source_vertex_indices'])
 ntotal=0; primstats=[]
 for mi,m in enumerate(j['meshes']):
  for pi,p in enumerate(m['primitives']):
   assert p.get('mode',4)==4
   ids=accessor(p['indices']).ravel(); assert len(ids)%3==0
   pos=accessor(p['attributes']['POSITION']);uv=accessor(p['attributes']['TEXCOORD_0']);tri=ids.reshape(-1,3);counts=np.zeros(len(tri),int)
   for ci,c in enumerate(components):
    for mapping in c['triangle_mappings']:
     if (mapping['mesh_index'],mapping['primitive_index'])!=(mi,pi):continue
     assert c['render_material']==j['materials'][p['material']]['name']
     tids=[]
     for start,end in mapping['triangle_ranges_half_open']:assert 0<=start<end<=len(tri);tids.extend(range(start,end));counts[start:end]+=1
     assert len(tids)==mapping['triangle_count']
     for ti in tids:
      tv=pos[tri[ti]];tu=uv[tri[ti]]; matches=[]
      for spi in c['source_polygon_indices']:
       sv=s['polygons'][spi];sp=transformed[sv];su=np.array(s['polygon_uvs'][spi]);su[:,1]=1-su[:,1]
       distances=np.max(np.abs(tv[:,None,:]-sp[None,:,:]),axis=2);ud=np.max(np.abs(tu[:,None,:]-su[None,:,:]),axis=2);both=np.maximum(distances,ud);best=both.argmin(1)
       if np.max(both[np.arange(3),best])<2e-6:matches.append((spi,best.tolist(),float(np.max(both[np.arange(3),best]))))
      assert len(matches)==1,(name,mi,pi,ti,matches)
      spi,corners,error=matches[0];maxerr=max(maxerr,error);polytris[spi].append(corners)
   assert np.all(counts==1),(name,pi,np.unique(counts,return_counts=True));ntotal+=len(tri);primstats.append(len(tri))
 for spi,sv in enumerate(s['polygons']):
  ts=polytris[spi];assert len(ts)==len(sv)-2
  # Check signed area conservation and shared-edge direction as well as boundary incidence.
  edgecounts=collections.Counter((t[k],t[(k+1)%3]) for t in ts for k in range(3)); boundary={(k,(k+1)%len(sv)) for k in range(len(sv))}
  assert all(edgecounts[e]==1 and edgecounts[e[::-1]]==0 for e in boundary)
  for e,count in edgecounts.items():
   if e not in boundary:assert count==1 and edgecounts[e[::-1]]==1
  sp=xyz[sv]; area=sum((np.cross(sp[t[1]]-sp[t[0]],sp[t[2]]-sp[t[0]]) for t in ts),start=np.zeros(3));polyarea=sum((np.cross(sp[k],sp[(k+1)%len(sp)]) for k in range(len(sp))),start=np.zeros(3));assert np.allclose(area,polyarea,atol=1e-10)
 assert ntotal==a['triangle_count']==sum(c['triangle_count'] for c in components)
 for c in components: assert c['triangle_count']==sum(m['triangle_count'] for m in c['triangle_mappings'])
 report['assets'].append({'asset':name,'triangles':ntotal,'components':len(components),'primitive_triangles':primstats,'max_coordinate_uv_error':maxerr,'source_polygons':len(s['polygons']),'signed_tessellation_checks':True})
print(json.dumps(report,indent=2));(Path(__file__).parent/'report.json').write_text(json.dumps(report,indent=2))
