import bpy,json,sys
from pathlib import Path
root,out=map(Path,sys.argv[sys.argv.index("--")+1:])
bpy.ops.wm.open_mainfile(filepath=str(root/'motor_court_motel.blend'))
r={}
for name in ['room_window_insert','lobby_glazed_facade']:
 o=bpy.data.objects[name]; m=o.data
 r[name]={'matrix_world':[list(row) for row in o.matrix_world],'vertices':[list(v.co) for v in m.vertices],'polygons':[list(p.vertices) for p in m.polygons], 'polymats':[m.materials[p.material_index].name for p in m.polygons],'groups':[[o.vertex_groups[g.group].name for g in v.groups if g.weight>0] for v in m.vertices], 'edges':[list(e.vertices) for e in m.edges], 'polygon_uvs':[[list(m.uv_layers.active.data[li].uv) for li in p.loop_indices] for p in m.polygons]}
open(out,'w').write(json.dumps(r))
