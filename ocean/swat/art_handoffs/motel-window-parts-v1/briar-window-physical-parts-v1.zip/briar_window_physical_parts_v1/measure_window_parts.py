"""Read-only analysis: blender -b -t 1 --python-exit-code 1 --python measure_window_parts.py -- ORIGINAL OUTPUT"""
import bpy,sys,json,struct,hashlib,csv
from pathlib import Path
from collections import defaultdict,Counter
root,out=map(Path,sys.argv[sys.argv.index('--')+1:]);out.mkdir(parents=True,exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
inputs=['motor_court_motel.blend','build_motel.py','geometry_core.py','README.md','manifest.json','assembly_manifest.json','assets/room_window_insert.glb','assets/lobby_glazed_facade.glb']
hashes={p:sha(root/p) for p in inputs}
def read_glb(path):
 raw=path.read_bytes(); chunks={};off=12
 while off<len(raw):
  n,t=struct.unpack_from('<II',raw,off);chunks[t]=raw[off+8:off+8+n];off+=8+n
 j=json.loads(chunks[0x4e4f534a]);b=chunks[0x004e4942]
 def acc(i):
  a=j['accessors'][i];v=j['bufferViews'][a['bufferView']]; assert 'sparse' not in a
  fmt='<'+{5126:'f',5125:'I',5123:'H',5121:'B'}[a['componentType']]*{'SCALAR':1,'VEC2':2,'VEC3':3}[a['type']];sz=struct.calcsize(fmt);start=v.get('byteOffset',0)+a.get('byteOffset',0)
  return [struct.unpack_from(fmt,b,start+k*v.get('byteStride',sz)) for k in range(a['count'])]
 for n in j['nodes']:assert not any(k in n for k in ['matrix','translation','rotation','scale'])
 ps=[]
 for mi,m in enumerate(j['meshes']):
  for pi,p in enumerate(m['primitives']):
   assert p.get('mode',4)==4;v=acc(p['attributes']['POSITION']);uv=acc(p['attributes']['TEXCOORD_0']);vs=[tuple(a)+tuple(c) for a,c in zip(v,uv)];ix=[x[0] for x in acc(p['indices'])]
   ps.append(dict(mesh_index=mi,primitive_index=pi,index_accessor=p['indices'],material_name=j['materials'][p['material']]['name'],triangles=[tuple(vs[x] for x in ix[k:k+3]) for k in range(0,len(ix),3)]))
 return j,ps

def ranges(ids):
 r=[]
 for i in sorted(ids):
  if r and r[-1][1]==i:r[-1][1]+=1
  else:r.append([i,i+1])
 return r
bpy.ops.wm.open_mainfile(filepath=str(root/'motor_court_motel.blend'))
def plain(v):
 if hasattr(v,'items'):return {k:plain(x) for k,x in v.items()}
 if not isinstance(v,(str,int,float,bool,type(None))):return [plain(x) for x in v]
 return v
assets=[]
for name in ['room_window_insert','lobby_glazed_facade']:
 o=bpy.data.objects[name];assert tuple(o.location)==(0,0,0);assert not o.modifiers
 mesh=o.data; adj=defaultdict(set)
 for e in mesh.edges:
  a,b=e.vertices;adj[a].add(b);adj[b].add(a)
 remain=set(range(len(mesh.vertices))); islands=[]
 while remain:
  todo=[min(remain)];got=set()
  while todo:
   v=todo.pop()
   if v in got:continue
   got.add(v);todo.extend(adj[v]-got)
  remain-=got;islands.append(sorted(got))
 owner={v:i for i,vs in enumerate(islands) for v in vs};records=[];source={};corner=defaultdict(set)
 for i,vs in enumerate(islands):
  points=[tuple(mesh.vertices[v].co) for v in vs];lo=[min(v[k] for v in points) for k in range(3)];hi=[max(v[k] for v in points) for k in range(3)];ext=[hi[k]-lo[k] for k in range(3)]
  groups={o.vertex_groups[g.group].name for v in vs for g in mesh.vertices[v].groups if g.weight>0};assert len(groups)==1;group=next(iter(groups))
  mats={mesh.materials[p.material_index].name for p in mesh.polygons if p.vertices[0] in vs};assert len(mats)==1;mat=next(iter(mats))
  kind='frame_or_header_member';physical=None;ev='Paint/color alone does not establish substrate.';gauge=None
  if mat=='MC15_glass':kind='pane_render_solid';physical='glass, composition/treatment unspecified';ev='build_motel.py window()/lobby_facade() names panes/glazed_panels and assigns glass; physical fabrication gauge unspecified.'
  elif mat=='MC15_cloth':kind='curtain_fold_render_solid';physical='cloth, fibre/weave unspecified';ev='build_motel.py window() curtain_folds and cloth palette. Solid boxes represent folds, not fabric gauge.'
  elif mat=='MC15_steel':physical='steel, alloy and finish unspecified';ev='build_motel.py window() explicitly assigns steel to central divider; hollow profile/gauge unspecified.'
  if group=='lettering':kind='lettering_render_bar';ev='build_motel.py label() merges pixel lettering into 9 mm-deep box bars; ink, paint, applique or sign substrate unspecified.'
  if group=='sill':kind='sill_render_solid'
  records.append(dict(component_id=f'{name}:island_{i:03d}',original_object_name=name,original_part_name=group,original_part_name_kind='original vertex-group tag; source has no separately named object for each solid',derived_component_label=f'{group}/island_{i:03d}',source_vertex_indices=vs,source_aabb_xyz_m=[lo,hi],source_extent_xyz_m=ext,source_center_xyz_m=[(a+b)/2 for a,b in zip(lo,hi)],component_kind=kind,render_material=mat,physical_material=physical,material_evidence=ev,modeled_depth_y_m=ext[1],physical_fabrication_thickness_m=None,thickness_status='measured solid/proxy envelope; not evidence of fabrication gauge',measurement_uncertainty_m=2e-6,collider=None,collision_enabled=None,render_binding=None,destruction_binding=None,physics_volume_assignment=None))
 for p in mesh.polygons:
  ids={owner[v] for v in p.vertices};assert len(ids)==1;ii=next(iter(ids));attrs=[]
  for li in p.loop_indices:
   v=mesh.vertices[mesh.loops[li].vertex_index].co;uv=mesh.uv_layers.active.data[li].uv;attrs.append((v.x,v.z,-v.y,uv.x,1-uv.y))
  source[p.index]=dict(island=ii,corners=attrs,triangles=[])
  for a in attrs:corner[tuple(round(x,5) for x in a[:3])].add(p.index)
 j,ps=read_glb(root/'assets'/f'{name}.glb');maps=defaultdict(list);err=0
 for p in ps:
  for ti,vs in enumerate(p['triangles']):
   cand=set.intersection(*(corner[tuple(round(x,5) for x in v[:3])] for v in vs))
   cand=[s for s in cand if all(any(max(abs(a-b) for a,b in zip(v,w))<2e-6 for w in source[s]['corners']) for v in vs)]
   assert len(cand)==1,(name,ti,cand);s=source[cand[0]];ct=[min(range(len(s['corners'])),key=lambda k:max(abs(a-b) for a,b in zip(v,s['corners'][k]))) for v in vs];s['triangles'].append(ct)
   err=max(err,max(max(abs(a-b) for a,b in zip(v,s['corners'][ci])) for v,ci in zip(vs,ct)))
   maps[(s['island'],p['mesh_index'],p['primitive_index'])].append(ti)
 for s in source.values():
  n=len(s['corners']);ts=s['triangles'];assert len(ts)==n-2;assert len(set(tuple(sorted(t)) for t in ts))==len(ts)
  edges=Counter(tuple(sorted((t[k],t[(k+1)%3]))) for t in ts for k in range(3));boundary={tuple(sorted((k,(k+1)%n))) for k in range(n)}
  assert {e for e,c in edges.items() if c==1}==boundary;assert all(c==(1 if e in boundary else 2) for e,c in edges.items())
 for i,r in enumerate(records):
  r['source_polygon_indices']=[k for k,s in source.items() if s['island']==i];r['triangle_mappings']=[]
  for (ii,mi,pi),ts in maps.items():
   if ii==i:r['triangle_mappings'].append(dict(mesh_index=mi,primitive_index=pi,triangle_ranges_half_open=ranges(ts),triangle_count=len(ts)))
  r['triangle_count']=sum(x['triangle_count'] for x in r['triangle_mappings'])
 coverage=[]
 for p in ps:
  ids=[t for (ii,mi,pi),ts in maps.items() if mi==p['mesh_index'] and pi==p['primitive_index'] for t in ts];assert sorted(ids)==list(range(len(p['triangles'])))
  coverage.append({k:v for k,v in p.items() if k!='triangles'}|dict(triangle_count=len(ids),complete_disjoint=True))
 assets.append(dict(asset_id=name,glb_sha256=hashes[f'assets/{name}.glb'],original_mesh_name=mesh.name,triangle_count=sum(len(p['triangles']) for p in ps),component_count=len(records),maximum_matching_error=err,coverage=coverage,components=records,original_materials=j['materials'],source_connections=plain(o.get('connections',[]))))
assert hashes=={p:sha(root/p) for p in inputs}
result=dict(schema='briar_window_physical_parts_addendum_v1',units='metres',source_basis='Blender Z-up, front -Y',gltf_basis='Y-up: (x,y,z) source -> (x,z,-y) glTF; UV (u,v)->(u,1-v)',index_convention='Zero-based mesh/primitive-local triangle IDs; triangle t reads index accessor offsets [3t,3t+3). Half-open ranges exclude end. No vertex reordering or geometry changes.',source_hashes=hashes,source_archive_sha256='92896091ee009a131cf76e73e0e3c6f94e543bb9e50debda797f89568c213fb3',assets=assets)
result['source_archive_url']='https://drive.google.com/file/d/1MceTtpBriTUP1-0nvkMC58f8iZG4INVX/view?usp=drivesdk'
result['license']='CC0-1.0'
(out/'physical_parts.json').write_text(json.dumps(result,indent=2)+'\n')
fields=['asset_id']+list(assets[0]['components'][0])
with (out/'physical_parts.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=fields);w.writeheader()
 for a in assets:
  for r in a['components']:w.writerow({k:json.dumps(v) if isinstance(v,(list,dict)) or v is None else v for k,v in ({'asset_id':a['asset_id']}|r).items()})
summary=dict(passed=True,original_inputs_unchanged=True,exact_source_polygon_corner_match=True,source_polygon_boundary_verification=True,all_triangles_uniquely_owned=True,assets=[{k:a[k] for k in ['asset_id','triangle_count','component_count','coverage','maximum_matching_error']} for a in assets])
(out/'validation.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary))
