BRIAR COURT WINDOW COMPONENTS v1 | additive source-art metadata

Unchanged originals: room_window_insert.glb (792 triangles, 18 source solids)
and lobby_glazed_facade.glb (1,004 triangles, 57 source solids).
Every original triangle is mapped exactly once. Room material primitive totals:
cream 220, steel 44, glass 88, cloth 440. Lobby: teal 44, cream 872, glass 88.
Original assets, source exports and placements were not edited. Reference GLBs
and text sources in this packet are byte-for-byte copies, not replacement art.

READ FIRST
The room panes are 18 mm-deep render solids, lobby panes 25 mm. These are measured
modeled dimensions, not verified real glazing gauges. Curtain folds are 32/48 mm
solid box proxies; physical fabric gauge is unknown. Cream/teal paint does not
establish a frame, header or sill substrate. Explicit steel/glass/cloth source
labels support only those broad material families, not grades or engineering data.
No geometry, whole-window transparency or new engine bindings are supplied.
All collider, collision, render, destruction and volume binding fields are null.
The unchanged original materials remain opaque. Engine owns independent splitting.

Each component has the exact original object name and original vertex-group tag.
The Blender source is one mesh per asset, not individually named components.
Island labels are explicitly derived stable connected-component IDs ordered by
lowest original source vertex index. They are not invented original part names.
Original lobby glazed_panels tag includes three cream crossrails as well as glass.
The lobby also includes header and 47 separate OFFICE-lettering bars. The empty
left doorway remains empty in this asset; its assembly door is a separate asset.

MAPPING
Zero-based mesh and primitive-local triangle numbers; [a,b) excludes b.
Triangle t uses original index-accessor entries [3*t,3*t+3), not vertex IDs.
Coordinates are metres. Blender source is Z-up, front -Y; glTF maps source
(x,y,z) to (x,z,-y), with UV V flipped. Matching tolerance is 2e-6 m per position coordinate and 2e-6 per
unitless UV component; observed errors are below 6e-8. This is numerical tolerance,
not real-world manufacturing accuracy. Raw GLB corners match unique source
polygon corners including UVs. Polygon boundary/internal edges and n-2 distinct
triangles are checked, allowing exporter diagonal choice without regeneration.

RELATIONSHIPS / LIMITS
Room cloth boxes intersect pane boxes by 6 or 14 mm in Y. There is no modeled
curtain rod, track or hanging hardware. The 6 mm lateral pane-to-central-divider
gaps, nominal outer-frame contact and missing fixings are recorded. Lobby
crossrails intersect pane geometry; post-to-pane gaps/overlaps are not a buildable
window detail. Lettering floats 1.5 mm ahead of header envelope. Relationships
are source-art observations, not physical joints or structural certification.
See relationships.json and measured_schematic.png.

PROVENANCE / REPRODUCE
Original CC0-1.0 batch15 artwork. Verified original archive:
https://drive.google.com/file/d/1MceTtpBriTUP1-0nvkMC58f8iZG4INVX/view?usp=drivesdk
motor-court-motel-batch-15.tar.xz | 29,744,760 bytes
SHA256 92896091ee009a131cf76e73e0e3c6f94e543bb9e50debda797f89568c213fb3
Download/extract that original archive to a fresh folder. It contains the packed
motor_court_motel.blend required for source-mapping reproduction. This compact
supplement intentionally does not duplicate the full Blender/archive payload.
Use Blender 4.3.2 or compatible:
blender -b -t 1 --python-exit-code 1 --python measure_window_parts.py -- ORIGINAL_DIR OUTPUT_DIR
The script reads original data only and verifies every tracked input hash before
and after. physical_parts.json records exact original source/GLB SHA256 hashes.
Source anchors: build_motel.py lines 121-131 room window; 139-148 lobby;
50-60 lettering; geometry_core.py box()/mesh_from_buffer() geometry and tags.
Original README.md explicitly describes intentional opaque dusty glazing and
static render-only art. No re-export is used as proof of original ownership.

INDEPENDENT REVIEW
independent_validation/ contains a separately implemented source snapshot reader,
raw GLB validator and convex-hull relationship check. It verifies 75 CSV/JSON
records, all 1,796 triangles, 1,010 source polygons, directed boundary incidence
and signed triangle-area conservation. Its 16 strict interior witnesses cover
10 room curtain/pane and six lobby rail/pane intersections. See its README for
portable commands (Python NumPy/SciPy; Blender for fresh source snapshot).
A lightweight runtime-only room overlap check also runs with standard Python:
python validate_relationships.py
All original input hashes remained unchanged. No engine integration is claimed.
