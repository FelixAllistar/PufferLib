exec(open(__file__.replace('render_detached.py','render_candidate.py')).read().split('for d in[0,45,90]:')[0])
pose(20,(1,2,3),True);shot('detached',(3,-4,2.6),(.55,-.35,1.1),3.1)
