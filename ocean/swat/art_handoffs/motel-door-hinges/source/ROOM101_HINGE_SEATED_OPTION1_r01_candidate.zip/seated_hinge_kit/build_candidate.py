import bpy,bmesh,json,math,hashlib
from pathlib import Path
from mathutils import Matrix,Vector
BASE=Path(__file__).resolve().parent;OUT=BASE/'candidate'
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
MAPPING=json.load(open(BASE/'fit_review/source_component_mapping.json'))
# Mesh coordinates Blender(x,-sourceZ,sourceY), all dimensions metres.
def import_parts(asset,prefix):
 old=set(bpy.data.objects);bpy.ops.import_scene.gltf(filepath=str(BASE/'source/assets'/f'{asset}.glb'))
 src=next(o for o in set(bpy.data.objects)-old if o.type=='MESH');parts=[]
 for comp in MAPPING[asset]['components']:
  o=bpy.data.objects.new(f'{prefix}_{comp["component_index"]:02}',src.data.copy());bpy.context.collection.objects.link(o);o.matrix_world=src.matrix_world.copy()
  bm=bmesh.new();bm.from_mesh(o.data);bm.verts.ensure_lookup_table();ids=set(comp['vertex_ids']);bmesh.ops.delete(bm,geom=[v for v in bm.verts if v.index not in ids],context='VERTS');bm.to_mesh(o.data);bm.free()
  o.data.transform(o.matrix_world);o.matrix_world=Matrix.Identity(4);o['original_component']=comp['component_index'];parts.append(o)
 bpy.data.objects.remove(src,do_unlink=True);return parts
leaf=import_parts('room_door_leaf_candidate','R101_LEAF');facade=import_parts('room_facade_4m_candidate','R101_FACADE')
metal=bpy.data.materials['R101_satin_metal'];paint=bpy.data.materials['R101_sage_enamel']
wood=bpy.data.materials.new('materials_v1_door_wood_REUSED');wood.use_nodes=True
bs=wood.node_tree.nodes.get('Principled BSDF');bs.inputs['Metallic'].default_value=0
for role in ['basecolor','normal','roughness']:
 image=bpy.data.images.load(str(BASE/'reused_door_wood'/f'door_wood_{role}.png'));image.colorspace_settings.name='sRGB' if role=='basecolor' else 'Non-Color'
 tex=wood.node_tree.nodes.new('ShaderNodeTexImage');tex.image=image
 if role=='basecolor':wood.node_tree.links.new(tex.outputs['Color'],bs.inputs['Base Color'])
 elif role=='roughness':wood.node_tree.links.new(tex.outputs['Color'],bs.inputs['Roughness'])
 else:
  normal=wood.node_tree.nodes.new('ShaderNodeNormalMap');normal.inputs['Strength'].default_value=1;wood.node_tree.links.new(tex.outputs['Color'],normal.inputs['Color']);wood.node_tree.links.new(normal.outputs['Normal'],bs.inputs['Normal'])

# Source faces, full attributes, for independent preservation audit.
def signature(o):
 uv=o.data.uv_layers.active
 return sorted([[(round(o.data.vertices[o.data.loops[i].vertex_index].co.x,7),round(o.data.vertices[o.data.loops[i].vertex_index].co.y,7),round(o.data.vertices[o.data.loops[i].vertex_index].co.z,7)),tuple(round(v,7) for v in uv.data[i].uv) if uv else None] for i in p.loop_indices] for p in o.data.polygons)
original={o.name:signature(o) for o in leaf+facade}
json.dump(original,open(OUT/'source/original_face_signatures.json','w'))
for i in [4,5,6]:bpy.data.objects.remove(leaf[i],do_unlink=True)
leaf=[o for i,o in enumerate(leaf) if i not in[4,5,6]]
slab=leaf[0]
for j,h in enumerate([.23,1.10,1.92],1):
 bpy.ops.mesh.primitive_cylinder_add(vertices=64,radius=.007,depth=.100,location=(0,0,h));cut=bpy.context.object
 bpy.context.view_layer.objects.active=slab;mod=slab.modifiers.new(f'Approved_R7_H{j:02}','BOOLEAN');mod.operation='DIFFERENCE';mod.solver='EXACT';mod.object=cut;bpy.ops.object.modifier_apply(modifier=mod.name);bpy.data.objects.remove(cut,do_unlink=True)
# Retreat only the inner edge and its bevel vertices; exterior boundary fixed.
edge_changes=[]
for v in facade[3].data.vertices:
 if v.co.x > -1.770:
  before=list(v.co);v.co.x-=.006;edge_changes.append({'vertex':v.index,'before_blender':before,'after_blender':list(v.co)})
json.dump(edge_changes,open(OUT/'source/casing_edge_vertex_changes.json','w'),indent=2)
json.dump({o.name:signature(o) for o in leaf+facade},open(OUT/'source/candidate_face_signatures.json','w'))
# Geometry helper: all meshes authored directly in source coordinate frame then converted.
allhardware=[];remnants=[];mounts=[]
def mesh(name,verts,faces,mat,owner,state='intact'):
 m=bpy.data.meshes.new(name);m.from_pydata([(x,-z,y) for x,y,z in verts],[],faces);m.update();o=bpy.data.objects.new(name,m);bpy.context.collection.objects.link(o);m.materials.append(mat);o['owner']=owner;o['state']=state;o['source_axis']='X=0,Z=0';(remnants if state=='failed' else allhardware).append(o);return o

def box(name,x0,x1,y0,y1,z0,z1,mat,owner,state='intact'):
 vs=[(x,y,z) for x,y,z in[(x0,y0,z0),(x1,y0,z0),(x1,y1,z0),(x0,y1,z0),(x0,y0,z1),(x1,y0,z1),(x1,y1,z1),(x0,y1,z1)]]
 return mesh(name,vs,[(0,3,2,1),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)],mat,owner,state)
def ring(name,y0,y1,ro,ri,owner):
 n=32;vs=[]
 for y in[y0,y1]:
  for r in[ro,ri]:vs += [(r*math.cos(i*2*math.pi/n),y,r*math.sin(i*2*math.pi/n)) for i in range(n)]
 faces=[]
 for i in range(n):
  j=(i+1)%n;faces += [(i,j,2*n+j,2*n+i),(n+j,n+i,3*n+i,3*n+j),(j,i,n+i,n+j),(2*n+i,2*n+j,3*n+j,3*n+i)]
 return mesh(name,vs,faces,metal,owner)
def merge(parts,name):
 bpy.ops.object.select_all(action='DESELECT')
 for o in parts:o.select_set(True)
 bpy.context.view_layer.objects.active=parts[0];bpy.ops.object.join();o=bpy.context.object;o.name=name
 for dead in parts[1:]:
  for arr in[allhardware,remnants]:
   if dead in arr:arr.remove(dead)
 return o
# Union adjacent additive primitives so no internal overlap is counted as contact.
def union(parts,name):
 target=parts[0]
 for o in parts[1:]:
  bpy.context.view_layer.objects.active=target;mod=target.modifiers.new('Metal_union','BOOLEAN');mod.operation='UNION';mod.solver='EXACT';mod.object=o;bpy.ops.object.modifier_apply(modifier=mod.name)
  if o in allhardware:allhardware.remove(o)
  bpy.data.objects.remove(o,do_unlink=True)
 target.name=name;return target
for j,h in enumerate([.23,1.10,1.92],1):
 p=f'R101_H{j:02}'
 lp=[ring(p+'_LEAF_RING',h-.015,h+.015,.006,.0033,'leaf')]
 lp += [box(p+'_WRAP_ARM',-.008,-.006,h-.014,h+.014,.003,.0245,metal,'leaf'),box(p+'_WRAP_TONGUE',-.008,-.003,h-.014,h+.014,.003,.005,metal,'leaf'),box(p+'_FACE_PLATE',-.008,.032,h-.014,h+.014,.0225,.0245,metal,'leaf')]
 union(lp,p+'_LEAF_METAL')
 fp=[]
 for k,(a,b) in enumerate([(-.045,-.016),(.016,.045)]):
  # Fixed mount surface-seated on moved jamb; excludes swept negative-Z wedge.
  fp += [ring(p+f'_FIXED_RING{k}',h+a,h+b,.006,.0033,'frame'),box(p+f'_FIXED_TONGUE{k}',-.0235,-.003,h+a+.001,h+b-.001,.003,.005,metal,'frame')]
 # Jamb plate sits outside new inner faceX=-.0235, entirely positiveZ.
 fp += [box(p+'_JAMB_PLATE',-.0235,-.0215,h-.046,h+.046,.003,.014,metal,'frame')]
 union(fp,p+'_FIXED_JAMB_METAL')
 # Pin as solid ring with center capped via cylinder.
 bpy.ops.mesh.primitive_cylinder_add(vertices=32,radius=.003,depth=.094,location=(0,0,h));pin=bpy.context.object;pin.name=p+'_PIN';pin.data.materials.append(metal);pin['owner']='frame';pin['state']='intact';allhardware.append(pin)
 for owner,x0,x1,z0,z1 in [('leaf',.004,.014,.0225,.024),('frame',-.0235,-.0215,.003,.012)]:
  # Small broken painted substrate splinters; same original paint material, no unlicensed wood maps.
  for q in range(3):
   # Uneven vertical grain-aligned splinters, not a repeating flag row.
   width=[.0017,.0025,.0019][q];length=[.022,.015,.025][q];vcenter=h+[-.001,.004,-.0005][q]
   ubase=(x0 if owner=='leaf' else z0)+[.0012,.0042,.0070][q]
   outline=[(0,-length*.43),(width*.85,-length*.5),(width,length*.28),(width*.62,length*.42),(width*.48,length*.30),(width*.26,length*.50),(width*.08,length*.34)]
   angle=math.radians([-4,7,-3][q]);points=[]
   for u,v in outline:
    u,v=u*math.cos(angle)-v*math.sin(angle),u*math.sin(angle)+v*math.cos(angle);points.append((ubase+u,vcenter+v))
   vs=[]
   for side in [0,1]:
    for k,(u,v) in enumerate(points):
     thick=side*(.0008+.00025*((k+q)%3))
     vs.append((u,v,z0+thick) if owner=='leaf' else (x0+thick,v,u))
   n=len(points);faces=[tuple(range(n-1,-1,-1)),tuple(range(n,2*n))]+[(i,(i+1)%n,(i+1)%n+n,i+n) for i in range(n)]
   if owner=='frame':faces=[tuple(reversed(f)) for f in faces]
   o=mesh(p+f'_{owner.upper()}_EXPOSED_WOOD_REMNANT_{q}',vs,faces,wood,owner,'failed')
   uv=o.data.uv_layers.new(name='UVMap')
   for face in o.data.polygons:
    for li in face.loop_indices:
     v=o.data.vertices[o.data.loops[li].vertex_index].co;uv.data[li].uv=((v.x-v.y)/.6,v.z/2.0)
  o=box(p+f'_{owner.upper()}_METAL_REMNANT',x0,x0+(x1-x0)*.25,h-.014,h+.014,z0 if owner=='leaf' else z1,(z0 if owner=='leaf' else z1)+.0015,metal,owner,'failed')
 empty=bpy.data.objects.new(p+'_MOUNT',None);bpy.context.collection.objects.link(empty);empty.location=(0,0,h);empty['source_anchor']=[0,h,0];empty['engine_anchor']=[0,h-1.095,-.54];mounts.append(empty)
# Facade moves only in assembled reference; exports retain original facade datum.
def export(path,objects):
 bpy.ops.object.select_all(action='DESELECT')
 for o in objects:o.hide_set(False);o.hide_render=False;o.select_set(True)
 bpy.ops.export_scene.gltf(filepath=str(path),export_format='GLB',use_selection=True,export_extras=True,export_yup=True,export_apply=False)
for o in leaf:o['owner']='leaf';o['state']='intact_leaf'
export(OUT/'runtime/room101_leaf_option1.glb',leaf)
export(OUT/'runtime/room101_facade_option1.glb',facade)
export(OUT/'runtime/room101_hardware_option1.glb',allhardware+mounts)
export(OUT/'runtime/room101_failure_remnants.glb',remnants)
for o in facade:o.location.x+=1.74
for o in remnants:o.hide_render=True;o.hide_set(True)
# Capture authored meshes and labels, no scene geometry duplicates.
for o in leaf:o['owner']='leaf';o['state']='intact_leaf'
manifest={'status':'candidate_needs_independent_QA','source_drive_id':'1OsWdtrOmgvHDr49SPdDNF9k2jqGpOV1p','approved_changes':['remove_only_original_barrel_components4_5_6','slab_R7mm_height100mm_at_.23_1.10_1.92','facade_component3_inner_edge_X_minus6mm_exterior_fixed'],'coordinate_system':'sourceGLB=(BlenderX,BlenderZ,-BlenderY)','swing':'xprime=x*cos+z*sin;zprime=-x*sin+z*cos','nodes':[],'remnants':'exposed wood uses existing materials_v1 door_wood maps unchanged; metal uses original satin material'}
for o in leaf+facade+allhardware+remnants:
 o.data.calc_loop_triangles();manifest['nodes'].append({'name':o.name,'owner':o.get('owner','frame'),'state':o.get('state','intact'),'triangles':len(o.data.loop_triangles),'materials':[m.name for m in o.data.materials]})
json.dump(manifest,open(OUT/'MANIFEST.json','w'),indent=2)
for im in bpy.data.images:
 if im.source=='FILE':
  try:im.pack()
  except:pass
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'source/room101_option1_editable.blend'))
print('BUILD_COMPLETE',len(allhardware),len(remnants))
