import bpy,json,hashlib
from pathlib import Path
from collections import defaultdict
base=Path(__file__).resolve().parent
report={'coordinate_system':'GLB source X horizontal,Y up,Z depth; Blender converted back to GLB','status':'source only; no candidate or edits'}
for f in ['room_door_leaf_candidate','room_facade_4m_candidate']:
 bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
 p=base/'source/assets'/f'{f}.glb';bpy.ops.import_scene.gltf(filepath=str(p))
 o=next(o for o in bpy.context.scene.objects if o.type=='MESH');m=o.data
 groups=defaultdict(list)
 for v in m.vertices:groups[tuple(round(x,6) for x in v.co)].append(v.index)
 adj=defaultdict(set)
 for g in groups.values():
  for v in g:adj[v].update(g)
 for face in m.polygons:
  for v in face.vertices:adj[v].update(face.vertices)
 unseen=set(range(len(m.vertices)));cs=[]
 while unseen:
  todo=[min(unseen)];ids=set()
  while todo:
   v=todo.pop()
   if v in ids:continue
   ids.add(v);todo.extend(adj[v]-ids)
  unseen-=ids
  vs=[o.matrix_world@m.vertices[v].co for v in ids];vs=[(v.x,v.z,-v.y) for v in vs]
  ps=[p for p in m.polygons if p.vertices[0] in ids]
  cs.append(dict(component_index=len(cs),vertex_ids=sorted(ids),polygon_ids=[p.index for p in ps],bounds=[[round(min(v[i] for v in vs),6) for i in range(3)],[round(max(v[i] for v in vs),6) for i in range(3)]],materials=list(set(m.materials[p.material_index].name for p in ps))))
 report[f]={'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'node':o.name,'components':cs}
json.dump(report,open(base/'fit_review/source_component_mapping.json','w'),indent=2)
