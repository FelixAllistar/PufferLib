from pathlib import Path
import json,hashlib
B=Path(__file__).resolve().parent/'candidate';h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
rt={p.name:h(p) for p in(B/'runtime').glob('*.glb')};out=[]
for p in(B/'qa').glob('*.png'):
 if p.name=='remnant_design_preview.png':continue
 if p.name.startswith('H02_'):assets=['room101_hardware_option1.glb']
 elif p.name.startswith(('failed','last_hinge','detached','remnant_design')):assets=list(rt)
 else:assets=[n for n in rt if 'failure_remnants' not in n]
 out.append({'image':p.name,'sha256':h(p),'visible_asset_hashes':{n:rt[n] for n in assets},'method':'actual exported GLB import, node-owner visibility/transform review pose; no mesh modifications'})
json.dump({'images':out,'png_to_jpeg':'packaged JPEG copies preserve framing; PNG SHA records original rendered evidence','limitations':'static Blender rendering, not engine integration or physics acceptance'},open(B/'qa/render_asset_bindings.json','w'),indent=2)
