exec(open(__file__.replace('render_bore.py','render_candidate.py')).read().split('for d in[0,45,90]:')[0])
for o in leaf+facade+rem:o.hide_render=True
for o in hw:o.hide_render=('H02' not in o.name or o.name.endswith('_PIN'))
shot('H02_bore_isolation_pin_hidden',(.08,-.12,1.20),(0,0,1.10),.13)
for o in hw:o.hide_render=('H02' not in o.name)
shot('H02_pin_knuckle_isolation',(.08,-.12,1.20),(0,0,1.10),.13)
