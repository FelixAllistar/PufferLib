from pathlib import Path
import json,hashlib,collections
B=Path(__file__).resolve().parent;C=B/'candidate';p=C/'MANIFEST.json';d=json.load(open(p));ns=d['nodes'];d['triangle_totals']={'leaf':sum(n['triangles'] for n in ns if n['name'].startswith('R101_LEAF_')),'facade':sum(n['triangles'] for n in ns if n['name'].startswith('R101_FACADE_')),'intact_hardware':sum(n['triangles'] for n in ns if '_H0' in n['name'] and n['state']=='intact'),'failure_remnants_all':sum(n['triangles'] for n in ns if n['state']=='failed')};d['material_names']=sorted({m for n in ns for m in n['materials']});d['reused_door_wood']={'source_drive_id':'1xgE8k9-w-V0-hRHexiHW0b89mbjvpudl','material_id':'door_wood','resolution':[512,512],'tile_metres':[.6,2.0],'files':{}}
mat=next(m for m in json.load(open(B/'reused_door_wood/material_manifest.json'))['materials'] if m['id']=='door_wood')
for role,m in mat['maps'].items():
 f=B/'reused_door_wood'/m['file'];h=hashlib.sha256(f.read_bytes()).hexdigest();assert h==m['sha256'];d['reused_door_wood']['files'][f.name]={'sha256':h,'bytes':f.stat().st_size}
d['runtime_files']={f.name:{'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for f in(C/'runtime').glob('*.glb')}
json.dump(d,open(p,'w'),indent=2)
a=json.load(open(C/'source/original_face_signatures.json'));b=json.load(open(C/'source/candidate_face_signatures.json'));r={}
for n,v in a.items():
 old=collections.Counter(json.dumps(f) for f in v);new=collections.Counter(json.dumps(f) for f in b.get(n,[]));r[n]={'original_faces':len(v),'candidate_faces':len(b.get(n,[])),'exact_unchanged_faces':sum((old&new).values()),'removed_or_retessellated_faces':[json.loads(s) for s in(old-new).elements()],'added_or_retessellated_faces':[json.loads(s) for s in(new-old).elements()]}
json.dump(r,open(C/'source/exact_face_change_audit.json','w'),indent=2)
print(d['triangle_totals'])
