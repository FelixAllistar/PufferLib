import bpy,json,math,time
from pathlib import Path
from mathutils import Vector
from mathutils.bvhtree import BVHTree
B=Path(__file__).resolve().parent
m=json.load(open(B/'candidate_meshes.json'));fixed={};moving={}
for f,a in m.items():
 if 'remnant' in f:continue
 for n,o in a['objects'].items():
  vs=[Vector(v) for v in o['vertices']]
  if 'FACADE' in n:
   for v in vs:v.x+=1.74
  rec={'vertices':vs,'triangles':o['triangles']}
  if 'LEAF' in n:moving[n]=rec
  else:fixed[n]=rec
legacy=json.load(open(B/'source_meshes.json'))
for filename,data in legacy.items():
 if 'optional_detail_overlay' not in filename:continue
 for name,o in data['objects'].items():
  vs=[Vector(v) for v in o['vertices']]
  if 'facade_optional' in filename:
   for v in vs:v.x+=1.74
   fixed['LEGACY_'+name]={'vertices':vs,'triangles':o['triangles']}
  else:moving['LEGACY_'+name]={'vertices':vs,'triangles':o['triangles']}
for a in fixed.values():a['bvh']=BVHTree.FromPolygons(a['vertices'],a['triangles'],all_triangles=True,epsilon=0)
report={'runtime_input_sha256':{Path(f).name:a['sha256'] for f,a in m.items() if 'remnant' not in f},'method':'Blender BVHTree triangle-surface overlap, actual exported GLB vertices in source coordinate frame,901 samples0–90degrees inclusive at0.1degree; no collider proxies','sample_count':901,'overlaps':[],'caveats':['triangle surface overlap alone is not containment detection; separate convex and bore/radial interval proofs supplement this sweep']}
start=time.time()
for ai in range(901):
 t=math.radians(ai/10);co,si=math.cos(t),math.sin(t)
 for n,a in moving.items():
  vv=[Vector((v.x*co+v.z*si,v.y,-v.x*si+v.z*co)) for v in a['vertices']]
  bvh=BVHTree.FromPolygons(vv,a['triangles'],all_triangles=True,epsilon=0)
  for fn,f in fixed.items():
   overlaps=bvh.overlap(f['bvh'])
   if overlaps:report['overlaps'].append({'angle_degrees':ai/10,'moving':n,'fixed':fn,'triangle_intersections':len(overlaps)})
 if ai%100==0:print(ai/10,'deg',len(report['overlaps']),'hits',round(time.time()-start,2),'sec',flush=True)
report['seconds']=time.time()-start
json.dump(report,open(B/'sweep_with_legacy_optional_overlays.json','w'),indent=2)
print('COMPLETE',len(report['overlaps']))
