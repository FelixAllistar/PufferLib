# Independent Room 101 option 1 audit

## Result and scope

The intact candidate passes the geometry, source-preservation, mounting-contact and original-axis sweep checks described below. These are offline checks of the exported geometry. They are not native-engine acceptance, structural certification, physics validation, or a claim that every legacy optional detail is collision-free.

Final actual-export images were inspected: intact 0/45/90-degree views, bore/pin isolation, one failed hinge, frame-fragment close-up, H03-only last-hinge state and illustrative detached state. Visible exposed wood and metal remain on the correct owners. The final remnant GLB hash is `6c7588f6b8635a6b2e7b67f077470223735b81246c1c5161a531019dcbf70a3c`. All 24 fragments are closed, outward-wound and seated on their owner surface within 0.1 micrometre. No open geometry or visual-review blockers remain within this offline candidate scope.

## Frozen source and approved changes

- All 42 files in the recovered source directory remain byte-for-byte unchanged. The accepted leaf hash remains `cf2cd3c1e521d53cd9e799b1035737f7247badf6d1d8b1cc32286934f7f89afc`.
- Exactly the three old decorative barrel components 4, 5 and 6 are removed: 36 source triangles each, 108 total. They map to H01, H02 and H03 respectively.
- The original slab has 44 triangles. Two hinge-edge triangles are replaced by 402 local relief triangles; the other 42 original position/UV/material triangle records remain unchanged. The three reliefs are radius 7 mm and height 100 mm at source Y = 0.23, 1.10 and 1.92 m. Broad slab faces are unchanged.
- Only the inner edge and adjoining bevel vertices of facade component 3 retreat by 6 mm. Its outer boundary stays fixed. This changes 48 imported seam-duplicated vertices and 30 triangles. The actual exported result matches that edge-only transformation to 1 micrometre; no whole-component translation was used.
- Every other original position/UV/material triangle record is preserved. Original embedded texture bytes and material settings are unchanged. Blender re-export regenerates normals on 27 unchanged bevel triangles; the largest normal-vector angle difference is approximately 0.0081 degrees. This tiny normal-only drift is disclosed rather than described as bitwise normal preservation.

The full source-to-candidate triangle mapping is in `exact_face_component_diff.json`. Its ordinals refer to raw GLB primitive triangle order; the original imported component mapping is separately retained in the kit.

## Actual geometry and continuous clearance

The original failure was independently reproduced using the actual source vertices: first slab/jamb contact at 60.0559686 degrees and 5.0000677 mm penetration at 90 degrees.

The corrected intact candidate was reimported from its exported GLBs and checked at 901 poses, including both endpoints, from 0 to 90 degrees in 0.1-degree steps. There were zero moving/fixed triangle-surface intersections. No proxy colliders were substituted.

Sampling is supplemented by geometry bounds covering the continuous angle interval:

- Slab to retreated jamb: at least approximately 0.999974 mm. Every actual facade triangle is wholly outside the leaf's full swept envelope, classified as left, right or above it.
- Faceted 7 mm relief to 6 mm outer-radius knuckle: at least approximately 0.991567 mm radial clearance.
- Faceted 3.3 mm bore to 3 mm pin: at least approximately 0.284110 mm radial clearance. This is smaller than the nominal 0.3 mm because the 32-sided bore's apothem is used.
- Leaf/fixed knuckle axial gap: approximately 1 mm, including float precision.
- Fixed mounting plates and tongues lie in the unswept negative-X/positive-Z quadrant. Leaf wrap and jamb plate separation is also bounded throughout the full angle interval.

Axis and swing remain source X = 0, Z = 0, clockwise using x' = x cos(theta) + z sin(theta), z' = -x sin(theta) + z cos(theta). All nine intact hardware meshes are closed and consistently oriented after welding coincident geometry at 0.1 micrometre precision.

## Mounting and failure scope

The leaf plate contacts the existing source Z = +22.5 mm face. The jamb plate is external to the retreated source X = -23.5 mm face. No extra mounting mortise or intentional embedded bridge is used. There are no modeled screws, bolt holes or retention features, so this audit establishes contact and clearance, not fastening strength.

The exports provide nine intact hardware nodes, three logical mount references and 24 independently named failure remnants with leaf/frame ownership. Runtime parenting and visibility remain an engine responsibility. Remnants must load hidden and be revealed only on the corresponding failure; the intact metal and pin for that support must be hidden.

The last-hinge example keeps H03 intact and rotates 45 degrees about the original axis. Its logical anchor stays exactly at source (0, 1.92, 0). It has no arbitrary tilt or asserted load-bearing sag simulation. The detached example is illustrative, with leaf-owned fragments following the slab and frame-owned fragments remaining fixed.

## Important inherited optional-overlay caveat

An additional sweep including all unchanged optional facade and door overlays found the pre-existing flush-threshold plate intersecting the slab at all 901 sampled poses. The source threshold top is +0.400000019 mm above the floor, matching the original documented visual offset. Every other legacy overlay pair was clear in this sweep. The threshold was not modified, and this inherited overlap is not hidden by the intact candidate's passing hinge-clearance result.

## Evidence files

- `baseline_actual_geometry.json`: independent reproduction of the original interference.
- `sweep_actual_exported_meshes.json`: actual exported candidate sweep, 901 poses.
- `continuous_clearance_bounds.json`: continuous interval and faceted bore/relief bounds.
- `sweep_with_legacy_optional_overlays.json`: separately scoped inherited-overlay sweep.
- `exact_face_component_diff.json`: full source/candidate position/UV/material triangle mapping and normal-only differences.
- `preservation_raw_glb.json`: embedded image hashes and raw attribute comparisons.
- `ownership_integrity_final.json`: final runtime hashes, source integrity, topology and failure ownership checks.
- `source_hashes_before.json`: frozen input hash snapshot.
- `detached_pose_check.json`: final illustrative detached-pose intersection check, with zero moving/fixed intersections.
- `visual_review_final.json`: inspected images bound to final image and asset hashes.
- `source_meshes.json`, `candidate_meshes.json`, `final_remnant_meshes.json`: actual exported geometry extraction snapshots for reproduction.

## Reproduction

The Python scripts use their own directory to locate the audit files and the kit root. Blender 4.3.2 was used for import and BVH checks; Python with NumPy and SciPy was used for independent numerical checks. Preserve the supplied `source/assets`, `candidate/runtime` and `fit_review` layout to regenerate snapshots. The snapshots also allow the Python numerical checks to run without Blender.

Run `check_baseline.py`, `check_preservation.py`, `preservation_details.py`, `clearance_proof.py` and `ownership_and_integrity.py` with Python. Run `sweep_bvh.py`, `sweep_with_legacy_overlays.py` and `check_detached_pose.py` with Blender in background mode. `extract_mesh.py` accepts an output JSON path followed by one or more GLB paths after Blender's `--` separator.
