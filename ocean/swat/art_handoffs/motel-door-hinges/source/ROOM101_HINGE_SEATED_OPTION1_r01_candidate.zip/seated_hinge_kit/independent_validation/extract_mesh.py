import bpy,json,sys,hashlib
from pathlib import Path
args=sys.argv[sys.argv.index('--')+1:]
output=Path(args[0]); files=args[1:]; result={}
for f in files:
 bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
 bpy.ops.import_scene.gltf(filepath=str(Path(f).resolve()))
 obs={}
 for o in bpy.context.scene.objects:
  if o.type!='MESH':continue
  m=o.data;m.calc_loop_triangles()
  vs=[o.matrix_world@v.co for v in m.vertices]
  verts=[[v.x,v.z,-v.y] for v in vs]
  obs[o.name]={'vertices':verts,'triangles':[list(p.vertices) for p in m.loop_triangles],'triangle_materials':[p.material_index for p in m.loop_triangles], 'polygons':[list(p.vertices) for p in m.polygons], 'polygon_materials':[p.material_index for p in m.polygons],'uv_layers': {uv.name:[[float(x) for x in item.uv] for item in uv.data] for uv in m.uv_layers},'materials':[x.name if x else None for x in m.materials], 'parent':o.parent.name if o.parent else None,'extras':dict(o.items())}
 result[str(Path(f))]={'sha256':hashlib.sha256(Path(f).read_bytes()).hexdigest(),'objects':obs}
output.write_text(json.dumps(result,default=str))
