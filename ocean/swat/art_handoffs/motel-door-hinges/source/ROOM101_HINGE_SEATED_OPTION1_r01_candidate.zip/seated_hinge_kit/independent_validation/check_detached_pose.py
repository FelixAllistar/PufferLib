import json,math
from pathlib import Path
from mathutils import Matrix,Vector
from mathutils.bvhtree import BVHTree
B=Path(__file__).resolve().parent;m=json.load(open(B/'candidate_meshes.json'));objects={n:o for a in m.values() for n,o in a['objects'].items()};R=Matrix.Translation((.55,-.8,.2))@Matrix.Rotation(math.radians(-30),4,'Y')@Matrix.Rotation(math.radians(20),4,'Z');moving={};fixed={}
for n,o in objects.items():
 if '_METAL' in n and '_REMNANT' not in n or '_PIN' in n:continue
 isleaf=n.startswith('R101_LEAF') or o['extras'].get('owner')=='leaf';vs=[]
 for v in o['vertices']:
  vec=Vector((v[0],-v[2],v[1]))
  if isleaf:vec=R@vec
  if n.startswith('R101_FACADE'):vec.x+=1.74
  vs.append(vec)
 b=BVHTree.FromPolygons(vs,o['triangles'],all_triangles=True)
 (moving if isleaf else fixed)[n]=b
hits=[]
for n,b in moving.items():
 for fn,f in fixed.items():
  over=b.overlap(f)
  if over:hits.append({'moving':n,'fixed':fn,'count':len(over)})
report={'scope':'Only the final illustrative detached review pose, not a falling trajectory or engine physics test','source':'Final actual GLB extraction','blender_pose':{'translation_m':[.55,-.8,.2],'pre_translation_rotation':'Y=-30 degrees after Z=+20 degrees'},'moving_fixed_triangle_intersections':hits,'leaf_and_leaf_fragments_share_transform':True,'frame_and_frame_fragments_remain_fixed':True}
json.dump(report,open(B/'detached_pose_check.json','w'),indent=2);print(json.dumps(report,indent=2))
