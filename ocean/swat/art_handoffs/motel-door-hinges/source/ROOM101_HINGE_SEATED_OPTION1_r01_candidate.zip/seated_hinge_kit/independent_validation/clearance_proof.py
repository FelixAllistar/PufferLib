import json,numpy as np,math
from pathlib import Path
B=Path(__file__).resolve().parent;data=json.load(open(B/'candidate_meshes.json'));objs={n:o for a in data.values() for n,o in a['objects'].items()};report={}
# Exterior facade faces must lie in left, right, or upper regions relative to the actual opening.
facade={n:o for n,o in objs.items() if n.startswith('R101_FACADE')}; bad=[]; margins=[]
for n,o in facade.items():
 v=np.array(o['vertices']);v[:,0]+=1.74
 for i,t in enumerate(o['triangles']):
  tri=v[t];left=-.022500001-tri[:,0].max();right=tri[:,0].min()-1.080234376;top=tri[:,1].min()-2.1900001
  margin=max(left,right,top)
  if margin<0:bad.append([n,i,margin,tri.tolist()])
  margins.append(margin)
report['facade_continuous_separation']={'method':'Every actual facade triangle is classified wholly left, right, or above the full0–90moving-leaf envelope. For sourceX>=0,sourceZ>=-22.5mm, rotatedX>=-22.5mm; rotatedX<=max vertex radial extent; verticalY unchanged. Convex-piece surfaces cannot contain the initial leaf, independently checked by opening bounds.','unclassified_triangles':bad,'minimum_axis_separation_m':min(margins)}
# Mesh dimensions at each hinge.
report['hinges']=[]
for j,h in enumerate([.23,1.1,1.92],1):
 p=f'R101_H{j:02}';leaf=np.array(objs[p+'_LEAF_METAL']['vertices']);fixed=np.array(objs[p+'_FIXED_JAMB_METAL']['vertices']);pin=np.array(objs[p+'_PIN']['vertices']);slab=np.array(objs['R101_LEAF_00']['vertices'])
 # ring coordinates are all vertices on r=.006 or.0033; bounded byactual vertices.
 rleaf=np.linalg.norm(leaf[:,[0,2]],axis=1);rfixed=np.linalg.norm(fixed[:,[0,2]],axis=1);rpin=np.linalg.norm(pin[:,[0,2]],axis=1)
 def inner_distance(o):
  v=np.array(o['vertices']);vals=[]
  for tri in o['triangles']:
   for a,b in zip(tri,np.roll(tri,1)):
    p,q=v[a,[0,2]],v[b,[0,2]]
    if abs(np.linalg.norm(p)-.0033)>1e-7 or abs(np.linalg.norm(q)-.0033)>1e-7:continue
    if np.linalg.norm(q-p)<1e-9:continue
    d=q-p;t=np.clip(-p@d/(d@d),0,1);vals.append(np.linalg.norm(p+t*d))
  return min(vals)
 bore=min(inner_distance(objs[p+'_LEAF_METAL']),inner_distance(objs[p+'_FIXED_JAMB_METAL']))
 rv=np.linalg.norm(slab[:,[0,2]],axis=1);rpts=slab[(np.abs(slab[:,1]-h)<.050001)&(np.abs(rv-.007)<1e-7)][:,[0,2]]
 angles=np.unique(np.round(np.arctan2(rpts[:,1],rpts[:,0]),7));angles.sort();max_step=float(np.diff(angles).max());relief_apothem=.007*math.cos(max_step/2)
 # Dimensions copied from actual vertices only.
 yleaf=leaf[(rleaf<.0060001),1]; yfixed=fixed[(rfixed<.0060001),1]
 low= yfixed[yfixed<h].max();high=yfixed[yfixed>h].min()
 report['hinges'].append({'hinge':p,'center_source':[0,h,0],'bore_min_apothem_m':bore,'pin_max_radius_m':float(rpin.max()),'pin_bore_continuous_radial_clearance_m':bore-float(rpin.max()),'relief_min_apothem_m':relief_apothem,'knuckle_max_outer_radius_m':max(float(rleaf[rleaf<.0060001].max()),float(rfixed[rfixed<.0060001].max())),'relief_knuckle_continuous_radial_clearance_m':relief_apothem-.006000001,'axial_gaps_m':[float(yleaf.min()-low),float(high-yleaf.max())],'leaf_plate_contact_z_m':float(leaf[(leaf[:,0]>.01),2].min()),'fixed_mount_min_x_m':float(fixed[:,0].min()),'fixed_mount_seating_surface_x_m':-.0235})
report['hardware_continuous_proof']=[
'Fixed tongues and plate lie in sourceX<0,Z>0. Under inverse0–90clockwise rotation,originalX=x*cos-z*sin<0, so these regions cannot intersect the leaf slab or unchanged source leaf components (all sourceX>=0).',
'Leaf wrap extends tosourceX=-8mm but hasZ>=3mm, so rotatedX>=-8mm throughout0–90. Fixed jambplate staysX<=-21.5mm: at least13.5mm separation.',
'Leaf wrapY=h±14mm and centerknuckleY=h±15mm are separated fromfixedknuckles/tonguesY<=h-16mm orY>=h+16mm byatleast1mm.',
'Central pin/knuckle and relief/knuckle radial clearances use actual faceted bore and relief apothems; axis and radial distances are invariant under the approved swing.',
'Full moving/fixed triangle-surface sweep adds901pose actual-export checks; no collider proxies or nativeengine claims.'
]
json.dump(report,open(B/'continuous_clearance_bounds.json','w'),indent=2);print(json.dumps(report,indent=2))
