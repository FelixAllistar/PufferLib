import json,struct,numpy as np,hashlib,collections
from pathlib import Path
B=Path(__file__).resolve().parent;S=B.parent/'source/assets';C=B.parent/'candidate/runtime'
def glb(path):
 data=path.read_bytes();n,t=struct.unpack_from('<II',data,12);g=json.loads(data[20:20+n]);off=20+n;nb,t=struct.unpack_from('<II',data,off);binary=data[off+8:off+8+nb]
 def acc(i):
  a=g['accessors'][i];v=g['bufferViews'][a['bufferView']];dt={5120:'i1',5121:'u1',5122:'i2',5123:'u2',5125:'u4',5126:'f4'}[a['componentType']];nc={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4,'MAT4':16}[a['type']];offset=v.get('byteOffset',0)+a.get('byteOffset',0);stride=v.get('byteStride',np.dtype(dt).itemsize*nc)
  return np.ndarray((a['count'],nc),dtype=dt,buffer=binary,offset=offset,strides=(stride,np.dtype(dt).itemsize)).copy()
 nodes={}
 for node in g.get('nodes',[]):
  if 'mesh' not in node:continue
  fs=[]
  for p in g['meshes'][node['mesh']]['primitives']:
   at={k:acc(i) for k,i in p['attributes'].items()}; ix=acc(p['indices']).ravel().reshape(-1,3);mat=g.get('materials',[{}])[p.get('material',0)].get('name','')
   for tri in ix:
    entries=[]
    for i in tri:
     entries.append(tuple(tuple(round(float(v),7) for v in at[k][i]) for k in ['POSITION','NORMAL','TEXCOORD_0'] if k in at))
    rotations=[tuple(entries[i:]+entries[:i]) for i in range(3)]
    fs.append((min(rotations),mat))
  nodes[node['name']]=fs
 imgs={}
 for im in g.get('images',[]):
  if 'bufferView' in im:
   v=g['bufferViews'][im['bufferView']];raw=binary[v.get('byteOffset',0):v.get('byteOffset',0)+v['byteLength']];imgs[im.get('name','')]=hashlib.sha256(raw).hexdigest()
 return nodes,imgs,g
source_l,iml,gl=glb(S/'room_door_leaf_candidate.glb');source_f,imf,gf=glb(S/'room_facade_4m_candidate.glb');cand_l,imcl,gcl=glb(C/'room101_leaf_option1.glb');cand_f,imcf,gcf=glb(C/'room101_facade_option1.glb')
# Exact source triangle ranges established from imported source component mapping.
mapdata=json.load(open(B.parent/'fit_review/source_component_mapping.json'))
# GLB primitive sorting may differ; assign source triangles to components by position membership.
sm=json.load(open(B/'source_meshes.json'))
report={'raw_embedded_image_hashes':{'source_leaf':iml,'candidate_leaf':imcl,'source_facade':imf,'candidate_facade':imcf},'component_face_diffs':[]}
for asset,source,cand in [('room_door_leaf_candidate',source_l,cand_l),('room_facade_4m_candidate',source_f,cand_f)]:
 sobj=list(sm[str(S.relative_to(B.parents[1]))/Path(asset+'.glb')] ['objects'].values())[0] if False else list(sm['seated_hinge_kit/source/assets/'+asset+'.glb']['objects'].values())[0]
 sf=list(source.values())[0]
 for comp in mapdata[asset]['components']:
  ci=comp['component_index'];vset={tuple(round(x,7) for x in sobj['vertices'][i]) for i in comp['vertex_ids']};src=[f for f in sf if all(e[0] in vset for e in f[0])];cn=('R101_LEAF_' if 'leaf' in asset else 'R101_FACADE_')+f'{ci:02}'
  dst=cand.get(cn,[]);sc=collections.Counter(src);dc=collections.Counter(dst)
  report['component_face_diffs'].append({'asset':asset,'component':ci,'node':cn,'source_triangles':len(src),'candidate_triangles':len(dst),'unchanged_exact_position_normal_uv_material_triangles':sum((sc&dc).values()),'removed_or_changed':sum((sc-dc).values()),'new_or_changed':sum((dc-sc).values())})
json.dump(report,open(B/'preservation_raw_glb.json','w'),indent=2)
print(json.dumps(report,indent=2))
