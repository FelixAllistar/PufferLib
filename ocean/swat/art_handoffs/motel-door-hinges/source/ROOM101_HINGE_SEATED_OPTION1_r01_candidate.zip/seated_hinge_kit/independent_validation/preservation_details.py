import sys,contextlib,io,collections,json,math,numpy as np
from pathlib import Path
with contextlib.redirect_stdout(io.StringIO()): import check_preservation as c
B=Path(__file__).resolve().parent
report={'component_diffs':[],'normal_only_changes':[],'material_changes':[]}
def pnuv(face,move=False):
 vs=[]
 for entry in face[0]:
  p=entry[0]
  if move and p[0]>-1.770:p=(round(p[0]-.006,7),p[1],p[2])
  vs.append((p,entry[2] if len(entry)>2 else None))
 return min(tuple(vs[i:]+vs[:i]) for i in range(3)),face[1]
for asset,source,cand,sg,cg in [('room_door_leaf_candidate',c.source_l,c.cand_l,c.gl,c.gcl),('room_facade_4m_candidate',c.source_f,c.cand_f,c.gf,c.gcf)]:
 sobj=list(c.sm['seated_hinge_kit/source/assets/'+asset+'.glb']['objects'].values())[0];allsource=list(source.values())[0]
 for comp in c.mapdata[asset]['components']:
  ci=comp['component_index'];vset={tuple(round(x,7) for x in sobj['vertices'][i]) for i in comp['vertex_ids']};src=[(i,f) for i,f in enumerate(allsource) if all(e[0] in vset for e in f[0])];cn=('R101_LEAF_' if 'leaf' in asset else 'R101_FACADE_')+f'{ci:02}';dst=cand.get(cn,[])
  dkeys=collections.defaultdict(list)
  for i,f in enumerate(dst):dkeys[pnuv(f)].append(i)
  common=[];removed=[]
  for i,f in src:
   key=pnuv(f)
   if key in dkeys:
    di=dkeys[key][0];common.append([i,di]);fd=dst[di]
    sverts={e[0]:e for e in f[0]};errs=[]
    for e in fd[0]:
     se=sverts[e[0]];nv=np.array(e[1]);sv=np.array(se[1]);errs.append(float(np.linalg.norm(nv-sv)))
    err=max(errs)
    if err>1e-8:report['normal_only_changes'].append({'node':cn,'source_raw_triangle_ordinal':i,'candidate_node_triangle_ordinal':di,'max_normal_vector_difference':err})
   else:removed.append(i)
  report['component_diffs'].append({'node':cn,'source_raw_triangle_ordinals':[i for i,f in src],'unchanged_position_uv_material_map':common,'removed_or_position_uv_material_changed_source_ordinals':removed,'candidate_changed_or_new_ordinals':sorted(set(range(len(dst)))-{v[1] for v in common})})
  if cn=='R101_FACADE_03':
   expected=collections.Counter(pnuv(f,True) for _,f in src);actual=collections.Counter(pnuv(f) for f in dst)
   # Floating32 re-export may round transformed positions differently by1e-7.
   def key6(x):
    return tuple((tuple(round(a,6) for a in p),tuple(round(a,6) for a in uv)) for p,uv in x[0]),x[1]
   expected6=collections.Counter(key6(k) for k in expected.elements());actual6=collections.Counter(key6(k) for k in actual.elements())
   report['casing_edge_only_expected_geometry_uv_material_matches_1um']=expected6==actual6
 # Resolve texture references by source image name so material-index changes do not create false differences.
 def materials(g):
  def resolve(o):
   if isinstance(o,dict):
    return {k:(g['images'][g['textures'][v]['source']].get('name') if k=='index' and isinstance(v,int) else resolve(v)) for k,v in o.items()}
   if isinstance(o,list):return [resolve(x) for x in o]
   return o
  return {m['name']:resolve(m) for m in g.get('materials',[])}
 sm,cm=materials(sg),materials(cg)
 for n,v in cm.items():
  if n in sm and v!=sm[n]:report['material_changes'].append({'asset':asset,'name':n,'source':sm[n],'candidate':v})
report['normal_drift_max_vector_difference']=max((x['max_normal_vector_difference'] for x in report['normal_only_changes']),default=0)
report['normal_drift_max_angle_degrees_approx']=math.degrees(2*math.asin(report['normal_drift_max_vector_difference']/2))
json.dump(report,open(B/'exact_face_component_diff.json','w'),indent=2)
print(json.dumps({'component_counts':[{ 'node':x['node'],'position_uv_material_changed':len(x['removed_or_position_uv_material_changed_source_ordinals']),'new_triangles':len(x['candidate_changed_or_new_ordinals'])} for x in report['component_diffs']],'normal_only_change_count':len(report['normal_only_changes']),'normal_drift_max_angle_degrees_approx':report['normal_drift_max_angle_degrees_approx'],'material_changes':report['material_changes'],'edge_only_match':report['casing_edge_only_expected_geometry_uv_material_matches_1um']},indent=2))
