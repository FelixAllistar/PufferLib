import json,numpy as np,math
from pathlib import Path
from scipy.spatial import ConvexHull
base=Path(__file__).resolve().parent
m=json.load(open(base/'source_meshes.json'));c=json.load(open(base.parent/'fit_review/source_component_mapping.json'))
def hull(asset,ci,offset=0):
 obj=list(m['seated_hinge_kit/source/assets/'+asset+'.glb']['objects'].values())[0]
 v=np.array(obj['vertices'])[c[asset]['components'][ci]['vertex_ids']][:,[0,2]];v[:,0]+=offset
 v=np.unique(v,axis=0);return v[ConvexHull(v).vertices]
def rotate(p,a):
 a=math.radians(a);return p@np.array([[math.cos(a),-math.sin(a)],[math.sin(a),math.cos(a)]])
def sat_gap(p,q):
 es=np.vstack((p-np.roll(p,1,axis=0),q-np.roll(q,1,axis=0)));axes=np.column_stack((-es[:,1],es[:,0]));axes/=np.linalg.norm(axes,axis=1)[:,None]
 projp=p@axes.T;projq=q@axes.T
 gap=np.maximum(projp.min(0)-projq.max(0),projq.min(0)-projp.max(0))
 return float(gap.max())
p=hull('room_door_leaf_candidate',0);q=hull('room_facade_4m_candidate',3,1.74)
a,b=0,90
for _ in range(60):
 mid=(a+b)/2
 if sat_gap(rotate(p,mid),q)>=0:a=mid
 else:b=mid
out={'method':'SAT of convex projections of actual full source slab and component3 casing vertices; these solids overlap in height and are constant-section away from height bevels','axis':[0,0],'swing':'clockwise viewed from+Y: x=x*cos+z*sin,z=-x*sin+z*cos','first_contact_degrees':(a+b)/2,'signed_sat_gap_90_m':sat_gap(rotate(p,90),q),'source_leaf_sha256':m['seated_hinge_kit/source/assets/room_door_leaf_candidate.glb']['sha256'],'source_leaf_outline_XZ_m':p.tolist(),'source_casing_outline_XZ_m':q.tolist()}
json.dump(out,open(base/'baseline_actual_geometry.json','w'),indent=2)
print(json.dumps({k:v for k,v in out.items() if 'outline' not in k},indent=2))
