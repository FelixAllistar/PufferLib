from pathlib import Path
import zipfile,hashlib,json
from PIL import Image
B=Path(__file__).resolve().parent;C=B/'candidate'
# Preview encoding only; originals kept locally. Full-resolution rendered image remains1200px.
for p in(C/'qa').glob('*.png'):
 if p.name=='remnant_design_preview.png':continue
 Image.open(p).convert('RGB').save(p.with_suffix('.jpg'),quality=92,subsampling=0)
files=[]
for p in C.rglob('*'):
 if p.is_file() and p.suffix not in['.png','.blend1'] and not p.name.startswith('remnant_design_preview') and p.name!='PACKAGE_CONTENTS.json':files.append(p)
files += list((B/'source/LICENSES').glob('*'))
files += [B/'source/assets'/n for n in ['room_door_leaf_candidate.glb','room_facade_4m_candidate.glb','door_optional_detail_overlay.glb','facade_optional_detail_overlay.glb']]
files += [B/'source'/n for n in ['RUNTIME_HANDOFF.md','MATERIAL_BINDINGS.json','SOURCE_MANIFEST.json','PINNED_SOURCE_AUDIT.json']]
files += [B/'fit_review/source_component_mapping.json']
files += list((B/'reused_door_wood').glob('*'))
files += [B/n for n in ['build_candidate.py','inspect_source_only.py','finalize_candidate.py','render_candidate.py','render_bore.py','render_failure.py','render_frame_close.py','render_detached.py','package_candidate.py','bind_render_evidence.py']]
files += [p for p in(B/'independent_validation').glob('*') if p.is_file() and p.suffix in['.py','.json','.md','.txt'] and 'initial' not in p.name]
checks={str(p.relative_to(B)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
receipt={'file_count':len(files),'sha256':checks};(C/'PACKAGE_CONTENTS.json').write_text(json.dumps(receipt,indent=2))
files.append(C/'PACKAGE_CONTENTS.json')
out=B.parent/'ROOM101_HINGE_SEATED_OPTION1_r01_candidate.zip'
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(set(files)):z.write(p,'seated_hinge_kit/'+str(p.relative_to(B)))
with zipfile.ZipFile(out) as z:
 assert z.testzip() is None
 for f,h in checks.items():assert hashlib.sha256(z.read('seated_hinge_kit/'+f)).hexdigest()==h
print(json.dumps({'path':str(out),'bytes':out.stat().st_size,'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'verified_members':len(checks)},indent=2))
