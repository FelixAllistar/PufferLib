import bpy,math,json
from pathlib import Path
from mathutils import Vector,Matrix
B=Path(__file__).resolve().parent/'candidate'
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
def imp(f):
 old=set(bpy.data.objects);bpy.ops.import_scene.gltf(filepath=str(B/'runtime'/f));return list(set(bpy.data.objects)-old)
leaf=imp('room101_leaf_option1.glb');facade=imp('room101_facade_option1.glb');hw=imp('room101_hardware_option1.glb');rem=imp('room101_failure_remnants.glb')
for o in facade:o.location.x+=1.74
for o in rem:o.hide_render=True
s=bpy.context.scene;s.render.engine='CYCLES';s.cycles.samples=48;s.cycles.use_denoising=False;s.render.resolution_x=1200;s.render.resolution_y=1200;s.render.resolution_percentage=100
s.world.color=(.3,.3,.3);s.view_settings.view_transform='AgX'
def area(loc,power,size):
 bpy.ops.object.light_add(type='AREA',location=loc);o=bpy.context.object;o.data.energy=power;o.data.shape='DISK';o.data.size=size;o.rotation_euler=((Vector((.2,0,1))-o.location).to_track_quat('-Z','Y')).to_euler()
area((2,-3,4),550,4);area((-2,-1,2),350,3);area((1,2,3),450,3)
bpy.ops.object.camera_add();cam=bpy.context.object;s.camera=cam;cam.data.type='ORTHO';cam.data.clip_start=.001
def shot(name,loc,target,scale):
 cam.location=loc;cam.rotation_euler=(Vector(target)-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.ortho_scale=scale;s.render.filepath=str(B/'qa'/f'{name}.png');bpy.ops.render.render(write_still=True)
base={o:o.matrix_world.copy() for o in leaf+hw+rem}
leafparts=leaf+[o for o in hw if o.get('owner')=='leaf'];leafrem=[o for o in rem if o.get('owner')=='leaf']
def pose(deg,failed=(),detach=False):
 R=Matrix.Rotation(math.radians(deg),4,'Z')
 if detach:R=Matrix.Translation((.55,-.8,.2))@Matrix.Rotation(math.radians(-30),4,'Y')@R
 for o in leafparts+leafrem:o.matrix_world=R@base[o]
 for o in hw:
  o.hide_render=any(f'H{j:02}' in o.name for j in failed)
 for o in rem:o.hide_render=not any(f'H{j:02}' in o.name for j in failed)
for d in[0,45,90]:
 pose(d);shot(f'intact_{d:02}',(3,-4,2.6),(.4,0,1.1),2.75)
 shot(f'hinge_H02_{d:02}',(.18,-.22,1.23),(0,0,1.10),.19)
pose(45,(1,));shot('failed_H01',(.25,-.28,.34),(0,0,.23),.22)
pose(45,(1,2));shot('last_hinge_H03_only',(3,-4,2.6),(.4,0,1.1),2.75)
pose(20,(1,2,3),True);shot('detached',(3,-4,2.6),(.55,-.35,1.1),3.1)
json.dump({'source':'actual exported GLBs reimported into empty Blender scene','poses':['closed0','45','90','H01failed_at45','H03only_at45','detachedillustrative'],'last_hinge_note':'OnlyH03 survives;45degree yaw about logicalaxis,no unsupported simulated strength/sag claim','detached_note':'Illustrative separation pose,not engine physics validation'},open(B/'qa/render_notes.json','w'),indent=2)
