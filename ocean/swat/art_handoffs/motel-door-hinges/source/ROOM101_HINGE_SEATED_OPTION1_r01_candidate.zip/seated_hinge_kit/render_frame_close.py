exec(open(__file__.replace('render_frame_close.py','render_candidate.py')).read().split('for d in[0,45,90]:')[0])
pose(45,(1,));shot('failed_H01_frame_close',(.04,-.06,.265),(-.022,-.007,.23),.075)
