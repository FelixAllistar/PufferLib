"""Briar Court separate window art revision. Original procedural CC0 artwork.
Run: blender -b -t 1 --python-exit-code 1 --python build_windows.py
Outputs only beside this script. Never writes original batch15 files.
"""
import bpy,bmesh,json,math,hashlib,os
from pathlib import Path
from mathutils import Vector
from math import sin,cos,pi
import numpy as np
ROOT=Path(__file__).resolve().parent
for d in ['assets','textures','qa','previews']:(ROOT/d).mkdir(exist_ok=True)
P=json.loads((ROOT/'approved_proposal.json').read_text())
bpy.ops.wm.read_factory_settings(use_empty=True)
scene=bpy.context.scene;scene.unit_settings.system='METRIC';scene.unit_settings.scale_length=1
M={};OB=[];RECORDS=[];CONTACTS=[];ACTIVE=None

def mat(name,col,rough,metal=0,kind='paint'):
 m=bpy.data.materials.new('BCR1_'+name);m.use_nodes=True;m.diffuse_color=(*col,1)
 bs=m.node_tree.nodes.get('Principled BSDF');bs.inputs['Roughness'].default_value=rough;bs.inputs['Metallic'].default_value=metal
 n=256 if kind=='cloth' else 128;rng=np.random.default_rng(791+sum(map(ord,name)));Y,X=np.mgrid[:n,:n]/n
 f=1+rng.normal(0,.015,(n,n))+.018*np.sin(X*29)*np.cos(Y*21)
 if kind=='cloth':
  f+=.025*np.sin(X*n*pi)+.022*np.sin(Y*n*pi)
  # Faded woven motel drape: narrow woven stripes, sun bleaching and a dusty hem.
  f+=.012*np.cos(X*2*pi*10)+.006*np.cos(X*2*pi*40)
  f-=.16*np.exp(-Y/.075)+.045*np.exp(-(1-Y)/.08)
  f+=.055*np.exp(-((X-.5)/.42)**2)
  f-=.05*np.exp(-((Y-.025)/.008)**2)
 if kind=='wood':f+=.015*np.sin(Y*89+np.sin(X*19))
 if kind=='paint':
  for i in range(55):
   x,y=rng.random(2);f-=rng.uniform(.06,.18)*np.exp(-((X-x)**2/.00003+(Y-y)**2/.0003))
 rgba=np.ones((n,n,4),dtype=np.float32)
 for k in range(3):rgba[:,:,k]=np.clip(col[k]*f,0,1)
 im=bpy.data.images.new('BCR1_'+name, width=n,height=n);im.pixels.foreach_set(rgba.ravel());im.filepath_raw=str(ROOT/'textures'/f'{name}.png');im.file_format='PNG';im.save();im.pack()
 tex=m.node_tree.nodes.new('ShaderNodeTexImage');tex.image=im;m.node_tree.links.new(tex.outputs['Color'],bs.inputs['Base Color'])
 m['physical_substrate']=name;m['runtime_render_owner']='Engine';m['source_alpha_mode']='OPAQUE'
 M[name]=m
for args in [('painted_aluminum',(.64,.60,.48),.66,.25),('painted_steel',(.25,.29,.28),.55,.45),('painted_timber',(.63,.59,.47),.72,0,'wood'),('teal_timber',(.12,.30,.28),.72,0,'wood'),('rubber',(.07,.085,.073),.85,0,'plain'),('cloth',(.49,.42,.32),.96,0,'cloth'),('glass',(.17,.28,.29),.22,.15,'plain')]:mat(*args)
M['glass']['physical_substrate']='monolithic glass';M['glass']['gauge_m']=.0064;M['glass']['engine_binding_required']=True

def mesh(name,vs,fs,material,kind,thickness=None,notes='',smooth=False):
 full=ACTIVE.name+'__r1__'+name
 me=bpy.data.meshes.new(full+'_mesh');me.from_pydata(vs,[],fs);me.update()
 bm=bmesh.new();bm.from_mesh(me);bmesh.ops.remove_doubles(bm,verts=list(bm.verts),dist=1e-9);bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(me);bm.free();me.update()
 ob=bpy.data.objects.new(full,me);ACTIVE.users_collection[0].objects.link(ob);ob.parent=ACTIVE;me.materials.append(M[material])
 uv=me.uv_layers.new(name='UVMap')
 for p in me.polygons:
  p.use_smooth=smooth;axis=max(range(3),key=lambda i:abs(p.normal[i]));axes=[i for i in range(3) if i!=axis]
  for li in p.loop_indices:
   v=me.vertices[me.loops[li].vertex_index].co;uv.data[li].uv=(v[axes[0]]*1.1,v[axes[1]]*1.1)
 ob['component_id']=full;ob['physical_substrate']=material;ob['component_kind']=kind;ob['support_notes']=notes;ob['revision']='separate_r1';ob['original_asset_unchanged']=True
 if thickness is not None:ob['nominal_material_thickness_m']=thickness
 if kind=='curtain_panel':ob['thickness_basis']='0.6 mm Y-direction shell offset; normal textile gauge varies on slopes'
 ob['engine_ownership_note']='No collision, render, destruction or physics-volume binding supplied; Engine owns implementation'
 OB.append(ob);RECORDS.append({'id':full,'asset':ACTIVE.name,'kind':kind,'substrate':material,'nominal_material_thickness_m':thickness,'support_notes':notes,'engine_bindings':{'collider':None,'collision_enabled':None,'render_binding':None,'destruction_binding':None,'physics_volume_assignment':None}})
 return ob

def box(name,lo,hi,mat,kind='support',thickness=None,notes=''):
 x,y,z=lo;X,Y,Z=hi
 return mesh(name,[(x,y,z),(X,y,z),(X,Y,z),(x,Y,z),(x,y,Z),(X,y,Z),(X,Y,Z),(x,Y,Z)],[(0,3,2,1),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)],mat,kind,thickness,notes)

def rod(name,a,b,r,mat='painted_steel',n=12,kind='hardware',notes=''):
 a=Vector(a);b=Vector(b);d=b-a;rot=d.to_track_quat('Z','Y').to_matrix()
 vs=[tuple(a+rot@Vector((r*cos(i*2*pi/n),r*sin(i*2*pi/n),z))) for z in [0,d.length] for i in range(n)]
 fs=[tuple(reversed(range(n))),tuple(range(n,2*n))]+[(i,(i+1)%n,n+(i+1)%n,n+i) for i in range(n)]
 return mesh(name,vs,fs,mat,kind,2*r,notes)

def profile(name,axis,span,rects,cuts,mat,kind='frame_profile',notes=''):
 # Closed extrusion of union(rectangles) minus cuts. Grid caps contain no interior volume faces.
 # Rectangles use (u_min,Y_min,u_max,Y_max); U=X for verticals, U=Z for horizontals.
 xx=sorted(set(v for r in rects+cuts for v in [r[0],r[2]]));yy=sorted(set(v for r in rects+cuts for v in [r[1],r[3]]))
 occ=set()
 for i in range(len(xx)-1):
  for j in range(len(yy)-1):
   x=(xx[i]+xx[i+1])/2;y=(yy[j]+yy[j+1])/2
   inside=lambda r:r[0]<x<r[2] and r[1]<y<r[3]
   if any(inside(r) for r in rects) and not any(inside(r) for r in cuts):occ.add((i,j))
 vs=[];fs=[];cache={}
 def V(i,j,k):
  key=(i,j,k)
  if key not in cache:
   cache[key]=len(vs);u,y,t=xx[i],yy[j],span[k];vs.append((u,y,t) if axis=='Z' else (t,y,u))
  return cache[key]
 for i,j in sorted(occ):
  fs += [(V(i,j,0),V(i+1,j,0),V(i+1,j+1,0),V(i,j+1,0)),(V(i,j,1),V(i,j+1,1),V(i+1,j+1,1),V(i+1,j,1))]
  for di,dj,edge in [(-1,0,[(i,j),(i,j+1)]),(1,0,[(i+1,j+1),(i+1,j)]),(0,-1,[(i+1,j),(i,j)]),(0,1,[(i,j+1),(i+1,j+1)])]:
   if (i+di,j+dj) not in occ:
    (a,b),(c,d)=edge;fs.append((V(a,b,0),V(c,d,0),V(c,d,1),V(a,b,1)))
 ob=mesh(name,vs,fs,mat,kind,.002,notes)
 # Coplanar dissolve reduces only redundant grid subdivisions; preserves actual cavities.
 bm=bmesh.new();bm.from_mesh(ob.data);bmesh.ops.dissolve_limit(bm,angle_limit=1e-7,verts=list(bm.verts),edges=list(bm.edges),use_dissolve_boundaries=False);bm.to_mesh(ob.data);bm.free();ob.data.update()
 return ob

def section_parts(name,axis,span,umin,umax,ymin,ymax,open_edges,gc,mat='painted_aluminum'):
 # open_edges = [(edge_u, inward_sign, pocket_depth)] sign points into material.
 e=gc-.0032;i=gc+.0032;g0=e-.002;g1=i+.002;s1=g1+.002
 rects=[(umin,ymin,umax,ymin+.002),(umin,ymax-.002,umax,ymax),(umin,ymin,umin+.002,ymax),(umax-.002,ymin,umax,ymax)]
 cuts=[];stops=[]
 for idx,(edge,sign,depth) in enumerate(open_edges):
  rear=edge+sign*depth;outer=rear+sign*.002;lo,hi=sorted([edge,rear]);bl,bh=sorted([rear,outer])
  cuts.append((min(edge,outer),g0,max(edge,outer),s1))
  # Add fixed exterior lip and a back web ending at the underside of removable stop.
  rects.extend([(min(edge,outer),g0-.002,max(edge,outer),g0),(bl,g0-.002,bh,g1)])
  stops.append((idx,min(edge,outer),max(edge,outer),g1,s1))
 # Cuts apply to original tube, while fixed lips/back webs are added afterwards via grid occupancy.
 # Build tube with cuts, then union lip/back web by passing dedicated add-backs to grid geometry helper.
 ob=profile_addbacks(name,axis,span,rects[:4],cuts,rects[4:],mat,notes='2 mm hollow frame; true edge glazing pockets; fixed exterior lip and stepped backing web')
 for idx,lo,hi,a,b in stops:
  if axis=='Z':box(name+f'_interior_stop_{idx}',[lo,a,span[0]],[hi,b,span[1]],mat,'removable_glazing_stop',.002,'Seats on pocket backing web; retained by named end/stop screws')
  else:box(name+f'_interior_stop_{idx}',[span[0],a,lo],[span[1],b,hi],mat,'removable_glazing_stop',.002,'Seats on pocket backing web; retained by named end/stop screws')
 # Two discrete stop screws sit on the 2 mm backing web, outside pane edges.
 for idx,(edge,sign,depth) in enumerate(open_edges):
  u=edge+sign*(depth+.001)
  for k,f in enumerate([.20,.80]):
   t=span[0]+f*(span[1]-span[0]);a=(u,g1+.003,t) if axis=='Z' else (t,g1+.003,u);b=(u,g0-.001,t) if axis=='Z' else (t,g0-.001,u)
   rod(name+f'_stop_screw_{idx}_{k}',a,b,.00065,n=6,kind='fastener',notes='Intentionally embeds matching interior stop and 2 mm profile backing web; outside pane edge')
 return ob

def profile_addbacks(name,axis,span,base,cuts,adds,mat,notes=''):
 # Convert (base minus cuts) plus adds to disjoint union rectangles; profile() performs welding and extrusion.
 xx=sorted(set(v for r in base+cuts+adds for v in [r[0],r[2]]));yy=sorted(set(v for r in base+cuts+adds for v in [r[1],r[3]]));rr=[]
 for i in range(len(xx)-1):
  for j in range(len(yy)-1):
   x=(xx[i]+xx[i+1])/2;y=(yy[j]+yy[j+1])/2
   inside=lambda r:r[0]<x<r[2] and r[1]<y<r[3]
   if (any(inside(r) for r in base) and not any(inside(r) for r in cuts)) or any(inside(r) for r in adds):rr.append((xx[i],yy[j],xx[i+1],yy[j+1]))
 return profile(name,axis,span,rr,[],mat,notes=notes)

def glass_and_retention(q,daylight):
 lo,hi=q['aabb_source_m'];name=q['id'];x0,y0,z0=lo;x1,y1,z1=hi;d0,d1,e0,e1=daylight
 box(name,lo,hi,'glass','glass_pane',.0064,'Monolithic 6.4 mm; supported by two bottom blocks, face gaskets and perimeter lips/stops; no safety designation')
 # Four nonoverlapping gasket bands per face, matching actual hidden glass margins.
 for side,(ya,yb) in [('exterior',(y0-.002,y0)),('interior',(y1,y1+.002))]:
  for label,a,b in [('left',[x0,ya,z0],[d0,yb,z1]),('right',[d1,ya,z0],[x1,yb,z1]),('bottom',[d0,ya,z0],[d1,yb,e0]),('top',[d0,ya,e1],[d1,yb,z1])]:
   box(name+'_'+side+'_gasket_'+label,a,b,'rubber','face_gasket',.002,'Exact face contact with glass and fixed lip/removable stop; 12 mm pane edge bite')
 for k,f in enumerate([.25,.75]):
  xc=x0+f*(x1-x0);yc=(y0+y1)/2
  box(name+f'_setting_block_{k}',[xc-.025,yc-.005,z0-.003],[xc+.025,yc+.005,z0],'rubber','setting_block',.003,'Top contacts pane underside; underside contacts pocket floor')

def root(name):
 global ACTIVE
 ACTIVE=bpy.data.objects.new(name,None);collection=bpy.data.collections.new(name+'_EDITABLE');scene.collection.children.link(collection);collection.objects.link(ACTIVE);ACTIVE['original_asset_identity']=name;ACTIVE['revision']='separate_realistic_r1';ACTIVE['units']='metres';ACTIVE['source_basis']='Z-up, front -Y';ACTIVE['original_frozen']=True
 ACTIVE['connections']=([{'name':'opening_origin','position_source_m':[0,0,0],'outward_source':[0,1,0]}] if name=='room_window_insert' else [{'name':'left','position_source_m':[-2,0,0],'outward_source':[-1,0,0]},{'name':'right','position_source_m':[2,0,0],'outward_source':[1,0,0]},{'name':'roof','position_source_m':[0,0,2.8],'outward_source':[0,0,1]}])
 for c in ACTIVE['connections']:
  v=c['position_source_m'];n=c['outward_source'];c['position_gltf_m']=[v[0],v[2],-v[1]];c['outward_gltf']=[n[0],n[2],-n[1]]
 return ACTIVE

# ROOM: original full envelope, no opaque intersections used to fake a pocket.
root('room_window_insert')
box('timber_sill',[-1.035,-.185,-.0085],[1.035,.065,.0245],'painted_timber','sill',.033,'Supports frame at Z=.0245; preserved original outer bounds; edge topology differs')
section_parts('left_jamb','Z',[.0245,1.298],-1,-.96,-.06,.06,[(-.96,-1,.015)],-.020)
section_parts('right_jamb','Z',[.0245,1.298],.96,1,-.06,.06,[(.96,1,.015)],-.020)
box('left_jamb_top_cap',[-1,-.06,1.298],[-.96,.06,1.3],'painted_aluminum','end_cap',.002,'Closes hollow jamb top; meets shortened jamb at1.298, preserves full1.3 height')
box('right_jamb_top_cap',[.96,-.06,1.298],[1,.06,1.3],'painted_aluminum','end_cap',.002,'Closes hollow jamb top; meets shortened jamb at1.298, preserves full1.3 height')
section_parts('bottom_rail','X',[-.96,.96],.0245,.05,-.06,.06,[(.05,-1,.015)],-.020)
section_parts('head_rail','X',[-.96,.96],1.25,1.30,-.06,.06,[(1.25,1,.015)],-.020)
# Narrow central fabricated section has shared 2 mm web and two 13 mm pockets.
# Main tube plus lips/backing; removable full-width rear stop bridges central web.
gc=-.020;g0=-.0252;g1=-.0148
base=[(-.014,-.065,.014,-.063),(-.014,.023,.014,.025),(-.014,-.065,-.012,.025),(.012,-.065,.014,.025)]
cut=[(-.014,g0,.014,-.0128)]
adds=[(-.014,-.0272,.014,-.0252),(-.001,-.0272,.001,-.0148)]
profile_addbacks('center_steel_divider','Z',[.05,1.25],base,cut,adds,'painted_steel','Fabricated steel 2 mm web; true opposed pockets; 1 mm clearance to each glass edge')
box('center_steel_divider_interior_stop',[-.014,-.0148,.05],[.014,-.0128,1.25],'painted_steel','removable_glazing_stop',.002,'Bridges 2 mm central web; end screws on centerline remain between glass panes')
for q in P['assets']['room_window_insert']['proposed_panes']:
 left=q['id'].endswith('left');glass_and_retention(q,[-.96,-.014,.05,1.25] if left else [.014,.96,.05,1.25])

# Selected visible screws and real underlying supports, kept well clear of glazing.
for side,x in [('left',-.980),('right',.980)]:
 for k,z in enumerate([.15,1.15]):
  rod(f'{side}_jamb_fixing_{k}',(x,.062,z),(x,.040,z),.0025,n=6,kind='fastener',notes='Head seats at rear frame face; shank embeds frame backing, no glass contact')
  box(f'{side}_jamb_backing_{k}',[x-.008,.038,z-.009],[x+.008,.058,z+.009],'painted_aluminum','backing_block',.016,'Inside hollow frame; screw receiving insert')
# Cleats join four frame corners behind glazing pockets and support divider ends.
for side,x in [('left',-.95),('right',.95)]:
 for k,z in enumerate([.035,1.28]):
  box(f'{side}_corner_cleat_{k}',[x-.010,.030,z-.008],[x+.010,.058,z+.008],'painted_aluminum','joint_cleat',.002,'Contacts jamb/rail interior; intended joint support')
  rod(f'{side}_corner_cleat_fixing_{k}',(x,.062,z),(x,.036,z),.0015,n=6,kind='fastener',notes='Embeds rear rail wall and corner cleat')
for k,z in enumerate([.05,1.25]):
 box(f'divider_end_cleat_{k}',[-.010,.025,z if k==0 else z-.002],[.010,.058,z+.002 if k==0 else z],'painted_steel','joint_cleat',.002,'Horizontal 2 mm end plate: face contact with rail and divider rear wall; no solid overlap')
 rod(f'divider_end_cleat_fixing_{k}',(0,.040,z+(.004 if k==0 else -.004)),(0,.040,z+(-.004 if k==0 else .004)),.001,n=6,kind='fastener',notes='Embeds divider end plate and rail wall')
 rod(f'divider_stop_screw_{k}',(0,-.0108,z+(.008 if k==0 else -.008)),(0,-.025,z+(.008 if k==0 else -.008)),.0007,n=6,kind='fastener',notes='Embeds stop and central web inside 4 mm pane-to-pane gap')

# Curtain geometry uses analytic tubular rings and a separate swept fabric loop;
# all pieces are closed thin shells, not double-sided zero-gauge planes.
def ring(name,x):
 vs=[];fs=[];N=12;K=4;cy=.040;cz=1.229;R=.008;r=.001
 for i in range(N):
  a=2*pi*i/N
  for j in range(K):
   b=2*pi*j/K;vs.append((x+r*sin(b),cy+(R+r*cos(b))*sin(a),cz+(R+r*cos(b))*cos(a)))
 for i in range(N):
  for j in range(K):fs.append((i*K+j,((i+1)%N)*K+j,((i+1)%N)*K+(j+1)%K,i*K+(j+1)%K))
 return mesh(name,vs,fs,'painted_steel','curtain_ring',.002,'Inner upper surface contacts rod; center 1 mm below axis')

def fabric_panel(name,l,r):
 N=40;rows=[0,.35,.70,1];vs=[];phase=.4 if l<0 else 1.7
 for thick in [-.0003,.0003]:
  for v in rows:
   for k in range(N+1):
    u=k/N;x=l+(r-l)*u
    hem=.060+.0025*(1+sin(u*8+phase))+.0015*(1+sin(u*21+phase))
    z=hem+(1.219-hem)*v
    # Top mean-Y crossings remain exactly at the five ring stations.
    warped=u+.012*sin(10*pi*u)*sin(4.3*u+phase)+.025*sin(2*pi*u+phase)*(1-v)**2
    amp=(.0074+.0015*sin(5.7*u+phase)**2)*(1+.08*sin(pi*v+u*5))
    y=.040+amp*sin(10*pi*warped)+thick;vs.append((x,y,z))
 stride=N+1;nr=len(rows);layer=nr*stride;fs=[]
 for side in range(2):
  off=side*layer
  for j in range(nr-1):
   for k in range(N):fs.append((off+j*stride+k,off+j*stride+k+1,off+(j+1)*stride+k+1,off+(j+1)*stride+k))
 for k in range(N):
  fs.append((k,k+layer,k+1+layer,k+1));a=(nr-1)*stride+k;fs.append((a,a+1,a+1+layer,a+layer))
 for k in [0,N]:
  for j in range(nr-1):a=j*stride+k;b=(j+1)*stride+k;fs.append((a,b,b+layer,a+layer))
 ob=mesh(name,vs,fs,'cloth','curtain_panel',.0006,'Thin irregular folds with gentle vertical drift and soft upward hem; fixed mean-Y top loop stations; all inside approved envelope')
 for poly in ob.data.polygons:
  for li in poly.loop_indices:
   v=ob.data.vertices[ob.data.loops[li].vertex_index].co;ob.data.uv_layers.active.data[li].uv=((v.x-l)/(r-l),(v.z-.06)/(1.219-.06))
 return ob

rod('curtain_rod',(-.955,.040,1.230),(.955,.040,1.230),.006,n=12,notes='Ends engage 5 mm in snug-fit sockets; rings bear on upper surface')
for side,(a,b) in [('left',(-.958,-.950)),('right',(.950,.958))]:
 # Annular prism along X, exact matching angular stations with rod.
 vs=[];fs=[];n=12
 for x in [a,b]:
  for r in [.006,.008]:
   for i in range(n):vs.append((x,.04+r*cos(i*2*pi/n),1.23+r*sin(i*2*pi/n)))
 for i in range(n):
  j=(i+1)%n;fs += [(i,j,2*n+j,2*n+i),(n+i,3*n+i,3*n+j,n+j),(i,n+i,n+j,j),(2*n+i,2*n+j,3*n+j,3*n+i)]
 mesh(side+'_rod_socket',vs,fs,'painted_steel','rod_socket',.002,'12 mm ID / 16 mm OD; 8 mm tube + 2 mm tab form original 10 mm inward support reach; 5 mm rod engagement; snug bore contact')
 lo,hi=([-.960,.032,1.210],[-.958,.048,1.245]) if side=='left' else ([.958,.032,1.210],[.960,.048,1.245])
 box(side+'_socket_mounting_tab',lo,hi,'painted_steel','bracket',.002,'Socket end face contacts this jamb-mounted tab')
 x=-.970 if side=='left' else .970
 box(side+'_socket_backing',[x-.008,.030,1.210],[x+.008,.050,1.245],'painted_aluminum','backing_block',.016,'Backs mounting screws inside jamb')
 for k,z in enumerate([1.214,1.241]):
  s=-1 if side=='left' else 1;rod(side+f'_socket_screw_{k}',(s*.958,.04,z),(s*.976,.04,z),.0015,n=6,kind='fastener',notes='Embeds mounting tab and jamb backing; no glass contact')
for side,l,r in [('left',-.90,-.52),('right',.52,.90)]:fabric_panel(side+'_curtain',l,r)
for k,x in enumerate(P['assets']['room_window_insert']['curtain']['ring_x_centers_m']):
 wire=ring(f'curtain_ring_{k:02}',x)
 # Clip the ACTUAL tessellated ring triangles, then offset that surface outward.
 # Inner loop faces therefore share the wire surface exactly, rather than using
 # a second analytically circular surface that can cross polygonal ring facets.
 wire.data.calc_loop_triangles();tris=[]
 def clip(poly,axis,value,greater):
  out=[]
  for a,b in zip(poly,poly[1:]+poly[:1]):
   da=(a[axis]-value)*(1 if greater else -1);db=(b[axis]-value)*(1 if greater else -1)
   if da>=-1e-12:out.append(a)
   if (da>=0)!=(db>=0):out.append(a+(b-a)*(da/(da-db)))
  return out
 for tri in wire.data.loop_triangles:
  vv=[Vector(wire.data.vertices[t].co) for t in tri.vertices]
  if max(v.z for v in vv)>1.224:continue
  vv=clip(clip(vv,1,.039,True),1,.041,False)
  for j in range(1,len(vv)-1):
   if (vv[j]-vv[0]).cross(vv[j+1]-vv[0]).length>1e-14:tris.append([vv[0],vv[j],vv[j+1]])
 vs=[];fs=[];lookup={}
 def vi(v):
  key=tuple(round(t,10) for t in v)
  if key not in lookup:lookup[key]=len(vs);vs.append(tuple(v))
  return lookup[key]
 for t in tris:fs.append(tuple(vi(v) for v in t))
 inner_n=len(vs);center=[Vector((x,.04+.008*sin(a),1.229+.008*cos(a))) for a in [pi-pi/6,pi,pi+pi/6]]
 for v in list(vs):
  p=Vector(v);best=None
  for a,b in zip(center,center[1:]):
   d=b-a;t=max(0,min(1,(p-a).dot(d)/d.length_squared));q=a+t*d
   if best is None or (p-q).length<(p-best).length:best=q
  n=(p-best).normalized();vs.append(tuple(p+n*.0006))
 edges={}
 for f in fs:
  for a,b in zip(f,f[1:]+f[:1]):
   key=tuple(sorted([a,b]));edges[key]=edges.get(key,0)+1
 inner_fs=list(fs);fs.extend(tuple(i+inner_n for i in reversed(f)) for f in inner_fs)
 for (a,b),count in edges.items():
  if count==1:fs.append((a,b,b+inner_n,a+inner_n))
 mesh(f'curtain_sewn_loop_{k:02}',vs,fs,'cloth','sewn_loop',.0006,'Inner shell copied from clipped actual ring triangles; outward 0.6 mm nominal radial thickness; measured envelope in manifest')
 box(f'curtain_stitch_tab_{k:02}',[x-.001,.0397,1.2185],[x+.001,.0403,1.2195],'cloth','sewn_tab',.0006,'Stitched overlap with main panel and loop lower surface; textile seam contact only')

# LOBBY. Left doorway remains wholly empty between X=-1.94 and -0.67.
root('lobby_glazed_facade')
box('teal_timber_header',[-2,-.09,2.4],[2,.09,2.8],'teal_timber','header',.18,'Fictional solid timber header; no structural sizing claim')
for name,x,edges in [('door_outer_post',-1.97,[]),('door_glazing_post',-.64,[(-.61,-1,.015)]),('middle_post',.65,[(.62,1,.015),(.68,-1,.015)]),('right_post',1.97,[(1.94,1,.015)])]:
 section_parts(name,'Z',[.002,2.398],x-.03,x+.03,-.06,.06,edges,.020)
for bay,(x0,x1) in [('left',(-.61,.62)),('right',(.68,1.94))]:
 for name,lo,hi,edges in [('base_rail',0,.08,[(.08,-1,.015)]),('middle_rail',.73,.77,[(.73,1,.015),(.77,-1,.015)]),('head_rail',2.34,2.4,[(2.34,1,.015)])]:section_parts(bay+'_'+name,'X',[x0,x1],lo,hi,-.06,.06,edges,.020)
for q in P['assets']['lobby_glazed_facade']['proposed_panes']:
 left='_left_' in q['id'];low=q['id'].endswith('lower');glass_and_retention(q,[-.61,.62,.08,.73] if left and low else [-.61,.62,.77,2.34] if left else [.68,1.94,.08,.73] if low else [.68,1.94,.77,2.34])
# Internal support blocks/visible rear-side fixings; no fastener crosses doorway clear bounds.
for k,x in enumerate([-1.97,-.64,.65,1.97]):
 box(f'post_{k}_base_insert',[x-.03,-.06,0],[x+.03,.06,.002],'painted_aluminum','base_support',.002,'Flush 2 mm base cap contacts post end at Z=.002 and floor interface at Z=0')
 box(f'post_{k}_head_insert',[x-.03,-.06,2.398],[x+.03,.06,2.4],'painted_aluminum','head_support',.002,'2 mm head cap contacts post end and timber header underside at2.4')
 rod(f'post_{k}_floor_interface_fixing',(x,.04,.004),(x,.04,0),.0025,n=6,kind='fastener',notes='Embeds base cap; shank terminates at floor interface, receiving floor not part of asset')
 rod(f'post_{k}_header_fixing',(x,.04,2.396),(x,.04,2.415),.0025,n=6,kind='fastener',notes='Embeds head cap and timber header')
 for end,z in [('base',.035),('head',2.365)]:
  box(f'post_{k}_{end}_fixing_backing',[x-.012,.034,z-.006],[x+.012,.058,z+.006],'painted_aluminum','backing_block',.024,'Contacts rear post inner wall; receives fixing shank')
  rod(f'post_{k}_{end}_fixing',(x,.062,z),(x,.04,z),.003,n=6,kind='fastener',notes='Rear head and shank embedded in named post support; outside doorway')
for bay,(x0,x1) in [('left',(-.61,.62)),('right',(.68,1.94))]:
 for k,z in enumerate([.035,.75,2.37]):
  for side,x in [('left',x0),('right',x1)]:
   box(f'{bay}_{side}_rail_shear_{k}',[x if side=='left' else x-.018,-.058,z-.008],[x+.018 if side=='left' else x,-.042,z+.008],'painted_aluminum','joint_shear_block',.016,'Inside rail: bears against post face and rail front inner wall with no solid overlap')
   rod(f'{bay}_{side}_rail_joint_fixing_{k}',(x+(.006 if side=='left' else -.006),-.050,z),(x+(-.006 if side=='left' else .006),-.050,z),.00125,n=6,kind='fastener',notes='Intentionally embeds named shear block and adjacent post wall at butt joint')
# Original OFFICE typography rebuilt from original pixel lettering proportions.
FONT={'O':['01110','10001','10001','10001','10001','10001','01110'],'F':['11111','10000','10000','11110','10000','10000','10000'],'I':['111','010','010','010','010','010','111'],'C':['01111','10000','10000','10000','10000','10000','01111'],'E':['11111','10000','10000','11110','10000','10000','11111']}
# Match source font exactly where source uses 5-column I (read provenance-copied data below if present).
fontfile=ROOT/'office_font.json'
if fontfile.exists():FONT=json.loads(fontfile.read_text())
unit=.22/7;txt='OFFICE';w=sum(len(FONT[ch][0])+1 for ch in txt)*unit-unit;x=-w/2;idx=0
for ch in txt:
 for j,row in enumerate(FONT[ch]):
  start=None
  for i,val in enumerate(row+'0'):
   if val=='1' and start is None:start=i
   if val=='0' and start is not None:
    xa=x+start*unit;xb=x+i*unit;zc=2.61+(3-j)*unit
    box(f'office_bar_{idx:02}',[xa,-.1005,zc-unit*.48],[xb,-.0915,zc+unit*.48],'painted_aluminum','lettering',.009,'Original OFFICE linework envelope retained')
    box(f'office_pad_{idx:02}',[xa,-.0915,zc-unit*.48],[xb,-.09,zc+unit*.48],'rubber','adhesive_pad',.0015,'Direct contact lettering back and header front; fills original gap')
    idx+=1;start=None
 x+=(len(FONT[ch][0])+1)*unit

# Named support relations and actual source mesh snapshot; runtime reimport audit remains separate.
roots=[o for o in scene.objects if o.type=='EMPTY']
RUNTIME_MAP={};RUNTIME_STATS={}
for r in roots:
 children=[o for o in OB if o.parent==r];groups={};temporary=[];selected=[]
 for ob in children:
  ob.data.calc_loop_triangles()
  if ob['component_kind']=='glass_pane':
   selected.append(ob);RUNTIME_MAP[ob.name]={'node_name':ob.name,'mesh_name':ob.data.name,'primitive_index':0,'triangle_range_half_open':[0,len(ob.data.loop_triangles)],'index_range_half_open':[0,3*len(ob.data.loop_triangles)]}
  else:groups.setdefault(ob.data.materials[0].name,[]).append(ob)
 for material,parts in groups.items():
  name=r.name+'__runtime__'+material;vv=[];ff=[];uvs=[];cursor=0
  for ob in parts:
   me=ob.data;start=cursor
   for t in me.loop_triangles:
    ids=[]
    for vi,li in zip(t.vertices,t.loops):
     ids.append(len(vv));vv.append(tuple(me.vertices[vi].co));uvs.append(tuple(me.uv_layers.active.data[li].uv))
    ff.append(tuple(ids));cursor+=1
   RUNTIME_MAP[ob.name]={'node_name':name,'mesh_name':name+'_mesh','primitive_index':0,'triangle_range_half_open':[start,cursor],'index_range_half_open':[start*3,cursor*3]}
  me=bpy.data.meshes.new(name+'_mesh');me.from_pydata(vv,[],ff);me.materials.append(bpy.data.materials[material]);me.update();uv=me.uv_layers.new(name='UVMap')
  for p in me.polygons:
   for li in p.loop_indices:uv.data[li].uv=uvs[me.loops[li].vertex_index]
  ob=bpy.data.objects.new(name,me);scene.collection.objects.link(ob);ob.parent=r;ob['component_ranges']=json.dumps({o['component_id']:RUNTIME_MAP[o.name]['triangle_range_half_open'] for o in parts});ob['engine_bindings']='UNASSIGNED';ob['render_batch_only']=True
  temporary.append(ob);selected.append(ob)
 for ob in scene.objects:ob.select_set(False)
 r.select_set(True)
 for ob in selected:ob.select_set(True)
 bpy.context.view_layer.objects.active=r
 bpy.ops.export_scene.gltf(filepath=str(ROOT/'assets'/(r.name+'_realistic_r1.glb')),export_format='GLB',use_selection=True,export_yup=True,export_extras=True,export_animations=False,export_cameras=False,export_lights=False)
 RUNTIME_STATS[r.name]={'mesh_nodes':len(selected),'material_batches':len(groups),'separate_glass_nodes':sum(o['component_kind']=='glass_pane' for o in children),'estimated_material_primitive_draws':len(selected)}
 for ob in temporary:
  me=ob.data;bpy.data.objects.remove(ob,do_unlink=True);bpy.data.meshes.remove(me)
for row,ob in zip(RECORDS,OB):
 me=ob.data;me.calc_loop_triangles();vv=[list(v.co) for v in me.vertices]
 row['thickness_basis']=ob.get('thickness_basis','nominal model dimension; see support notes');row['source_object_name']=ob.name;row['runtime_mapping']=RUNTIME_MAP[ob.name]
 row['aabb_source_m']=[[min(v[k] for v in vv) for k in range(3)],[max(v[k] for v in vv) for k in range(3)]];row['triangles']=len(me.loop_triangles);row['material']=me.materials[0].name
snapshot={o['component_id']:{'source_object_name':o.name,'asset':o.parent.name,'positions_source_m':[list(v.co) for v in o.data.vertices],'triangles':[list(t.vertices) for t in o.data.loop_triangles],'triangle_corner_uvs':[[list(o.data.uv_layers.active.data[li].uv) for li in t.loops] for t in o.data.loop_triangles],'root_transform_source':[[float(v) for v in row] for row in o.parent.matrix_world],'material':o.data.materials[0].name} for o in OB}
(ROOT/'qa'/'source_mesh_snapshot.json').write_text(json.dumps(snapshot,separators=(',',':')))
manifest={'schema':'briar_court_separate_window_revision_r1','status':'IMPLEMENTATION CANDIDATE; parent QA required','units':'metres','basis':'source X right, Y roomward, Z up; glTF (x,z,-y)','original_assets_modified':False,'glass_runtime_behavior':'Separate opaque placeholder material. Engine owns transparency, lighting, collision, damage and placement.','runtime_grouping':RUNTIME_STATS,'components':RECORDS,'assets':{r.name:{'file':'assets/'+r.name+'_realistic_r1.glb','triangles':sum(x['triangles'] for x in RECORDS if x['asset']==r.name),'component_count':sum(x['asset']==r.name for x in RECORDS),'sha256':hashlib.sha256((ROOT/'assets'/(r.name+'_realistic_r1.glb')).read_bytes()).hexdigest()} for r in roots}}
(ROOT/'component_manifest.json').write_text(json.dumps(manifest,indent=2))
scene['artifact']='Briar Court separate realistic window revision R1';scene['license']='CC0-1.0';scene['no_engine_bindings']=True
bpy.data.collections['lobby_glazed_facade_EDITABLE'].hide_viewport=True;bpy.data.collections['lobby_glazed_facade_EDITABLE'].hide_render=True
bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/'briar_court_windows_realistic_r1.blend'))
print('BUILT',json.dumps(manifest['assets']))
