"""Declare intended component contacts by exact source names; geometric checks are separate."""
import json,re
from pathlib import Path
R=Path(__file__).resolve().parent;manifest=json.loads((R/'component_manifest.json').read_text());names={q['id'] for q in manifest['components']};pairs=[]
def add(asset,a,b,kind='surface_contact',note=''):
 a=asset+'__r1__'+a;b=asset+'__r1__'+b
 assert a in names,a;assert b in names,b
 pairs.append({'a':a,'b':b,'kind':kind,'note':note})
for asset,data in json.loads((R/'approved_proposal.json').read_text())['assets'].items():
 for q in data['proposed_panes']:
  pane=q['id']
  if asset=='room_window_insert':
   left=pane.endswith('left');side={'left':('left_jamb',0) if left else ('center_steel_divider',None),'right':('center_steel_divider',None) if left else ('right_jamb',0),'bottom':('bottom_rail',0),'top':('head_rail',0)}
  else:
   left='_left_' in pane;low=pane.endswith('lower');bay='left' if left else 'right'
   side={'left':('door_glazing_post',0) if left else ('middle_post',1),'right':('middle_post',0) if left else ('right_post',0),'bottom':(bay+'_base_rail',0) if low else (bay+'_middle_rail',1),'top':(bay+'_middle_rail',0) if low else (bay+'_head_rail',0)}
  for edge,(frame,idx) in side.items():
   for face in ['exterior','interior']:
    gasket=pane+'_'+face+'_gasket_'+edge;add(asset,pane,gasket)
    support=frame if face=='exterior' else frame+'_interior_stop'+('' if idx is None else '_'+str(idx));add(asset,gasket,support)
  for k in range(2):add(asset,pane,pane+f'_setting_block_{k}');add(asset,pane+f'_setting_block_{k}',side['bottom'][0])
for row in manifest['components']:
 a=row['asset'];n=row['id'].split('__r1__',1)[1]
 if row['kind']=='removable_glazing_stop':add(a,n,n.split('_interior_stop')[0])
 if row['kind']=='lettering':add(a,n,n.replace('office_bar','office_pad'));add(a,n.replace('office_bar','office_pad'),'teal_timber_header')
 if row['kind']=='fastener':
  hosts=[]
  if '_stop_screw_' in n and not n.startswith('divider_'):
   base,k=n.split('_stop_screw_');idx=k.split('_')[0];hosts=[base,base+'_interior_stop_'+idx]
  elif n.startswith('divider_stop_screw_'):hosts=['center_steel_divider','center_steel_divider_interior_stop']
  elif '_jamb_fixing_' in n:
   side,k=n.split('_jamb_fixing_');hosts=[side+'_jamb',side+'_jamb_backing_'+k]
  elif '_corner_cleat_fixing_' in n:
   side,k=n.split('_corner_cleat_fixing_');hosts=[side+'_corner_cleat_'+k,'bottom_rail' if k=='0' else 'head_rail']
  elif n.startswith('divider_end_cleat_fixing_'):
   k=n.rsplit('_',1)[1];hosts=['divider_end_cleat_'+k,'bottom_rail' if k=='0' else 'head_rail']
  elif '_socket_screw_' in n:
   side,k=n.split('_socket_screw_');hosts=[side+'_socket_mounting_tab',side+'_socket_backing',side+'_jamb']
  elif n.startswith('post_'):
   k=int(n.split('_')[1]);post=['door_outer_post','door_glazing_post','middle_post','right_post'][k]
   if n.endswith('_floor_interface_fixing'):hosts=[f'post_{k}_base_insert']
   elif n.endswith('_header_fixing'):hosts=[f'post_{k}_head_insert','teal_timber_header']
   else:
    end=n.split('_')[2];hosts=[post,f'post_{k}_{end}_fixing_backing']
  elif '_rail_joint_fixing_' in n:
   bay,side=n.split('_')[:2];k=n.rsplit('_',1)[1];post={('left','left'):'door_glazing_post',('left','right'):'middle_post',('right','left'):'middle_post',('right','right'):'right_post'}[(bay,side)];hosts=[f'{bay}_{side}_rail_shear_{k}',post]
  assert hosts,n
  for h in hosts:add(a,n,h,'intentional_fastener_embed','Only declared fastener shanks may overlap these rigid hosts; no glass/cloth exception')
a='room_window_insert'
for side in ['left','right']:
 add(a,side+'_jamb_top_cap',side+'_jamb');add(a,side+'_jamb_top_cap',side+'_jamb_interior_stop_0');add(a,side+'_jamb_top_cap','head_rail');add(a,side+'_jamb','timber_sill');add(a,side+'_jamb','head_rail');add(a,side+'_jamb','bottom_rail')
 add(a,side+'_rod_socket','curtain_rod');add(a,side+'_rod_socket',side+'_socket_mounting_tab');add(a,side+'_socket_mounting_tab',side+'_jamb');add(a,side+'_socket_backing',side+'_jamb')
 for k in range(2):add(a,side+f'_jamb_backing_{k}',side+'_jamb');add(a,side+f'_corner_cleat_{k}',side+'_jamb');add(a,side+f'_corner_cleat_{k}','bottom_rail' if k==0 else 'head_rail')
add(a,'bottom_rail','timber_sill')
for k in range(2):add(a,f'divider_end_cleat_{k}','center_steel_divider');add(a,f'divider_end_cleat_{k}','bottom_rail' if k==0 else 'head_rail')
for k in range(10):
 add(a,f'curtain_ring_{k:02}','curtain_rod');add(a,f'curtain_sewn_loop_{k:02}',f'curtain_ring_{k:02}')
 add(a,f'curtain_stitch_tab_{k:02}',f'curtain_sewn_loop_{k:02}','textile_stitched_seam','Small sewn textile overlap is intentional; no rigid-wire penetration')
 add(a,f'curtain_stitch_tab_{k:02}','left_curtain' if k<5 else 'right_curtain','textile_stitched_seam','Small sewn textile overlap is intentional')
a='lobby_glazed_facade';posts=['door_outer_post','door_glazing_post','middle_post','right_post']
for k,post in enumerate(posts):
 add(a,post,f'post_{k}_base_insert');add(a,post,f'post_{k}_head_insert');add(a,f'post_{k}_head_insert','teal_timber_header')
 for end in ['base','head']:add(a,post,f'post_{k}_{end}_fixing_backing')
for bay,postnames in [('left',['door_glazing_post','middle_post']),('right',['middle_post','right_post'])]:
 for k,rail in enumerate(['base_rail','middle_rail','head_rail']):
  for side,post in zip(['left','right'],postnames):add(a,bay+'_'+rail,post);add(a,f'{bay}_{side}_rail_shear_{k}',post);add(a,f'{bay}_{side}_rail_shear_{k}',bay+'_'+rail)
 add(a,bay+'_head_rail','teal_timber_header')
(R/'support_relationships.json').write_text(json.dumps({'status':'intended relations; independent actual-mesh measurement required','coordinates':'source asset-local metres','contacts':pairs,'external_interfaces':['Room jamb outer faces meet existing masonry opening; no wall edits','Lobby base caps Z=0 meet existing floor; receiving floor anchors beyond interface are not part of this asset'],'implementation_refinements':['Rod socket has 8 mm tubular length plus 2 mm mounting tab within original 10 mm support reach; 5 mm rod engagement unchanged','Curtain main panels now have restrained irregular folds/down-height drift and upward uneven hems; top loop stations fixed; all vertices inside approved cloth envelope','Room jambs shortened2 mm and capped2 mm at top; full outer bounds unchanged','Actual faceted-wire-conforming loop reaches Z1.2228476 instead of schematic1.2226; minimum rod-bottom envelope clearance1.1524 mm','Source objects retained individually; runtime non-glass batches by material with exact component ranges']},indent=2))
print('Declared',len(pairs),'named contact/fastener/seam pairs')
