# Briar Court: separate realistic window revision R1

**Separate integration candidate. Source-art visual review and independent mesh QA passed. Engine integration and acceptance remain pending.**

Two separately versioned source-art assets; original batch15 exports remain frozen. This fictional motel construction is designed for visual/game use. No code compliance, structural sizing, safety glazing designation, ballistic resistance or certification is asserted.

## Runtime and editable source

- `assets/room_window_insert_realistic_r1.glb`: 5,280 triangles; 7 meshes / 7 single-material primitives; 6 materials; two separate glass nodes.
- `assets/lobby_glazed_facade_realistic_r1.glb`: 4,932 triangles; 8 meshes / 8 single-material primitives; 5 materials; four separate glass nodes.
- `briar_court_windows_realistic_r1.blend`: editable named components in per-asset collections and packed original textures. The lobby collection is hidden by default to avoid overlapping the room in the source viewport; switch collection visibility to edit either asset at its unchanged local origin. Source has 108 room / 241 lobby components; this does **not** imply that many runtime draw calls.
- `build_windows.py`, `office_font.json`, `approved_proposal.json`: self-contained generator inputs. No network/downloaded image dependency.
- `component_manifest.json`: canonical component IDs, actual Blender object names (which may truncate at 63 characters), substrate, nominal thickness, measured source bounds and exact runtime mesh/primitive/triangle/index mapping. IDs refer to source components, not automatic physics bodies.
- `support_relationships.json`: exact named contacts, intentional fastener-to-host embeds, textile seams and assembly interfaces. It distinguishes those intended relations from geometric evidence.

Non-glass runtime meshes are grouped by compact material. Glass remains individually addressable. All triangle ranges are zero-based, half-open `[start,end)`, local to primitive 0 of the named mesh. Index ranges are three times triangle ranges. A component can be extracted using its ranges; runtime render batching does not merge its physical meaning. Engine owns any extraction, collision, transparency/lighting, damage and placement. Binding fields in the manifest remain null.

Four room instances plus one lobby use 26,052 triangles and 36 material primitives before additional engine batching, versus 4,172 original triangles. This is a deliberately higher-detail candidate, not a claim of original-budget parity. Cameras/lights, neutral render ground and any clear-glass preview overrides are not in runtime assets.

## Basis, identity and fixed dimensions

All coordinates are asset-root local metres, Blender Z-up: X right, exterior −Y, roomward +Y. glTF maps `(x,y,z)` to `(x,z,−y)`. Roots retain the `room_window_insert` / `lobby_glazed_facade` identities and original anchors; filenames distinguish the revision. There is no world-placement update or scene/display-layout offset baked into the assets.

Room complete bounds including sill: X ±1.035, Y −0.185…0.065, Z −0.0085…1.300. Lobby complete bounds: X ±2.000, Y −0.1005…0.0900, Z 0…2.800. Original 1.270 × 2.400 m lobby left doorway remains empty, X −1.940…−0.670; its separate door is untouched.

## What is actually modeled

- Six closed 6.4 mm glass solids with both full-area faces. Original 18/25 mm render proxies are replaced only in these new assets.
- Hollow 2 mm nominal aluminum frame sections with real glazing pockets, a fabricated steel room divider, fixed exterior lips, separate interior stops and fasteners. Pocket geometry is not hidden full boxes intersecting the glass.
- Twelve-millimetre edge bite, face gaskets and two setting blocks beneath every pane. Setting blocks and lips touch their actual receiving surfaces.
- Painted timber room sill and teal timber lobby header; room frame sits on sill. Lobby middle rail separates four panes; head/base rails meet header/floor interfaces.
- Room-only thin drapes on a steel rod: fixed top attachment stations, restrained irregular fold depth/spacing, gentle drift down height and subtly uneven hems. Each main panel is a closed nominal 0.6 mm Y-direction shell inside the approved envelope; perpendicular textile gauge varies on fold slopes. Separate sewn loops conform to actual ring facets; stitched textile joins are explicitly identified.
- Jamb-mounted sockets engage the rod; rings physically bear on it. Named support tabs, backing, screws, end caps, corner/rail joints and lettering adhesive pads are included.

Room glass-to-cloth minimum is remeasured from the final mesh. The approved 46.5 mm envelope clearance is a lower bound; irregular panels remain within that envelope. Do not substitute a proposal number for the actual QA report.

## Bounded implementation refinements

The core approved glass/frame/doorway bounds are unchanged. Small implementation details are disclosed:

1. Each socket uses an 8 mm tube plus a 2 mm mounting tab within the original 10 mm inward reach; rod engagement remains 5 mm. This avoids overlapping the mounting tab with the jamb wall.
2. Actual faceted-wire-conforming loops reach Z≈1.2228476 instead of schematic 1.2226000, leaving ≈1.1524 mm below the rod underside. The cloth main panel still ends at Z=1.219. These are measured modeling details, not manufacturing tolerances.
3. Room jamb profiles stop 2 mm short of the original top and receive 2 mm caps, preserving the full 1.300 m height and closing visible hollow ends.
4. Original small bevels are not replicated exactly on the new sill/header; bounds/placement are preserved, while replacement edge/topology details differ.
5. The approved regular cloth wave was given a bounded realism pass; top attachment locations stay fixed and all fabric stays inside the approved envelope.

## Materials and preview limits

Seven original procedural textures: six 128 × 128 images and one 256 × 256 woven cloth image. They are packed into the Blender source and embedded as needed in each GLB. Non-glass materials are opaque; roughness/metallic values are material constants. No third-party photographs, maps or textures are used.

`BCR1_glass` is a distinct opaque placeholder in delivered runtime art. Engine owns its final visual/sight behavior. Ordinary front/back renders show that actual placeholder. Files named `*_CLEAR_ILLUSTRATION_NOT_RUNTIME.png` use a **presentation-only** transparent surface mix; they illustrate physical separation and are not proof that the delivered runtime is transparent.

`previews/runtime_sections.png` and SVG are intersections of actual exported triangles, not redrawn proposal rectangles. Render/section provenance files record runtime hashes and any staging/preview-only changes.

## Validation and reproduction

Read the final independent QA reports for measured contacts, positive-volume/manifold checks, root/bounds/doorway checks, runtime triangle/UV mapping and clearances. Intentional fastener embeds and textile seams are not counted as accidental collisions. Sub-micron float residuals are assessed against the stated numerical tolerance; a nonzero Boolean sliver alone is not a physical penetration claim.

Rebuild with Blender 4.3.2 (or a compatible version), its bundled NumPy and Python:

`blender -b -t 1 --python-exit-code 1 --python build_windows.py`

`python map_contacts.py`

Render imported runtime, e.g.:

`blender -b -t 2 --python-exit-code 1 --python render_runtime.py -- room back`

`blender -b -t 2 --python-exit-code 1 --python render_runtime.py -- lobby front`

`python section_runtime.py` requires NumPy and Matplotlib; it verifies identity node transforms before converting axes and taking raw-GLB triangle cuts. No source geometry or engine code is changed by render/section scripts.

The original batch15 reference archive is https://drive.google.com/file/d/1MceTtpBriTUP1-0nvkMC58f8iZG4INVX/view?usp=drivesdk . Its original inputs are intentionally not duplicated here. Manufacturer scale references and the proposal are retained in `approved_proposal.json`; those references do not endorse this custom construction. All new artwork/scripts are CC0-1.0; see `LICENSE.txt`.

## Frozen handoff evidence

`independent_review/independent_review.md` and `summary_report.json` record the independent final PASS, including final editable-source/runtime hashes. Portable scripts and measured reports accompany them. `qa/portable_rebuild_report.json` confirms a clean, input-only rebuild reproduced both runtime GLBs, source geometry snapshot and component/support mappings byte for byte. `SHA256SUMS.txt` covers every packaged payload file; the archive receipt is provided separately.

The four ordinary front/back views were independently reviewed. The additional hardware closeup and explicitly labeled clear-shader illustration were checked during final packaging; the latter remains presentation-only. No engine code, world placement or original batch15 replacement is included.
