import json,sys,math
from pathlib import Path
from mathutils import Vector
from mathutils.bvhtree import BVHTree
D=Path(__file__).parent;data=json.load(open(D/'runtime_components.json'));trees={};bounds={}
for n,d in data.items():
 vv=[Vector(v) for t in d['triangles'] for v in t];trees[n]=BVHTree.FromPolygons(vv,[(3*k,3*k+1,3*k+2) for k in range(len(d['triangles']))],all_triangles=True);bounds[n]=([min(v[k] for v in vv) for k in range(3)],[max(v[k] for v in vv) for k in range(3)])
def cast(asset,origin,direction):
 found=[]
 for n,d in data.items():
  if d['asset']!=asset or d['kind'] not in ['frame_profile','removable_glazing_stop']:continue
  loc,norm,index,dist=trees[n].ray_cast(Vector(origin),Vector(direction),.1)
  if dist is not None:found.append((float(dist),n,list(loc)))
 return min(found) if found else None
results=[]
for n,d in data.items():
 if d['kind']!='glass_pane':continue
 lo,hi=bounds[n];mid=[(a+b)/2 for a,b in zip(lo,hi)]
 rays=[('left_edge',[lo[0],mid[1],mid[2]],[-1,0,0]),('right_edge',[hi[0],mid[1],mid[2]],[1,0,0]),('lower_edge_between_blocks',[mid[0],mid[1],lo[2]],[0,0,-1]),('upper_edge',[mid[0],mid[1],hi[2]],[0,0,1])]
 for face,y,direction in [('exterior',lo[1],[0,-1,0]),('interior',hi[1],[0,1,0])]:
  rays.extend([(face+'_side_bite',[lo[0]+.006,y,mid[2]],direction),(face+'_bottom_bite',[mid[0],y,lo[2]+.006],direction)])
 for tag,origin,direction in rays:
  hit=cast(d['asset'],origin,direction);expected=.002 if '_bite' in tag else (.001 if d['asset']=='room_window_insert' and (tag=='right_edge' and 'left' in n or tag=='left_edge' and 'right' in n) else .003)
  results.append({'pane':n,'ray':tag,'origin_source_m':origin,'direction':direction,'expected_gap_m':expected,'measured_gap_m':hit[0] if hit else None,'hit_component':hit[1] if hit else None,'hit_point_source_m':hit[2] if hit else None,'passes_2um':bool(hit and abs(hit[0]-expected)<2e-6)})
report={'measured_rays':len(results),'passed':all(r['passes_2um'] for r in results),'rays':results};(D/'pocket_rays_report.json').write_text(json.dumps(report,indent=2));print('RAY_RESULT',report['measured_rays'],report['passed']);print([r for r in results if not r['passes_2um']])
