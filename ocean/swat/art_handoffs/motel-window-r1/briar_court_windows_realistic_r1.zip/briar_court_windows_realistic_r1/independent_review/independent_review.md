# Independent window-revision review

Date: 2026-10-10. PASS for geometry, metadata and final front/back/section visual QA.

## Exact candidate

- Room: `18112ea6a0675875db3ca452d3307fce0fa32242a77bb624747aa2a6df181fe9`, 5,280 triangles, 108 physical components, 7 runtime primitives.
- Lobby: `f77dac494b028fac16902709fea32bb9f3a187e3b541fe9b659fecfaabea0241`, 4,932 triangles, 241 physical components, 8 runtime primitives.
- All 10,212 triangles are mapped exactly once. Triangle corners, winding and UVs agree with the independently read saved Blender source within 0.00000006 m/UV units. All 349 physical component solids are closed, consistently wound and positive-volume.
- Full original outer bounds and identity roots are retained. Original source-coordinate and glTF-coordinate anchor entries match exactly. Long canonical IDs now explicitly map to actual Blender object names and runtime ranges.
- Eight tracked original files remain byte-identical to the frozen source hashes. This is a separate replacement candidate; original art is unchanged.

## Measured construction evidence

- All six panes are closed 6.4 mm solids with full-area front and back faces.
- Forty-eight actual triangle-ray measurements verify 1 mm room-divider edge clearance, 3 mm other pocket edge clearances, and 2 mm rigid-lip separation through both pane faces. Gasket and setting-block contact is independently witnessed.
- All 346 declared surface-contact pairs have measured witnesses within 2 micrometres; worst recorded witness distance is approximately 1.565 micrometres.
- All 152 declared fastener embeds and 20 stitched seams have positive intersection volume. The full named contact graph is connected within each asset: 108 room and 241 lobby components.
- All 353 strictly positive-AABB-overlap pairs were tested with exact mesh Booleans. No undeclared positive-volume intersection was found. Rod/socket surface pairs produce small numerical slivers; actual polygonal-bore penetration is at most 0.345443 micrometres, below the 2 micrometre audit tolerance.
- Ring/loop coincident surfaces produce tiny Boolean residuals (up to approximately 3.2e-14 m³, sometimes with degenerate Boolean-output edges). Actual component meshes remain closed. Supplemental runtime loop vertex/face-centroid tests show at most 0.128 micrometres inward offset; no material clash is indicated at the audit tolerance.
- Actual minimum axis separations: cloth/glass 47.0713 mm; cloth/divider rear plane 5.2713 mm; cloth/sill 35.6278 mm; sewn loops/rod underside 1.1524 mm. Socket engagement is 4.999995/4.999757 mm.
- The 1,270 by 2,400 mm left lobby doorway is clear of every replacement component, including fasteners. Its X/Z opening is also clear at every depth.

## Explicit limitations and refinements

- This validates modeled contact and clearance, not structural capacity or real-world fabrication. Fastener hosts and receiving building interfaces are declared; surrounding wall/floor assets were not changed.
- Cloth is a nominal 0.6 mm Y-direction shell; perpendicular thickness varies on folds. Facet-conforming sewn loops differ slightly from the schematic envelope while remaining clear of the rod.
- Original bounds and placements are preserved; replacement bevels and topology are not identical to the original solids. The new timber sill/header use box edges.
- Runtime glass remains an opaque placeholder. Collision, transparency/lighting, damage and placement remain unassigned/Engine-owned. Any clear-glass render is a QA-only shader illustration, not the exported material contract.
- Manufacturer references are scale context, not certification of these custom profiles.

## Visual review

Final room front/back and lobby front/back renders were inspected and their provenance matches the exact final runtime hashes above. Exported mesh-section drawing was also reviewed. Pockets, setting blocks, four split lobby panes, capped room jambs, rod, separate folded curtains and clear doorway are legible. No missing broad pane face, unsupported visible component or unexplained intersection was observed. Views use opaque placeholder runtime glass; any separate clear preview is shader-only illustration. Rendering/staging is QA-only and is not exported. Image hashes and runtime provenance are recorded in visual_report.json.
