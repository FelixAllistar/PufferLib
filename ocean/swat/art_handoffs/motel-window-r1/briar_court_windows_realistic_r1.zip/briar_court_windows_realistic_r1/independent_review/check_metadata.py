import json,struct,sys,hashlib
from pathlib import Path
ROOT,ORIGINAL=map(Path,sys.argv[1:]);D=Path(__file__).parent;manifest=json.load(open(ROOT/'component_manifest.json'));snapshot=json.load(open(ROOT/'qa/source_mesh_snapshot.json'));source=json.load(open(D/'blend_source.json'));out={}
def read(p):
 raw=p.read_bytes();off=12;chunks={}
 while off<len(raw):
  n,t=struct.unpack_from('<II',raw,off);chunks[t]=raw[off+8:off+8+n];off+=8+n
 return json.loads(chunks[0x4e4f534a]),chunks[0x004e4942]
for asset,desc in manifest['assets'].items():
 j,bin=read(ROOT/desc['file']);old,_=read(ORIGINAL/'assets'/f'{asset}.glb');nodes={n['name']:n for n in j['nodes']};root=nodes[asset];orig=next(n for n in old['nodes'] if n['name']==asset);assert root['extras']['connections']==orig['extras']['connections'];assert not set(root)&{'matrix','translation','rotation','scale'}
 for c in manifest['components']:
  if c['asset']!=asset:continue
  assert c['id'] in snapshot;assert c['source_object_name']==source[c['id']]['actual_object_name'];m=c['runtime_mapping'];node=nodes[m['node_name']];mesh=j['meshes'][node['mesh']];assert m['mesh_name']==mesh['name'];ranges=node.get('extras',{}).get('component_ranges')
  if ranges:
   ranges=json.loads(ranges) if isinstance(ranges,str) else ranges;assert ranges[c['id']]==m['triangle_range_half_open']
  assert all(v is None for v in c['engine_bindings'].values())
 assert all('uri' not in b for b in j['buffers']);assert all('bufferView' in i for i in j.get('images',[]));assert all(mat.get('alphaMode','OPAQUE')=='OPAQUE' for mat in j['materials'])
 out[asset]={'sha256':desc['sha256'],'bin_chunk_sha256':hashlib.sha256(bin).hexdigest(),'original_connection_entries_preserved_exactly':True,'canonical_ids_source_names_and_runtime_ranges_agree':True,'engine_bindings_unassigned':True,'embedded_images':len(j.get('images',[])),'opaque_placeholder_materials':True}
(D/'metadata_report.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
