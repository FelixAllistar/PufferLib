import json
from pathlib import Path
from mathutils import Vector
from mathutils.bvhtree import BVHTree
D=Path(__file__).parent;data=json.load(open(D/'runtime_components.json'));results=[]
for name,d in data.items():
 if d['kind']!='sewn_loop':continue
 wire=name.replace('curtain_sewn_loop','curtain_ring');wt=data[wire]['triangles'];v=[Vector(p) for t in wt for p in t];tree=BVHTree.FromPolygons(v,[(3*k,3*k+1,3*k+2) for k in range(len(wt))],all_triangles=True);samples=[]
 for t in d['triangles']:
  vs=[Vector(p) for p in t];samples.extend(vs);samples.append(sum(vs,Vector())/3)
 signed=[]
 for p in samples:
  loc,n,idx,dist=tree.find_nearest(p);signed.append((p-loc).dot(n))
 results.append({'loop':name,'wire':wire,'sample_count':len(samples),'minimum_signed_nearest_face_offset_m':min(signed),'all_samples_outside_or_within_2um':min(signed)>-2e-6})
report={'method':'Runtime loop vertices and triangle centroids against nearest oriented runtime wire face, complementing full exact-Boolean intersection checks. This sample test alone is not exhaustive.','passed':all(r['all_samples_outside_or_within_2um'] for r in results),'checks':results};(D/'loop_surfaces_report.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
