import json,sys,hashlib,collections
from pathlib import Path
D=Path(__file__).parent;ROOT=Path(sys.argv[1]);runtime=json.load(open(D/'runtime_report.json'));dims=json.load(open(D/'dimensions_report.json'));meta=json.load(open(D/'metadata_report.json'));contacts=json.load(open(D/'contacts_distance_report.json'));intersections=json.load(open(D/'intersection_report.json'));rays=json.load(open(D/'pocket_rays_report.json'));loops=json.load(open(D/'loop_surfaces_report.json'));visual=json.load(open(D/'visual_report.json'));manifest=json.load(open(ROOT/'component_manifest.json'));surface=[r for r in contacts if r['kind']=='surface_contact'];bad_surface=[r for r in surface if r['vertex_face_distance_upper_bound_m']>2e-6];bad_intersections=[]
for r in intersections:
 if r['intersection_volume_m3']<=1e-12 or r['declared_kind'] in ['intentional_fastener_embed','textile_stitched_seam']:continue
 if r['a'].endswith('__curtain_rod') and r['b'].endswith(('_rod_socket')) and max(dims['measured']['left_rod_socket_max_polygon_bore_violation_m'],dims['measured']['right_rod_socket_max_polygon_bore_violation_m'])<2e-6:continue
 bad_intersections.append(r)
adj=collections.defaultdict(set)
for r in contacts:adj[r['a']].add(r['b']);adj[r['b']].add(r['a'])
graph={}
for asset in manifest['assets']:
 remain={c['id'] for c in manifest['components'] if c['asset']==asset};sizes=[]
 while remain:
  todo=[min(remain)];got=set()
  while todo:
   n=todo.pop()
   if n in got:continue
   got.add(n);todo.extend(adj[n]-got)
  remain-=got;sizes.append(len(got))
 graph[asset]=sizes
visual_valid=all(v['runtime_sha256'] in {a['sha256'] for a in manifest['assets'].values()} and hashlib.sha256((ROOT/'previews'/(name+'.png')).read_bytes()).hexdigest()==v['sha256'] for name,v in visual.items())
passed=visual_valid and all(dims['checks'].values()) and not bad_surface and not bad_intersections and rays['passed'] and loops['passed'] and all(a['all_closed_consistently_wound_positive_volume'] and a['all_triangles_uniquely_mapped'] for a in runtime['assets']) and all(len(v)==1 for v in graph.values())
result={'passed':passed,'scope':'Actual geometry, source/runtime mapping, numerical contacts, clearances, frozen-original preservation, metadata and manually reviewed final visual evidence. Not structural or engine-binding certification.','position_contact_tolerance_m':2e-6,'assets':runtime['assets'],'editable_source_sha256':hashlib.sha256((ROOT/'briar_court_windows_realistic_r1.blend').read_bytes()).hexdigest(),'decoded_runtime_components_sha256':hashlib.sha256((D/'runtime_components.json').read_bytes()).hexdigest(),'declared_surface_contacts':len(surface),'maximum_surface_contact_witness_distance_m':max(r['vertex_face_distance_upper_bound_m'] for r in surface),'positive_aabb_pairs_tested':len(intersections),'unexpected_material_intersections':bad_intersections,'contact_graph_component_sizes':graph,'actual_pocket_rays':rays['measured_rays'],'final_views':visual,'source_byte_freeze_verified':dims['checks']['all_eight_original_hashes_frozen']};(D/'summary_report.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2));assert passed
