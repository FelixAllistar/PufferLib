import bpy,json,sys
from pathlib import Path
root,out=map(Path,sys.argv[sys.argv.index('--')+1:]);bpy.ops.wm.open_mainfile(filepath=str(root/'briar_court_windows_realistic_r1.blend'))
manifest=json.load(open(root/'component_manifest.json'));r={}
for c in manifest['components']:
 o=next((ob for ob in bpy.data.objects if ob.get('component_id')==c['id']),None);assert o is not None and o.type=='MESH',c['id'];m=o.data;m.calc_loop_triangles();r[c['id']]={'actual_object_name':o.name,'asset':o.parent.name,'positions_source_m':[list(v.co) for v in m.vertices],'triangles':[list(t.vertices) for t in m.loop_triangles],'triangle_corner_uvs':[[list(m.uv_layers.active.data[li].uv) for li in t.loops] for t in m.loop_triangles],'matrix_world':[list(row) for row in o.matrix_world],'root_matrix':[list(row) for row in o.parent.matrix_world],'material':m.materials[0].name,'modifiers':[mod.type for mod in o.modifiers]}
out.write_text(json.dumps(r,separators=(',',':')))
