import json,sys,hashlib
from pathlib import Path
import numpy as np
from scipy.spatial import ConvexHull
D=Path(__file__).parent;ROOT=Path(sys.argv[1]);data=json.load(open(D/'runtime_components.json'));proposal=json.load(open(ROOT/'approved_proposal.json'));checks={};stats={}
def vertices(n):return np.unique(np.array(data[n]['triangles']).reshape(-1,3),axis=0)
def name(asset,short):return asset+'__r1__'+short
for asset in proposal['assets']:
 ts=np.concatenate([np.array(d['triangles']).reshape(-1,3) for d in data.values() if d['asset']==asset]);bounds=np.array([ts.min(0),ts.max(0)]);checks[asset+'_whole_bounds_match_frozen']=bool(np.max(abs(bounds-np.array(proposal['assets'][asset]['original']['measured_aabb_source_m'])))<2e-6)
 for pane in proposal['assets'][asset]['proposed_panes']:
  n=name(asset,pane['id']);v=vertices(n);expected=np.array(pane['aabb_source_m']);b=np.array([v.min(0),v.max(0)]);checks[pane['id']+'_exact_pane_bounds']=bool(np.max(abs(b-expected))<2e-6);checks[pane['id']+'_closed_6_4mm_solid']=bool(abs(v[:,1].ptp()-.0064)<2e-6) if hasattr(v[:,1],'ptp') else bool(abs(np.ptp(v[:,1])-.0064)<2e-6)
  ts=np.array(data[n]['triangles']);normals=np.cross(ts[:,1]-ts[:,0],ts[:,2]-ts[:,0]);area=normals/2;facearea=[sum(abs(a[1]) for a in area if a[1]*sign>0) for sign in [-1,1]];expectedarea=(b[1,0]-b[0,0])*(b[1,2]-b[0,2]);checks[pane['id']+'_both_faces_full_area']=all(abs(a-expectedarea)<1e-6 for a in facearea)
room='room_window_insert';cloth=np.concatenate([vertices(name(room,side+'_curtain')) for side in ['left','right']]);glass=np.concatenate([vertices(name(room,'room_glass_'+side)) for side in ['left','right']]);divider=vertices(name(room,'center_steel_divider'));rod=vertices(name(room,'curtain_rod'));sill=vertices(name(room,'timber_sill'));loops=np.concatenate([vertices(n) for n,d in data.items() if d['kind']=='sewn_loop']);rings=np.concatenate([vertices(n) for n,d in data.items() if d['kind']=='curtain_ring'])
stats['cloth_glass_y_separation_m']=float(cloth[:,1].min()-glass[:,1].max());stats['cloth_divider_y_separation_m']=float(cloth[:,1].min()-divider[:,1].max());stats['cloth_sill_z_separation_m']=float(cloth[:,2].min()-sill[:,2].max());stats['loop_rod_z_separation_m']=float(rod[:,2].min()-loops[:,2].max());stats['cloth_rod_z_separation_m']=float(rod[:,2].min()-cloth[:,2].max());checks['cloth_glass_clearance_46_5mm']=stats['cloth_glass_y_separation_m']>=.0465-2e-6;checks['cloth_divider_clearance_4_7mm']=stats['cloth_divider_y_separation_m']>=.0047-2e-6;checks['cloth_sill_clearance_35_5mm']=stats['cloth_sill_z_separation_m']>=.0355-2e-6;checks['loops_below_rod']=stats['loop_rod_z_separation_m']>.0011
for side in ['left','right']:
 socket=vertices(name(room,side+'_rod_socket'));radii=np.linalg.norm(socket[:,[1,2]]-np.array([.04,1.23]),axis=1);inner=socket[radii<.007];h=ConvexHull(inner[:,[1,2]]);eq=h.equations;maxradial=float(np.max(rod[:,[1,2]]@eq[:,:2].T+eq[:,2]));stats[side+'_rod_socket_max_polygon_bore_violation_m']=maxradial;checks[side+'_rod_within_actual_bore_2um']=maxradial<2e-6
 overlap=min(rod[:,0].max(),socket[:,0].max())-max(rod[:,0].min(),socket[:,0].min());stats[side+'_actual_socket_engagement_m']=float(overlap);checks[side+'_5mm_engagement']=abs(overlap-.005)<2e-6
# Complete open doorway is separated in X/Z from every solid, including fixings. Broad-phase proof is sufficient here.
lobby='lobby_glazed_facade';door=np.array(proposal['assets'][lobby]['doorway']['clear_bounds_source_m']);bad=[]
for n,d in data.items():
 if d['asset']!=lobby:continue
 v=vertices(n);extent=np.minimum(v.max(0),door[1])-np.maximum(v.min(0),door[0]);
 if np.min(extent)>2e-6:bad.append(n)
checks['doorway_completely_empty']=not bad;stats['doorway_intruders']=bad
xzbad=[]
for n,d in data.items():
 if d['asset']!=lobby:continue
 v=vertices(n);extent=np.minimum(v.max(0),door[1])-np.maximum(v.min(0),door[0])
 if min(extent[0],extent[2])>2e-6:xzbad.append(n)
checks['doorway_xz_clear_at_every_depth']=not xzbad;stats['doorway_xz_intruders']=xzbad
# Original source hashes independently re-read.
hashes=json.load(open(D/'frozen_source_hashes.json'));orig=Path(sys.argv[2]);checks['all_eight_original_hashes_frozen']=all(hashlib.sha256((orig/path).read_bytes()).hexdigest()==sha for path,sha in hashes.items())
report={'checks':{k:bool(v) for k,v in checks.items()},'measured':stats};(D/'dimensions_report.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2));assert all(checks.values())
