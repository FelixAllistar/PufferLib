import bpy,bmesh,json,sys,math
from pathlib import Path
from mathutils import Vector
from mathutils.bvhtree import BVHTree
D=Path(__file__).parent;ROOT=Path(sys.argv[sys.argv.index('--')+1]);data=json.load(open(D/'runtime_components.json'));rels=json.load(open(ROOT/'support_relationships.json'))['contacts'];bpy.ops.wm.read_factory_settings(use_empty=True);objs={};points={};trees={};bounds={};faces={}
for name,d in data.items():
 vv=[];ff=[];cache={}
 for t in d['triangles']:
  f=[]
  for p in t:
   key=tuple(p)
   if key not in cache:cache[key]=len(vv);vv.append(key)
   f.append(cache[key])
  ff.append(tuple(f))
 me=bpy.data.meshes.new(name);me.from_pydata(vv,[],ff);me.update();o=bpy.data.objects.new(name,me);bpy.context.scene.collection.objects.link(o);objs[name]=o;points[name]=[Vector(v) for v in vv];faces[name]=ff;trees[name]=BVHTree.FromPolygons(points[name],ff,all_triangles=True);bounds[name]=([min(v[k] for v in vv) for k in range(3)],[max(v[k] for v in vv) for k in range(3)])
def mindist(a,b):
 best=(float('inf'),None,None)
 for x,y in [(a,b),(b,a)]:
  tree=trees[y]
  # Vertex-face distances are exact witness distances; zero witnesses prove contact. Positive values are upper bounds only.
  for v in points[x]+[(points[x][f[0]]+points[x][f[1]]+points[x][f[2]])/3 for f in faces[x]]:
   loc,norm,index,dist=tree.find_nearest(v)
   if dist is not None and dist<best[0]:best=(dist,list(v),list(loc))
 return best
contacts=[]
for r in rels:
 a,b=r['a'],r['b'];dist,pa,pb=mindist(a,b);contacts.append(dict(r,vertex_face_distance_upper_bound_m=dist,witness_a=pa,witness_b=pb))
(D/'contacts_distance_report.json').write_text(json.dumps(contacts,indent=2));print('CONTACTS',len(contacts),'potential gaps',sum(c['vertex_face_distance_upper_bound_m']>2e-6 for c in contacts),flush=True)
if '--distances-only' in sys.argv: sys.exit(0)
by_pair={frozenset([r['a'],r['b']]):r for r in rels};pairs=[];names=list(data)
for i,a in enumerate(names):
 for b in names[i+1:]:
  if data[a]['asset']!=data[b]['asset']:continue
  ov=[min(bounds[a][1][k],bounds[b][1][k])-max(bounds[a][0][k],bounds[b][0][k]) for k in range(3)]
  if min(ov)>1e-8:pairs.append((a,b))
results=[];deps=bpy.context.evaluated_depsgraph_get()
for i,(a,b) in enumerate(pairs):
 tmp=bpy.data.objects.new('audit_intersection',objs[a].data.copy());bpy.context.scene.collection.objects.link(tmp);mod=tmp.modifiers.new('audit_intersection','BOOLEAN');mod.operation='INTERSECT';mod.solver='EXACT';mod.object=objs[b];bpy.context.view_layer.update();ev=tmp.evaluated_get(deps);me=ev.to_mesh();bm=bmesh.new();bm.from_mesh(me);vol=abs(bm.calc_volume(signed=True));bad=sum(not e.is_manifold for e in bm.edges);nv=len(bm.verts);bm.free();ev.to_mesh_clear();mesh=tmp.data;bpy.data.objects.remove(tmp,do_unlink=True);bpy.data.meshes.remove(mesh)
 r=by_pair.get(frozenset([a,b]));results.append({'a':a,'b':b,'intersection_volume_m3':vol,'intersection_nonmanifold_edges':bad,'intersection_vertices':nv,'declared_kind':r['kind'] if r else None})
 if i%50==0:print('INTERSECTIONS',i,'/',len(pairs),flush=True)
(D/'intersection_report.json').write_text(json.dumps(results,indent=2));print('DONE',len(results),flush=True)
