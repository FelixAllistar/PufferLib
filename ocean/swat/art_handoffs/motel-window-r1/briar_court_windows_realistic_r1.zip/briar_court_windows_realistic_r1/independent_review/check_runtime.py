import json,struct,hashlib,collections,sys
from pathlib import Path
import numpy as np
ROOT=Path(sys.argv[1]);OUT=Path(__file__).parent;manifest=json.load(open(ROOT/'component_manifest.json'));src=json.load(open(OUT/'blend_source.json'));report={'assets':[],'issues':[]};runtime={}
for asset,desc in manifest['assets'].items():
 raw=(ROOT/desc['file']).read_bytes();assert hashlib.sha256(raw).hexdigest()==desc['sha256'];off=12;chunks={}
 while off<len(raw):
  length,typ=struct.unpack_from('<II',raw,off);chunks[typ]=raw[off+8:off+8+length];off+=8+length
 doc=json.loads(chunks[0x4e4f534a]);binary=chunks[0x004e4942]
 def acc(ai):
  a=doc['accessors'][ai];v=doc['bufferViews'][a['bufferView']];dtype={5126:'<f4',5125:'<u4',5123:'<u2',5121:'u1'}[a['componentType']];n={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4}[a['type']];size=np.dtype(dtype).itemsize;return np.ndarray((a['count'],n),dtype=dtype,buffer=binary,offset=v.get('byteOffset',0)+a.get('byteOffset',0),strides=(v.get('byteStride',n*size),size)).copy()
 nodes={n['name']:n for n in doc['nodes']};root=nodes[asset];assert not set(root)&{'matrix','translation','rotation','scale'}
 prims={};count=0
 for name,node in nodes.items():
  if 'mesh' not in node:continue
  assert not set(node)&{'matrix','translation','rotation','scale'}
  mesh=doc['meshes'][node['mesh']]
  for pi,p in enumerate(mesh['primitives']):
   assert p.get('mode',4)==4;ix=acc(p['indices']).ravel().reshape(-1,3);pos=acc(p['attributes']['POSITION']);uv=acc(p['attributes']['TEXCOORD_0']);normal=acc(p['attributes']['NORMAL']);ts=pos[ix][:,:,[0,2,1]]*np.array([1,-1,1]);us=uv[ix].astype(float);us[:,:,1]=1-us[:,:,1];ns=normal[ix][:,:,[0,2,1]]*np.array([1,-1,1]);prims[(name,pi)]={'triangles':ts,'uvs':us,'normals':ns,'material':doc['materials'][p['material']]['name'],'counts':np.zeros(len(ix),int),'mesh_name':mesh['name']};count+=len(ix)
 assetcomps=[c for c in manifest['components'] if c['asset']==asset];maxerr=0;totalv=[];notclosed=[]
 for c in assetcomps:
  name=c['id'];s=src[name];assert not s['modifiers'];assert np.allclose(s['matrix_world'],np.eye(4),atol=0);assert np.allclose(s['root_matrix'],np.eye(4),atol=0)
  m=c['runtime_mapping'];pr=prims[(m['node_name'],m['primitive_index'])];start,end=m['triangle_range_half_open'];assert m['index_range_half_open']==[start*3,end*3];pr['counts'][start:end]+=1;ts=pr['triangles'][start:end];us=pr['uvs'][start:end];pos=np.array(s['positions_source_m']);ids=np.array(s['triangles']);expected=pos[ids];eu=np.array(s['triangle_corner_uvs']);assert len(ts)==c['triangles']==len(expected);assert pr['material']==s['material']==c['material']
  # Triangle order is promised by ranges; cyclic corner rotation allowed, reversal prohibited.
  err=np.stack([np.maximum(np.max(abs(ts-np.roll(expected,k,axis=1)),axis=(1,2)),np.max(abs(us-np.roll(eu,k,axis=1)),axis=(1,2))) for k in range(3)]).min(axis=0)
  assert err.max()<2e-6,(name,err.max());maxerr=max(maxerr,float(err.max()))
  edges=collections.Counter(tuple(sorted((int(t[k]),int(t[(k+1)%3])))) for t in ids for k in range(3));direct=collections.Counter((int(t[k]),int(t[(k+1)%3])) for t in ids for k in range(3));closed=all(v==2 for v in edges.values()) and all(direct[e]==direct[e[::-1]]==1 for e in direct)
  if not closed:notclosed.append(name)
  vol=float(np.einsum('ij,ij->i',expected[:,0],np.cross(expected[:,1],expected[:,2])).sum()/6);assert vol>0,(name,vol)
  assert np.allclose([pos.min(0),pos.max(0)],c['aabb_source_m'],atol=2e-6)
  runtime[name]={'asset':asset,'kind':c['kind'],'triangles':ts.tolist(),'uvs':us.tolist(),'volume_m3':vol,'material':c['material'],'actual_source_name':s['actual_object_name']};totalv.extend(ts.reshape(-1,3).tolist())
 for pr in prims.values():assert np.all(pr['counts']==1)
 assert count==desc['triangles'];totalv=np.array(totalv);report['assets'].append({'asset':asset,'sha256':desc['sha256'],'triangles':count,'components':len(assetcomps),'runtime_primitives':len(prims),'max_source_runtime_corner_uv_error':maxerr,'aabb_source_m':[totalv.min(0).tolist(),totalv.max(0).tolist()],'all_closed_consistently_wound_positive_volume':not notclosed,'nonmanifold_components':notclosed,'all_triangles_uniquely_mapped':True})
(OUT/'runtime_components.json').write_text(json.dumps(runtime,separators=(',',':')));(OUT/'runtime_report.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
