# Independent actual-runtime verification

These checks inspect the exported GLB triangles and the saved editable Blender source. They do not substitute proposal constants for actual geometry measurements. Originals and candidate assets are never written by the audit scripts. Blender creates only temporary in-memory audit meshes.

## Reproduce

Requirements: Blender 4.3.2 or compatible, Python 3 with NumPy and SciPy. Run from this directory and substitute the candidate packet and extracted original batch15 source directories.

1. `blender -b -t 1 --python-exit-code 1 --python extract_blend.py -- CANDIDATE_DIR blend_source.json`
2. `python check_runtime.py CANDIDATE_DIR`
3. `python check_metadata.py CANDIDATE_DIR ORIGINAL_DIR`
4. `python check_dimensions.py CANDIDATE_DIR ORIGINAL_DIR`
5. `blender -b -t 1 --python-exit-code 1 --python check_contacts_blender.py -- CANDIDATE_DIR`
6. `blender -b -t 1 --python-exit-code 1 --python check_pocket_rays.py`
7. `blender -b -t 1 --python-exit-code 1 --python check_loop_surfaces.py`
8. `python summarize_reports.py CANDIDATE_DIR`

The final summary also checks the recorded manually reviewed image hashes. Changed images require a new human/visual review and an updated visual_report.json; the script does not replace that review.

Scripts write their reports and intermediate decoded meshes beside themselves. The original directory is required to recheck frozen hashes and exact original anchor entries. Source `component_id` custom properties resolve original long identifiers even where Blender limits display names to 63 characters; the final manifest explicitly records both identifiers.

## Methods and limits

- Binary parsing checks every component's exact primitive-local triangle/index range, complete disjoint coverage, winding-preserving corner correspondence, UVs, materials, roots and bounds. Source geometry is independently extracted from the saved `.blend` rather than trusting the builder's snapshot.
- Each source solid must be closed, consistently wound, and have positive volume; the verified source/runtime correspondence transfers those geometric properties to the exported component ranges.
- Surface-contact reports record measured runtime vertex/triangle-centroid to triangle witnesses. A near-zero witness proves contact within numerical tolerance; positive sampled distances alone would not prove a gap. All declared surface-contact pairs have witnesses within 2 micrometres.
- Blender's exact Boolean solver tests all same-asset pairs with strictly positive AABB overlap. Declared fastener embeds and stitched seams are separately identified. Coincident surface roundoff is not interpreted as a physical clash. Rod/socket residuals are bounded independently by the actual polygonal bore halfspaces.
- The loop-surface sample check supplements Boolean checks; it is not an exhaustive standalone collision proof. Near-coplanar ring/loop Boolean residue is disclosed in the report.
- Forty-eight rays measure the actual pane edge pockets and rigid retention lips on both faces. Pane closure, full front/back areas and 6.4 mm depth are checked independently.
- Contact connectivity is geometric adjacency, not an engineering load-path calculation. No structural, fabrication, code, safety, collision, destruction or final material-rendering certification is provided.
- Cloth thickness is nominal 0.6 mm along source Y; perpendicular gauge varies with fold slopes. Source normals/triangles are finite-precision game art.
