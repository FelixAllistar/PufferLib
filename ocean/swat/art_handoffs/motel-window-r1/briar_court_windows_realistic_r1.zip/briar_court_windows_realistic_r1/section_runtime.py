"""Measured cross-section linework extracted from actual exported GLB triangles."""
import json,struct,hashlib
from pathlib import Path
import numpy as np
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection
R=Path(__file__).resolve().parent
COL={'BCR1_painted_aluminum':'#879086','BCR1_painted_steel':'#44575a','BCR1_painted_timber':'#b39463','BCR1_teal_timber':'#257b72','BCR1_glass':'#229fc0','BCR1_rubber':'#252924','BCR1_cloth':'#ba764b'}
def read(path):
 b=path.read_bytes();n=struct.unpack_from('<I',b,12)[0];j=json.loads(b[20:20+n]);off=20+n;length=struct.unpack_from('<I',b,off)[0];blob=b[off+8:off+8+length]
 def acc(i):
  a=j['accessors'][i];v=j['bufferViews'][a['bufferView']];d={5126:'<f4',5125:'<u4',5123:'<u2',5121:'u1'}[a['componentType']];ncomp={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4}[a['type']];item=np.dtype(d).itemsize
  return np.ndarray((a['count'],ncomp),dtype=d,buffer=blob,offset=v.get('byteOffset',0)+a.get('byteOffset',0),strides=(v.get('byteStride',item*ncomp),item)).copy()
 out=[]
 # Builder emits identity-transform root/mesh nodes and already axis-converted accessors.
 assert all(not any(k in x for k in ['matrix','rotation','translation','scale']) for x in j['nodes'])
 for node in j['nodes']:
  if 'mesh' not in node:continue
  for q in j['meshes'][node['mesh']]['primitives']:
   p=acc(q['attributes']['POSITION']);p=p[:,[0,2,1]];p[:,1]*=-1;tri=acc(q['indices']).ravel().reshape(-1,3);out.append((j['materials'][q['material']]['name'],p[tri]))
 return out,hashlib.sha256(b).hexdigest()
def cut(data,axis,value,ax,coord,limits,title):
 for material,triangles in data:
  segments=[]
  for t in triangles:
   ds=t[:,axis]-value
   if min(ds)>0 or max(ds)<0:continue
   pts=[]
   for i,j in [(0,1),(1,2),(2,0)]:
    if ds[i]*ds[j]<0:pts.append(t[i]+(t[j]-t[i])*ds[i]/(ds[i]-ds[j]))
    elif abs(ds[i])<1e-9:pts.append(t[i])
   unique=[]
   for p in pts:
    if not any(np.linalg.norm(p-q)<1e-9 for q in unique):unique.append(p)
   if len(unique)==2:segments.append(np.array(unique)[:,coord]*1000)
  if segments:ax.add_collection(LineCollection(segments,colors=COL.get(material,'#888888'),linewidths=1.15,label=material.replace('BCR1_','')))
 ax.set(xlim=limits[0],ylim=limits[1],title=title);ax.set_aspect('equal');ax.grid(alpha=.10)
room,rh=read(R/'assets/room_window_insert_realistic_r1.glb');lobby,lh=read(R/'assets/lobby_glazed_facade_realistic_r1.glb')
fig,axs=plt.subplots(1,3,figsize=(14,7),constrained_layout=True)
cut(room,2,.651,axs[0],[0,1],[(-1005,-940),(-70,70)],'Room left jamb pocket\nactual GLB cut at Z=651 mm')
axs[0].set(xlabel='X mm',ylabel='Y mm · roomward up')
cut(room,0,-.7295,axs[1],[1,2],[(-42,12),(20,72)],'Room setting-block / sill pocket\nactual GLB cut at X=−729.5 mm')
axs[1].set(xlabel='Y mm · roomward right',ylabel='Z mm')
cut(lobby,0,.12,axs[2],[1,2],[(-65,65),(715,785)],'Lobby split panes / middle rail\nactual GLB cut at X=120 mm')
axs[2].set(xlabel='Y mm · roomward right',ylabel='Z mm')
fig.suptitle('BRIAR COURT · exported mesh sections',fontweight='bold',fontsize=17)
fig.get_layout_engine().set(rect=(0,.07,1,.94));fig.text(.5,.015,'Blue glass · charcoal gaskets / setting blocks · gray aluminum · linework comes from exported triangles, not proposal boxes',ha='center',fontsize=10)
fig.savefig(R/'previews/runtime_sections.png',dpi=170);fig.savefig(R/'previews/runtime_sections.svg');plt.close(fig)
(R/'qa/section_provenance.json').write_text(json.dumps({'method':'triangle/plane intersections from raw GLB index and POSITION accessors; source-basis conversion applied','room_sha256':rh,'lobby_sha256':lh,'planes_source_m':{'room_jamb_Z':.651,'room_block_X':-.7295,'lobby_middle_X':.12}},indent=2))
print('Rendered actual exported GLB sections')
