"""Render actual imported GLBs for visual QA, never changes delivered source/runtime."""
import bpy,sys,math,json,hashlib
from pathlib import Path
from mathutils import Vector
ROOT=Path(__file__).resolve().parent
args=sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else ['room','front']
asset,view=args[:2];name='room_window_insert' if asset=='room' else 'lobby_glazed_facade'
RUNTIME_HASH=hashlib.sha256((ROOT/'assets'/(name+'_realistic_r1.glb')).read_bytes()).hexdigest()
bpy.ops.wm.read_factory_settings(use_empty=True);bpy.ops.import_scene.gltf(filepath=str(ROOT/'assets'/(name+'_realistic_r1.glb')))
# Blender importer restores source Z-up from glTF convention.
sc=bpy.context.scene;sc.render.engine='CYCLES';sc.cycles.device='CPU';sc.cycles.samples=24;sc.cycles.use_denoising=False;sc.render.threads_mode='FIXED';sc.render.threads=2
sc.render.resolution_x=1000;sc.render.resolution_y=750;sc.render.resolution_percentage=100;sc.render.image_settings.file_format='PNG'
sc.world=bpy.data.worlds.new('Neutral studio');sc.world.use_nodes=True;sc.world.node_tree.nodes['Background'].inputs[0].default_value=(.19,.22,.24,1);sc.world.node_tree.nodes['Background'].inputs[1].default_value=.65
sc.view_settings.view_transform='AgX';sc.view_settings.look='AgX - Medium High Contrast'
# Non-delivered staging plane below asset; never part of GLB or mesh validation.
bpy.ops.mesh.primitive_plane_add(size=200,location=(0,0,-.018 if asset=='room' else -.01));ground=bpy.context.object;ground.name='QA_ONLY_ground'
m=bpy.data.materials.new('QA_ONLY_neutral');m.diffuse_color=(.13,.15,.16,1);ground.data.materials.append(m)
def light(name,p,target,energy,size):
 d=bpy.data.lights.new(name,'AREA');d.energy=energy;d.shape='DISK';d.size=size;o=bpy.data.objects.new(name,d);sc.collection.objects.link(o);o.location=p;o.rotation_euler=(Vector(target)-o.location).to_track_quat('-Z','Y').to_euler()
light('QA_ONLY_key',(-3,-4,6),(0,0,1),900,4);light('QA_ONLY_back',(3,4,5),(0,0,1),1100,4);light('QA_ONLY_fill',(4,-1,2),(0,0,1),400,3)
target=(0,0,.65 if asset=='room' else 1.4);scale=2.85 if asset=='room' else 5.6
if view=='front':pos=(2.4,-4.8,2.2) if asset=='room' else (4.5,-7,3.9)
elif view=='back':pos=(-2.1,4.7,2.0) if asset=='room' else (-4.5,7,3.9)
elif view=='detail':target=(.66,.025,1.04);pos=(1.5,2.8,1.8);scale=.75
elif view=='hardware':target=(.85,.04,1.22);pos=(1.3,2,1.52);scale=.32
elif view=='clear_preview':
 pos=(2.4,-4.8,2.2) if asset=='room' else (4.5,-7,3.9)
 for mat in bpy.data.materials:
  if mat.name.startswith('BCR1_glass'):
   nt=mat.node_tree;bs=nt.nodes.get('Principled BSDF');bs.inputs['Transmission Weight'].default_value=0;bs.inputs['Metallic'].default_value=.1;bs.inputs['Roughness'].default_value=.10
   for link in list(nt.links):
    if link.to_socket==bs.inputs['Base Color']:nt.links.remove(link)
   bs.inputs['Base Color'].default_value=(.75,.87,.89,1)
   transparent=nt.nodes.new('ShaderNodeBsdfTransparent');mix=nt.nodes.new('ShaderNodeMixShader');mix.inputs[0].default_value=.10
   nt.links.new(transparent.outputs[0],mix.inputs[1]);nt.links.new(bs.outputs[0],mix.inputs[2]);nt.links.new(mix.outputs[0],nt.nodes.get('Material Output').inputs['Surface'])
else:raise ValueError(view)
d=bpy.data.cameras.new('QA_ONLY_camera');o=bpy.data.objects.new('QA_ONLY_camera',d);sc.collection.objects.link(o);o.location=pos;o.rotation_euler=(Vector(target)-o.location).to_track_quat('-Z','Y').to_euler();d.type='ORTHO';d.ortho_scale=scale;sc.camera=o
if view=='clear_preview':
 t=bpy.data.curves.new('QA_ONLY_illustration_label','FONT');t.body='ILLUSTRATION: CLEAR SHADER OVERRIDE / NOT RUNTIME';t.size=scale*.011;t.align_x='CENTER';lab=bpy.data.objects.new('QA_ONLY_illustration_label',t);sc.collection.objects.link(lab);lab.parent=o;lab.location=(0,-scale*.33,-1)
 lm=bpy.data.materials.new('QA_ONLY_label');lm.use_nodes=True;bs=lm.node_tree.nodes.get('Principled BSDF');bs.inputs['Base Color'].default_value=(.02,.025,.03,1);bs.inputs['Roughness'].default_value=1;lab.data.materials.append(lm)
filename=f'{asset}_CLEAR_ILLUSTRATION_NOT_RUNTIME.png' if view=='clear_preview' else f'{asset}_{view}.png'
sc.render.filepath=str(ROOT/'previews'/filename);bpy.ops.render.render(write_still=True)
(ROOT/'qa'/f'render_{asset}_{view}_provenance.json').write_text(json.dumps({'runtime_file':'assets/'+name+'_realistic_r1.glb','runtime_sha256':RUNTIME_HASH,'view':view,'renderer':'Blender Cycles CPU','samples':sc.cycles.samples,'QA_only_staging':'neutral plane, world, area lights and camera; never exported','glass_override':'preview-only transparent surface mix; delivered runtime stays opaque' if view=='clear_preview' else None},indent=2))
print('RENDERED',sc.render.filepath)
