from pathlib import Path
import json,hashlib
root=Path(__file__).resolve().parent;src=root/'source/worn_room_furnishings_v1';m=json.loads((src/'manifest.json').read_text());results=[]
for a in m['assets']:
 for f in a['files']:
  b=(src/f['path']).read_bytes();checks={'bytes':len(b)==f['bytes'],'sha256':hashlib.sha256(b).hexdigest()==f['sha256'],'official_md5':hashlib.md5(b).hexdigest()==f['source_md5']};assert all(checks.values());results.append({'path':f['path'],'checks':checks})
(root/'output/source_audit.json').write_text(json.dumps(results,indent=2));print(len(results),'original files passed bytes, SHA-256 and recorded official MD5 checks')
