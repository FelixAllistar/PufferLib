import json,struct,hashlib,copy
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parent
SRC=ROOT/'source/worn_room_furnishings_v1/originals'; OUT=ROOT/'output'
def sha(b):return hashlib.sha256(b).hexdigest()
def accessor(d,b,i):
 a=d['accessors'][i];v=d['bufferViews'][a['bufferView']];dt={5126:'<f4',5123:'<u2',5125:'<u4',5121:'u1'}[a['componentType']];n={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4}[a['type']];offset=v.get('byteOffset',0)+a.get('byteOffset',0);return np.ndarray((a['count'],n),dtype=dt,buffer=b,offset=offset,strides=(v.get('byteStride',np.dtype(dt).itemsize*n),np.dtype(dt).itemsize)).copy()
def matrix(n):
 if 'matrix' in n:return np.array(n['matrix']).reshape(4,4).T
 x,y,z,w=n.get('rotation',[0,0,0,1]);m=np.eye(4);m[:3,:3]=np.array([[1-2*(y*y+z*z),2*(x*y-z*w),2*(x*z+y*w)],[2*(x*y+z*w),1-2*(x*x+z*z),2*(y*z-x*w)],[2*(x*z-y*w),2*(y*z+x*w),1-2*(x*x+y*y)]])@np.diag(n.get('scale',[1]*3));m[:3,3]=n.get('translation',[0]*3);return m
def measure(d,b):
 rows=[]
 def walk(i,parent):
  n=d['nodes'][i];m=parent@matrix(n)
  if 'mesh' in n:
   pts=[];tri=0
   for p in d['meshes'][n['mesh']]['primitives']:
    a=accessor(d,b,p['attributes']['POSITION']);pts.append((np.c_[a,np.ones(len(a))]@m.T)[:,:3]);idx=accessor(d,b,p['indices']).ravel();assert idx.max()<len(a);assert np.isfinite(a).all();assert len(idx)%3==0;tri+=len(idx)//3
   pts=np.concatenate(pts);lo=pts.min(0);hi=pts.max(0);rows.append({'node':n['name'],'mesh':d['meshes'][n['mesh']]['name'],'triangles':tri,'material_indices':[p['material'] for p in d['meshes'][n['mesh']]['primitives']],'min_xyz_m':lo.tolist(),'max_xyz_m':hi.tolist(),'dimensions_width_height_depth_m':(hi-lo).tolist()})
  for ch in n.get('children',[]):walk(ch,m)
 for i in d['scenes'][d.get('scene',0)]['nodes']:walk(i,np.eye(4))
 return rows
def bounds(rows):
 lo=np.min([r['min_xyz_m'] for r in rows],0);hi=np.max([r['max_xyz_m'] for r in rows],0);return {'min_xyz_m':lo.tolist(),'max_xyz_m':hi.tolist(),'dimensions_width_height_depth_m':(hi-lo).tolist(),'triangles':sum(r['triangles'] for r in rows)}
p=SRC/'painted_wooden_nightstand/painted_wooden_nightstand_2k.gltf';d=json.loads(p.read_text());original=copy.deepcopy(d);b=(p.parent/d['buffers'][0]['uri']).read_bytes();orig_b=b
before=measure(d,b);bo=bounds(before);lo=np.array(bo['min_xyz_m']);hi=np.array(bo['max_xyz_m']);offset=-(lo+hi)/2;offset[1]=-lo[1]
roots=d['scenes'][0]['nodes'];d['nodes'].append({'name':'Nightstand_FloorCentered','translation':offset.tolist(),'children':roots});d['scenes'][0]['nodes']=[len(d['nodes'])-1]
imgs=[]
for im in d['images']:
 raw=(p.parent/im['uri']).read_bytes();b+=b'\0'*((-len(b))%4);im['bufferView']=len(d['bufferViews']);d['bufferViews'].append({'buffer':0,'byteOffset':len(b),'byteLength':len(raw)});imgs.append({'source_uri':im.pop('uri'),'bytes':len(raw),'sha256':sha(raw)});b+=raw
b+=b'\0'*((-len(b))%4);d['buffers']=[{'byteLength':len(b)}];j=json.dumps(d,separators=(',',':')).encode();j+=b' '*((-len(j))%4);glb=struct.pack('<III',0x46546c67,2,12+8+len(j)+8+len(b))+struct.pack('<II',len(j),0x4e4f534a)+j+struct.pack('<II',len(b),0x004e4942)+b
out=OUT/'painted_wooden_nightstand_floor_centered_2k.glb';out.write_bytes(glb)
# Independently parse actual on-disk derivative and compare all binary geometry and source image bytes.
r=out.read_bytes();magic,ver,total=struct.unpack_from('<III',r);assert total==len(r) and magic==0x46546c67 and ver==2;jn,jt=struct.unpack_from('<II',r,12);actual=json.loads(r[20:20+jn]);bn,bt=struct.unpack_from('<II',r,20+jn);actualb=r[28+jn:];assert len(actualb)==bn and actualb[:len(orig_b)]==orig_b;assert actual['meshes']==original['meshes'] and actual['materials']==original['materials'];assert actual['accessors']==original['accessors'];assert actual['nodes'][:-1]==original['nodes'];assert not any('uri' in x for x in actual['buffers']+actual['images'])
for im,expected in zip(actual['images'],imgs):
 v=actual['bufferViews'][im['bufferView']];assert sha(actualb[v['byteOffset']:v['byteOffset']+v['byteLength']])==expected['sha256']
after=measure(actual,actualb);ab=bounds(after);assert ab['triangles']==470 and abs(ab['min_xyz_m'][1])<1e-10
p2=SRC/'vintage_suitcase/vintage_suitcase_2k.gltf';sd=json.loads(p2.read_text());sb=(p2.parent/sd['buffers'][0]['uri']).read_bytes();sr=measure(sd,sb)
report={'coordinate_system':'glTF right-handed Y-up; width X, height Y, depth Z; meters','original_nightstand':bo,'nightstand_components':before,'exported_nightstand':ab,'root_translation_m':offset.tolist(),'glb_bytes':len(r),'glb_sha256':sha(r),'embedded_images':imgs,'verified':{'original_geometry_binary_byte_exact':True,'materials_accessors_meshes_unchanged':True,'source_node_transforms_unchanged_under_new_root':True,'embedded_images_byte_exact':True,'no_external_uris':True,'all_indices_in_range':True,'finite_positions':True},'suitcase_components':sr,'suitcase_variants':{f'vintage_suitcase_{i:02}':bounds([x for x in sr if x['node'].startswith(f'vintage_suitcase_{i:02}')]) for i in [1,2]},'suitcase_combined_scene':bounds(sr)}
(OUT/'verification.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
