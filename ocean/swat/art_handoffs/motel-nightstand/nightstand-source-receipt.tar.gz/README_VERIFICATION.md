# Worn-room assets: nightstand import derivative and suitcase measurements

Prepared 2026-10-10. No accepted asset or project placement was replaced. The recovered original ZIP and extracted source files remain unchanged.

## Deliverable

`painted_wooden_nightstand_floor_centered_2k.glb` is a self-contained binary glTF 2.0 of the original Painted Wooden Nightstand. Its 470 triangles, original indexed geometry, normals, UVs, two mesh components, source transforms and one material are preserved. All three original 2048 × 2048 JPEG files are embedded without recompression. No simplification, re-topology, texture resizing, scaling, collision generation or material substitution was applied.

The conversion concatenates the original geometry buffer and JPEG bytes into a GLB and adds one parent translation. It deliberately avoids a Blender re-export that might rewrite mesh vertices or JPEGs. Blender is used for independent import and rendered review afterward.

## Units, axes and pivot

All numbers below are meters. glTF and the GLB use right-handed **X = width, Y = up/height, Z = depth**. Blender imports glTF into its **X = width, Y = depth, Z = up/height**, with glTF +Z mapped to Blender -Y. Do not interpret the middle value in a glTF XYZ dimension array as depth.

- Nightstand W × D × H: **0.504564583 × 0.508716002 × 0.615520971 m**.
- Suitcase 01 W × D × H: **0.693782897 × 0.239175416 × 0.567905050 m**.
- Suitcase 02 W × D × H: **0.693782897 × 0.239175416 × 0.567905050 m**.
- Combined suitcase scene W × D × H: **1.608182878 × 0.239175416 × 0.567905050 m**. The old approximately 1.61 m width measures the two cases and their intervening gap; it is not an individual case size.

Measurements use actual POSITION arrays transformed by the full scene-node transforms, including suitcase scale 1.587164402 and rotations. Each suitcase includes its bottom, clasp, handle and top. This is the supplied closed pose, including protrusions; it is not an opened-case envelope. Each case has **8,237 triangles**, combined **16,474**.

Nightstand's source world AABB in glTF XYZ is min (-0.253411949, -0.0000000167, -0.249247357), max (0.251152635, 0.615520954, 0.259468645). The derivative has min (-0.252282292, 0, -0.254358001), max (0.252282292, 0.615520971, 0.254358001).

The added `Nightstand_FloorCentered` root translates by glTF XYZ (+0.001129657, +0.0000000167, -0.005110644). Its local origin is centered on the full prop's floor-projected bounding rectangle. Import/use the complete hierarchy under that root; importing only a child bypasses this prop pivot. The drawer's separate source origin and relative placement remain intact. No drawer motion, clearance or animation has been validated.

## Exact mesh and material assignment

These are actual source nodes and material bindings, not invented material slots for every physical part.

Nightstand:
- Node `painted_wooden_nightstand`, mesh `nightstand.024`: 180 triangles, 248 source accessor vertices; material 0 `painted_wooden_nightstand`.
- Node `painted_wooden_nightstand_drawer`, mesh `nightstand.025`: 290 triangles, 255 source accessor vertices; the same material 0.
- The cabinet/table body and drawer are the only two explicit mesh components. Top, frame, tapered legs and drawer detailing are not individually assigned physical-material slots.
- Source metadata identifies wood and worn paint. Wood species, solid wood versus veneer/composite construction, finish chemistry, drawer pull substrate and concealed joinery are **unknown**. Do not convert the one shared material into unsupported per-part substrate claims.

Suitcase 01:
- `vintage_suitcase_01_bottom` → `handle_mount.003`, 3,864 triangles.
- `vintage_suitcase_01_clasp` → `latch.001`, 448 triangles.
- `vintage_suitcase_01_handle` → `Handle.001`, 1,216 triangles.
- `vintage_suitcase_01_top` → `hinge_top.001`, 2,709 triangles.
- All four use material 0 `vintage_suitcase_01`.

Suitcase 02:
- `vintage_suitcase_02_bottom` → `handle_mount.001`, 3,864 triangles.
- `vintage_suitcase_02_clasp` → `latch.002`, 448 triangles.
- `vintage_suitcase_02_handle` → `Handle.002`, 1,216 triangles.
- `vintage_suitcase_02_top` → `hinge_top.002`, 2,709 triangles.
- All four use material 1 `vintage_suitcase_02`.

Internal mesh datablock names can be misleading (for example, a node named bottom uses a datablock named handle_mount); node names and inspected geometry are the grouping reference. The cases are texture variants with matching measured geometry envelopes and triangle counts. Source metadata identifies leather and metal and describes aged green surfaces, clasps and travel labels. The supporting shell substrate, exact leather construction/species, metal alloy, handle core and label substrate/adhesive are **unknown**. Physical materials are represented within each variant's shared texture atlas, not separate leather/metal mesh materials.

## Texture channels and preserved source behavior

For each material, the original `*_diff_2k.jpg` is the base-color texture (sRGB); `*_nor_gl_2k.jpg` is the OpenGL tangent-space normal map (non-color); `*_arm_2k.jpg` packs ambient occlusion in R, roughness in G and metallic in B (non-color). Nightstand uses the `painted_wooden_nightstand` prefix; each suitcase material uses its matching `vintage_suitcase_01` or `_02` prefix. UV set is TEXCOORD_0.

Important source fidelity details:
- All materials are double-sided and opaque (default alpha mode).
- The original nightstand glTF has metallicFactor **0**, so it remains fully non-metallic in glTF regardless of ARM B. This has not been silently altered.
- Neither original asset glTF binds an `occlusionTexture`. The ARM red channel exists in the JPEG but is **not connected to glTF AO**. The derivative preserves this behavior. Adding AO would be a separate, explicitly described material adjustment.
- Suitcase materials omit metallicFactor, so glTF defaults to 1 multiplied by ARM B.
- Sampler settings, normals, UVs and material JSON are retained; image URI references alone become internal bufferViews.

## Provenance and permissions

- Nightstand: **Kirill Sannikov**, [Painted Wooden Nightstand / Poly Haven](https://polyhaven.com/a/painted_wooden_nightstand).
- Suitcases: **Maximilian Schuster**, [Vintage Suitcase / Poly Haven](https://polyhaven.com/a/vintage_suitcase).
- Original assets are offered as **CC0-1.0**; [Poly Haven license](https://polyhaven.com/license), [CC0 deed](https://creativecommons.org/publicdomain/zero/1.0/). Asset author and license were rechecked against the official pages on 2026-10-10.
- CC0 permits copying/modification, including commercial use, without mandatory attribution. Author credits are retained as provenance. CC0 does not separately clear trademark, privacy or publicity rights; inspect travel-label imagery before prominent branding or marketing use.
- Original source API metadata, official file URLs and MD5 records, source SHA-256 records and license reference are retained under provenance. Rendered previews in this derivative package are newly rendered from the assets, not Poly Haven's website previews.

## Recovery and verification

Recovered from Drive file `12jZ50cqpWrWQCnmQlAsymlOm1rO5Plyv`, `briar_court_worn_room_furnishings_sources_v1.zip`, **50,905,982 bytes**. SHA-256:
`1115badf9d1620ef50838585217a9f7b9d5e318b7064718c25320c5372af6da8`.

All **26** original glTF/bin/JPEG files across the four-asset source pack were checked against the recorded byte lengths, SHA-256 and original API MD5 values. Every check passed. The existing source ZIP is retained separately and unchanged.

The actual GLB was read back from disk, its header/chunks parsed, and its mesh data measured independently. Passed:
- 470 triangle count (180 body + 290 drawer), valid index ranges, finite vertex positions.
- Byte-identical original geometry buffer, including index, normal and UV bytes.
- Unchanged source accessors, primitive/material assignments, material JSON and original child node transforms.
- Byte-identical embedded JPEG data verified by SHA-256.
- No external buffer/image URIs; self-contained textures.
- Floor contact at Y = 0, symmetric X/Z overall bounds and unchanged dimensions.

GLB: **8,215,320 bytes**, SHA-256 `af66187e614c9a11c7d690fcbe35422d45af2890cb3f4644ea631b0d9b3e1d17`.

`verification.json` supplies full-precision source/derivative bounds, individual component counts, hashes and checks. `source_audit.json` records all original-file checks. `blender_import_verification.json` records independent Blender import counts, bounds, material bindings and loaded image sizes. `blender_render.log` records the actual import/render run. Previews are studio review renders, independently framed, not engine screenshots or a shared-scale comparison.

## Integration limitations

No game-engine import, collider, physics, navmesh, lightmap-UV, animation, draw-call or target-hardware performance test was run. An original low triangle count is not a guarantee of runtime readiness. Three uncompressed RGBA8 2K maps with full mipmaps would be roughly 64 MiB, despite the GLB's approximately 7.83 MiB disk size; actual importer formats/compression differ. Retain source detail and profile before deriving texture/LOD reductions. The asset was not rescaled to an assumed furniture size.

## Render and secondary check results

Blender 4.3.2 imported the final GLB successfully with 180 + 290 triangles and all three embedded 2048² images loaded and packed. Imported dimensions agree with the independent binary parser to less than 0.00000003 m for the nightstand and both suitcase variants (floating-point conversion tolerance). `crosscheck.json` records those comparisons. Both nightstand meshes have zero zero-area triangles at a 1e-12 m² threshold, finite normals and UVs, and normals of unit length to float precision (`additional_mesh_checks.json`). This is not a watertight/manifold certification.

Four newly rendered PNGs were visually inspected: nightstand front and rear, plain suitcase 01, and labeled suitcase 02. The images show complete framing, the expected worn textures, the cabinet and drawer assembled, and no missing-texture pink surfaces. Review lighting is mildly grainy at 24 Cycles samples. No generated stand-in mesh or texture was used. Variant 01 has a plain front; variant 02 has weathered travel labels.

The ZIP is an add-on derivative/review pack. Its `provenance/` contains original metadata/file-list/license snapshots and the original source manifest. It does not duplicate the entire 50.9 MB source archive; that recovered archive is preserved separately. For reproduction, copy the included scripts into the recovery directory alongside `source/` and `output/`, then run them there. They resolve `source/worn_room_furnishings_v1/` relative to their own file location. The original working scripts remain at the recovery-directory root.
