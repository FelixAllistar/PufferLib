"""New isolated full-body foundation from two validated Drive backups; no originals saved."""
import bpy,json,hashlib,os
from pathlib import Path
from mathutils import Matrix,Vector
R=Path('/workspace/scratch/eac4961518d4/animation_rebuild');O=R/'upright_locomotion';FULL=R/'recovered_fps/single_swat_fps_fixed_camera.blend1';FPS=R/'editable/swat_fps_recovered.blend';sha=lambda p:hashlib.file_digest(open(p,'rb'),'sha256').hexdigest();inputs={str(p):sha(p) for p in [FULL,FPS]};compat=json.load(open(O/'base_compatibility.json'));assert compat['shared_bones']==67 and compat['rest_matrix_max_difference']==0 and not compat['parent_mismatches']
bpy.ops.wm.open_mainfile(filepath=str(FPS));s=bpy.context.scene;r=bpy.data.objects['SWAT_Mixamo_Rig'];assert len(r.data.bones)==70;r.animation_data.action=bpy.data.actions['FPS Idle']
for tr in r.animation_data.nla_tracks:tr.mute=True
s.frame_set(0);reference={b.name:b.matrix_basis.copy() for b in r.pose.bones};before=set(bpy.data.objects)
with bpy.data.libraries.load(str(FULL),link=False) as (src,dst):dst.objects=['SWAT Point source']
body=dst.objects[0];assert len(body.data.vertices)==24850;oldrig=body.parent;assert oldrig and oldrig.type=='ARMATURE';assert all(max(abs(oldrig.data.bones[n].matrix_local[i][j]-r.data.bones[n].matrix_local[i][j]) for i in range(4) for j in range(4))==0 for n in oldrig.data.bones.keys())
def payload(o):return hashlib.sha256(repr(([list(v.co) for v in o.data.vertices],[[list((g.group,g.weight)) for g in v.groups] for v in o.data.vertices],[v.name for v in o.vertex_groups])).encode()).hexdigest()
mesh_hash=payload(body);world=body.matrix_world.copy();body.parent=r;body.matrix_world=world
for mod in body.modifiers:
 if mod.type=='ARMATURE':mod.object=r
s.collection.objects.link(body);body.name='Rebuilt SWAT full body';body.hide_render=False;body.hide_viewport=False;body.hide_set(False)
for ob in list(bpy.data.objects):
 if ob.type=='MESH' and ob!=body and ob.name.startswith('SWAT Point FPS arms'):bpy.data.objects.remove(ob,do_unlink=True)
assert payload(body)==mesh_hash
# Preserve the recovered hold local channels exactly, while freezing a neutral reference.
carry=bpy.data.actions.new('Rebuild Carry Reference / Recovered FPS Idle');carry.use_fake_user=True
for n,M in reference.items():
 for field,vals in zip(['location','rotation_quaternion','scale'],M.decompose()):
  for j,val in enumerate(vals):
   fc=carry.fcurves.new('pose.bones["'+n+'"].'+field,index=j,action_group=n)
   for f in [0,30]:k=fc.keyframe_points.insert(f,float(val));k.interpolation='LINEAR'
r.animation_data.action=carry
for tr in list(r.animation_data.nla_tracks):r.animation_data.nla_tracks.remove(tr)
for act in list(bpy.data.actions):
 if act!=carry:bpy.data.actions.remove(act)
for ob in list(bpy.data.objects):
 if ob.type=='ARMATURE' and ob!=r:bpy.data.objects.remove(ob,do_unlink=True)
s.render.fps=30;s.render.fps_base=1;s.frame_start=0;s.frame_end=30;s.frame_set(0)
for im in bpy.data.images:
 if im.size[0]>0 and im.source=='FILE' and not im.packed_file:
  try:im.pack()
  except RuntimeError:pass
s.render.engine='BLENDER_WORKBENCH';s.render.resolution_x=540;s.render.resolution_y=720;s.render.resolution_percentage=100;s.render.image_settings.file_format='PNG';s.world.color=(.055,.065,.085);sh=s.display.shading;sh.light='STUDIO';sh.color_type='MATERIAL';sh.show_shadows=True;sh.show_cavity=True;sh.cavity_type='BOTH';sh.show_object_outline=True;sh.background_type='WORLD';s.view_settings.view_transform='Standard';s.render.film_transparent=False
if not s.camera:
 c=bpy.data.objects.new('Upright review camera',bpy.data.cameras.new('Upright review camera'));s.collection.objects.link(c);s.camera=c
c=s.camera;c.data.type='ORTHO';c.data.ortho_scale=2.1;target=Vector((0,0,.90));bpy.context.preferences.filepaths.save_version=0
out=O/'upright_foundation_rebuilt.blend';bpy.ops.wm.save_as_mainfile(filepath=str(out),compress=True)
manifest={'status':'new_rebuilt_foundation_not_prior_bank_bytes','inputs':inputs,'output':str(out),'sha256':sha(out),'rig':r.name,'body':body.name,'carry_action':carry.name,'carry_source':'Recovered older FPS Idle; no claim of lost latest elbow/shoulder revision parity','shared_human_rest_exact':True,'body_payload_sha256':mesh_hash,'body_vertices':len(body.data.vertices),'body_max_influences':max(len([g for g in v.groups if g.weight>1e-8]) for v in body.data.vertices),'bone_count':len(r.data.bones),'active_bone_constraints':[(b.name,c.name) for b in r.pose.bones for c in b.constraints if not c.mute]};json.dump(manifest,open(O/'foundation_manifest.json','w'),indent=2)
for view,off in [('front',(0,-4,0)),('right',(4,0,0)),('threequarter',(3,-4,.4))]:
 c.location=target+Vector(off);c.rotation_euler=(target-c.location).to_track_quat('-Z','Y').to_euler();s.render.filepath=str(O/('foundation_'+view+'.png'));bpy.ops.render.render(write_still=True)
assert all(sha(p)==h for p,h in inputs.items());print('FOUNDATION',json.dumps(manifest),flush=True)
