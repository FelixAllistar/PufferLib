"""Read native source timing and transforms; creates only a metadata JSON."""
import bpy,math,json,hashlib
from pathlib import Path
R=Path('/workspace/scratch/eac4961518d4');O=R/'animation_rebuild/upright_locomotion';P='mixamorig:'
DIRECTIONS=['forward','forward left','left','backward left','backward','backward right','right','forward right']
records=[]
for family in ['walk','run']:
 for d in DIRECTIONS:
  label=family+' '+d;files=list((R/'attachments').glob('*/'+label+'.fbx.bin'));assert len(files)==1,(label,files);path=files[0]
  bpy.ops.wm.read_factory_settings(use_empty=True);bpy.ops.import_scene.fbx(filepath=str(path));r=next(o for o in bpy.data.objects if o.type=='ARMATURE');a=r.animation_data.action;s=bpy.context.scene;lo,hi=a.frame_range;fps=s.render.fps/s.render.fps_base
  s.frame_set(int(lo));p0=r.matrix_world@r.pose.bones[P+'Hips'].head;s.frame_set(int(hi));p1=r.matrix_world@r.pose.bones[P+'Hips'].head
  record={'source':label,'path':str(path),'sha256':hashlib.file_digest(open(path,'rb'),'sha256').hexdigest(),'fps':fps,'frame_range':[lo,hi],'duration_s':(hi-lo)/fps,'bones':len(r.data.bones),'root_start_world':list(p0),'root_end_world':list(p1),'root_delta_world':list(p1-p0),'scene_units_scale_length':s.unit_settings.scale_length,'rig_world':[list(x) for x in r.matrix_world],'rest_bones':{n:{'parent':r.data.bones[n].parent.name if r.data.bones[n].parent else None,'world_matrix':[list(x) for x in r.matrix_world@r.data.bones[n].matrix_local]} for n in [P+'Hips',P+'Spine',P+'Spine1',P+'Spine2',P+'LeftUpLeg',P+'LeftLeg',P+'LeftFoot',P+'RightUpLeg',P+'RightLeg',P+'RightFoot']}}
  assert fps==60 and abs(record['duration_s']-(.5 if family=='run' else 1.))<1e-9,record
  records.append(record);print('NATIVE',label,'60Hz',record['duration_s'],list(p1-p0),flush=True)
json.dump({'purpose':'Actual surviving original FBX inspection for new rebuilt bank; not recovered prior outputs','clips':records},open(O/'native_source_inventory.json','w'),indent=2)
