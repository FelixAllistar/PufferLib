import bpy,json,math,collections
from pathlib import Path
from mathutils import Vector
from mathutils.bvhtree import BVHTree
O=Path('/workspace/scratch/eac4961518d4/animation_rebuild/upright_locomotion');m=json.load(open(O/'run_forward_manifest.json'));c=m['clips'][0];bpy.ops.wm.open_mainfile(filepath=m['base_blend']);r=bpy.data.objects['SWAT_Mixamo_Rig'];b=bpy.data.objects['Rebuilt SWAT full body'];g=bpy.data.objects['Rifle 7'];s=bpy.context.scene
with bpy.data.libraries.load(m['library'],link=False) as (src,dst):dst.actions=[c['action']]
b.data.calc_loop_triangles();tris=[tuple(t.vertices) for t in b.data.loop_triangles];rear_ids=[v.index for v in g.data.vertices if v.co.y>.4499];rear=[g.data.vertices[i].co for i in rear_ids];pad=Vector(((min(v.x for v in rear)+max(v.x for v in rear))/2,.45,(min(v.z for v in rear)+max(v.z for v in rear))/2));foot={};sub=[]
for tri in tris:
 wt={}
 for vi in tri:
  for w in b.data.vertices[vi].groups:wt[b.vertex_groups[w.group].name]=wt.get(b.vertex_groups[w.group].name,0)+w.weight/3
 if sum(wt.get('mixamorig:'+n,0) for n in ['Spine','Spine1','Spine2','RightShoulder','RightArm'])>.5:sub.append(tri)
def skin(o):
 ev=o.evaluated_get(bpy.context.evaluated_depsgraph_get());me=ev.to_mesh();v=[o.matrix_world@p.co for p in me.vertices];ev.to_mesh_clear();return v
def weights(tri):
 wt=collections.Counter()
 for vi in tri:
  for w in b.data.vertices[vi].groups:wt[b.vertex_groups[w.group].name]+=w.weight/3
 return wt.most_common(4)
def ray(tree,p,d):
 hit,n,ix,dist=tree.ray_cast(p,d.normalized(),2)
 return {'distance_m':dist,'point':list(hit),'face_weights':weights(sub[ix])} if hit is not None else None
out={'pad_center_native':list(pad),'rear_plane_vertices':len(rear_ids),'samples':[]};r.animation_data.action=dst.actions[0]
for i in range(61):
 t=i/120;f=t*30;s.frame_set(math.floor(f),subframe=f%1);v=skin(b);gv=skin(g);tree=BVHTree.FromPolygons(v,sub,all_triangles=True);G=r.pose.bones['Prop_Rifle'].matrix;p=G@pad;pt,n,ix,dist=tree.find_nearest(p);ds=[tree.find_nearest(gv[j])[3] for j in rear_ids];out['samples'].append({'t':t,'pad_center_nearest_distance_m':dist,'pad_center_nearest_face_weights':weights(sub[ix]),'rear_pad_vertex_distance_range_m':[min(ds),max(ds)],'rearward_pad_normal_ray':ray(tree,p,G.to_3x3()@Vector((0,1,0))),'forward_opposite_ray':ray(tree,p,G.to_3x3()@Vector((0,-1,0)))})
json.dump(out,open(O/'independent_stage_stockcleared/pad_seating.json','w'),indent=2);print('PAD',json.dumps({'center_gap_range':[min(x['pad_center_nearest_distance_m'] for x in out['samples']),max(x['pad_center_nearest_distance_m'] for x in out['samples'])],'min_rear_vertex_gap':min(x['rear_pad_vertex_distance_range_m'][0] for x in out['samples']),'frame0':out['samples'][0]}),flush=True)
