import bpy,json,math,hashlib,collections
from pathlib import Path
from mathutils import Matrix,Vector
from mathutils.bvhtree import BVHTree
from mathutils.geometry import intersect_ray_tri
O=Path('/workspace/scratch/eac4961518d4/animation_rebuild/upright_locomotion');Q=O/'independent_stage_stockcleared';M=json.load(open(O/'run_forward_manifest.json'));C=M['clips'][0];F=json.load(open(O/'foundation_stockcleared_manifest.json'));P='mixamorig:';sha=lambda p:hashlib.file_digest(open(p,'rb'),'sha256').hexdigest();out={'foundation_sha_matches':sha(M['base_blend'])==M['base_sha256'],'action_sha_matches':sha(M['library'])==M['library_sha256'],'source_sha_matches':sha(C['source_path'])==C['source_sha256']}
bpy.ops.wm.open_mainfile(filepath=M['base_blend']);s=bpy.context.scene;r=bpy.data.objects['SWAT_Mixamo_Rig'];body=bpy.data.objects[F['body']];gun=bpy.data.objects['Rifle 7'];mag=bpy.data.objects['Removed magazine'];base=bpy.data.actions[C['baseline_action']]
with bpy.data.libraries.load(M['library'],link=False) as (src,dst):
 out['library_inventory']={k:list(getattr(src,k)) for k in ['actions','objects','armatures','meshes','materials']};dst.actions=[C['action']]
a=dst.actions[0];out['frame_range']=list(a.frame_range);out['nla_tracks']=[(t.name,t.mute) for t in r.animation_data.nla_tracks];out['active_constraints']=[(b.name,c.name,c.type) for b in r.pose.bones for c in b.constraints if not c.mute]
def payload(o):return hashlib.sha256(repr(([list(v.co) for v in o.data.vertices],[[list((g.group,g.weight)) for g in v.groups] for v in o.data.vertices],[v.name for v in o.vertex_groups])).encode()).hexdigest()
out['body_payload_matches_foundation']=payload(body)==F['body_payload_sha256']
def sf(t):f=t*30;s.frame_set(math.floor(f),subframe=f%1)
def qa(q,p):
 d=abs(sum(float(x)*float(y) for x,y in zip(q,p)))/math.sqrt(sum(float(x*x) for x in q)*sum(float(y*y) for y in p));return math.degrees(2*math.acos(min(1,d)))
def skin(o):
 ev=o.evaluated_get(bpy.context.evaluated_depsgraph_get());me=ev.to_mesh();v=[o.matrix_world@x.co for x in me.vertices];ev.to_mesh_clear();return v
def anatomy(row):
 x=(row['LeftArm'].translation-row['RightArm'].translation).normalized();z=row['Spine2'].to_quaternion()@Vector((0,1,0));z=(z-x*z.dot(x)).normalized();return Matrix((x,z.cross(x).normalized(),z)).transposed().to_quaternion()
def sig(ac):return {(fc.data_path,fc.array_index):repr([(tuple(k.co),k.interpolation) for k in fc.keyframe_points]) for fc in ac.fcurves}
x,y=sig(base),sig(a);out['changed_bones']=sorted(set(k[0].split('"')[1] for k in set(x)|set(y) if x.get(k)!=y.get(k)))
curves={}
for fc in a.fcurves:
 if fc.data_path.endswith('.rotation_quaternion'):curves.setdefault(fc.data_path,{})[fc.array_index]=fc
dots=[]
for path,fs in curves.items():
 times=sorted(set(k.co.x for f in fs.values() for k in f.keyframe_points));qs=[[fs[i].evaluate(t) for i in range(4)] for t in times];dots += [sum(x*y for x,y in zip(q,p)) for q,p in zip(qs,qs[1:])]
out['quaternion_min_adjacent_key_dot']=min(dots)
for o in [body,gun,mag]:o.data.calc_loop_triangles()
bt=[tuple(t.vertices) for t in body.data.loop_triangles];gt=[tuple(t.vertices) for t in gun.data.loop_triangles];mt=[tuple(t.vertices) for t in mag.data.loop_triangles];regions=['stock_rear' if sum(gun.data.vertices[i].co.y for i in t)/3>.22 else 'barrel' if sum(gun.data.vertices[i].co.y for i in t)/3<-.12 else 'receiver' for t in gt];groups={x:[] for x in ['torso','head_neck','legs','right_shoulder','left_shoulder']};feet={};hands=[]
for side in ['Left','Right']:
 gr={g.index for g in body.vertex_groups if g.name.startswith(tuple(P+side+x for x in ['Foot','ToeBase','Toe_End']))};feet[side]=[v.index for v in body.data.vertices if sum(g.weight for g in v.groups if g.group in gr)>.65]
for v in body.data.vertices:
 if sum(g.weight for g in v.groups if 'Hand' in body.vertex_groups[g.group].name)>.99:hands.append(v.index)
for tri in bt:
 wt={}
 for vi in tri:
  for w in body.data.vertices[vi].groups:wt[body.vertex_groups[w.group].name]=wt.get(body.vertex_groups[w.group].name,0)+w.weight/3
 if sum(wt.get(P+n,0) for n in ['Spine','Spine1','Spine2'])>.7:groups['torso'].append(tri)
 if sum(wt.get(P+n,0) for n in ['Head','Neck'])>.5:groups['head_neck'].append(tri)
 if sum(wt.get(P+side+n,0) for side in ['Left','Right'] for n in ['UpLeg','Leg'])>.5:groups['legs'].append(tri)
 for side in ['Right','Left']:
  if sum(wt.get(P+side+n,0) for n in ['Shoulder','Arm'])>.5:groups[side.lower()+'_shoulder'].append(tri)
def crosses(tris,v,gv,gb,ptris,labels=None):
 bb=BVHTree.FromPolygons(v,tris,all_triangles=True);hits=collections.Counter()
 for i,j in bb.overlap(gb):
  aa=[v[x] for x in tris[i]];ba=[gv[x] for x in ptris[j]];found=False
  for aa1,ba1 in [(aa,ba),(ba,aa)]:
   if found:break
   for u,w in [(0,1),(1,2),(2,0)]:
    d=aa1[w]-aa1[u];L=d.length
    if L<1e-8:continue
    p=intersect_ray_tri(*ba1,d.normalized(),aa1[u],True)
    if p is not None and (p-aa1[u]).dot(d)>=-1e-10 and (p-aa1[u]).length<=L+1e-7:found=True;break
  if found:hits[labels[j] if labels else 'magazine']+=1
 return dict(hits)
r.animation_data.action=base;sf(0);G=r.pose.bones['Prop_Rifle'].matrix.copy();GI=G.inverted();v=skin(body);handref={i:GI@v[i] for i in hands};armref={side:[(r.pose.bones[P+side+'Arm'].head-r.pose.bones[P+side+'ForeArm'].head).length,(r.pose.bones[P+side+'ForeArm'].head-r.pose.bones[P+side+'Hand'].head).length] for side in ['Left','Right']};r.animation_data.action=a;rows=[];minsole=99.;handerr=0.;armerr=0.;prop_position_error=0.;prop_angle_error=0.;mag_position_error=0.;mag_angle_error=0.;collisions=[];headgap=99.;headgap_info=None
bones=['Hips','LeftUpLeg','LeftLeg','LeftFoot','LeftToeBase','RightUpLeg','RightLeg','RightFoot','RightToeBase','Spine','Spine1','Spine2','Neck','Head','LeftArm','RightArm'];rate=480;N=round(C['duration']*rate);rel={n:Matrix(v) for n,v in M['prop_relative_matrices'].items()}
for i in range(N+1):
 t=i/rate;sf(t);rows.append({n:r.pose.bones[P+n].matrix.copy() for n in bones});v=skin(body);minsole=min(minsole,min(v[j].z for ids in feet.values() for j in ids));G=r.pose.bones['Prop_Rifle'].matrix.copy();GI=G.inverted();handerr=max(handerr,max((GI@v[k]-handref[k]).length for k in hands));H=r.pose.bones[P+'RightHand'].matrix.copy()
 for n,R in rel.items():
  actual=r.pose.bones[n].matrix;target=H@R;prop_position_error=max(prop_position_error,(actual.translation-target.translation).length);prop_angle_error=max(prop_angle_error,qa(actual.to_quaternion(),target.to_quaternion()))
 magactual=r.pose.bones['Prop_Magazine_A'].matrix;mag_position_error=max(mag_position_error,(magactual.translation-G.translation).length);mag_angle_error=max(mag_angle_error,qa(magactual.to_quaternion(),G.to_quaternion()))
 for side in ['Left','Right']:
  bb=[r.pose.bones[P+side+n] for n in ['Arm','ForeArm','Hand']];armerr=max(armerr,*[abs((bb[j].head-bb[j+1].head).length-armref[side][j]) for j in [0,1]])
 if i%4==0:
  gv=skin(gun);mv=skin(mag);gb=BVHTree.FromPolygons(gv,gt,all_triangles=True);mb=BVHTree.FromPolygons(mv,mt,all_triangles=True);row={'t':t,'rifle':{name:crosses(tris,v,gv,gb,gt,regions) for name,tris in groups.items()},'installed_magazine':{name:crosses(tris,v,mv,mb,mt) for name,tris in groups.items() if name in ['torso','head_neck','legs']}}
  if any(row['rifle'].values()) or any(row['installed_magazine'].values()):collisions.append(row)
  hb=BVHTree.FromPolygons(v,groups['head_neck'],all_triangles=True)
  for j,p in enumerate(gv):
   d=hb.find_nearest(p)[3]
   if d<headgap:headgap=d;headgap_info={'t':t,'gun_vertex':j,'native_gun_y':gun.data.vertices[j].co.y}
print('DENSE_CONTACTS',json.dumps({'minsole':minsole,'handerr':handerr,'collision_sample_count':len(collisions),'headgap':headgap}),flush=True)
out.update({'dense_hz':rate,'collision_hz':120,'sole_min_m':minsole,'hand_skin_prop_relative_max_drift_m':handerr,'native_arm_length_max_error_m':armerr,'prop_from_right_hand_max_position_error_m':prop_position_error,'prop_from_right_hand_max_rotation_error_deg':prop_angle_error,'installed_magazine_from_gun_max_position_error_m':mag_position_error,'installed_magazine_from_gun_max_rotation_error_deg':mag_angle_error,'collision_samples':collisions,'head_neck_nearest_rifle_vertex_gap_m':headgap,'head_neck_nearest_rifle_vertex_info':headgap_info,'endpoint_position_m':{n:(rows[0][n].translation-rows[-1][n].translation).length for n in bones},'endpoint_rotation_deg':{n:qa(rows[0][n].to_quaternion(),rows[-1][n].to_quaternion()) for n in bones},'maximum_dense_rotation_step_deg':{n:max(qa(rows[i][n].to_quaternion(),rows[i+1][n].to_quaternion()) for i in range(N)) for n in bones}})
before=set(bpy.data.objects);bpy.ops.import_scene.fbx(filepath=C['source_path']);added=set(bpy.data.objects)-before;sr=next(o for o in added if o.type=='ARMATURE');lo,hi=sr.animation_data.action.frame_range;fps=s.render.fps;s.frame_set(math.floor(lo),subframe=lo%1);p0=(sr.matrix_world@sr.pose.bones[P+'Hips'].matrix).translation.copy();s.frame_set(math.floor(hi),subframe=hi%1);p1=(sr.matrix_world@sr.pose.bones[P+'Hips'].matrix).translation.copy();delta=p1-p0;srcrows=[]
for i in range(N+1):
 t=i/rate;f=lo+t*fps;s.frame_set(math.floor(f),subframe=f%1);off=Vector((p0.x,p0.y,0))+Vector((delta.x,delta.y,0))*t/C['duration'];row={}
 for n in bones:row[n]=(sr.matrix_world@sr.pose.bones[P+n].matrix).copy();row[n].translation-=off
 srcrows.append(row)
out['independent_source']={'fps':fps,'frame_range':[lo,hi],'duration':(hi-lo)/fps,'root_delta_m':list(delta),'hip_position_max_error_m':max((x['Hips'].translation-y['Hips'].translation).length for x,y in zip(rows,srcrows)),'world_rotation_max_error_deg':{n:max(qa(x[n].to_quaternion(),y[n].to_quaternion()) for x,y in zip(rows,srcrows)) for n in ['Hips','Spine','Spine1','Neck','Head','LeftFoot','RightFoot']},'anatomical_shoulder_frame_max_error_deg':max(qa(anatomy(x),anatomy(y)) for x,y in zip(rows,srcrows))}
json.dump(out,open(Q/'run_forward_independent.json','w'),indent=2);print('QA_DONE',json.dumps(out),flush=True)
