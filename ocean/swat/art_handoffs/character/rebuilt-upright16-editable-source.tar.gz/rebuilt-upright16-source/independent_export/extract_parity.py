import bpy, json, hashlib, math, numpy as np
from pathlib import Path

O=Path('/workspace/scratch/eac4961518d4/animation_rebuild/upright_locomotion')
Q=O/'independent_export'; T=Path('/tmp/new16_upright_export_gate'); T.mkdir(exist_ok=True)
M=json.load(open(O/'all16_manifest.json')); E=json.load(open(O/'glb_export_manifest.json'))
sha=lambda p:hashlib.file_digest(open(p,'rb'),'sha256').hexdigest()
assert sha(M['base_blend'])==M['base_sha256'] and sha(M['library'])==M['library_sha256'] and sha(E['output'])==E['sha256']
bpy.ops.wm.open_mainfile(filepath=M['base_blend']); s=bpy.context.scene; s.render.fps=30; s.render.fps_base=1
r=bpy.data.objects['SWAT_Mixamo_Rig']; r.animation_data.action=None
for tr in list(r.animation_data.nla_tracks):r.animation_data.nla_tracks.remove(tr)
with bpy.data.libraries.load(M['library'],link=False) as (src,dst):dst.actions=[c['action'] for c in M['clips']]
bn=[b.name for b in r.data.bones]; bi={n:i for i,n in enumerate(bn)}
names=['Rebuilt SWAT full body','Rifle 7','Removed magazine','Fresh magazine']
def sf(t):
 f=t*30; s.frame_set(math.floor(f),subframe=f%1)
def static(r,meshes):
 out={'bone_names':np.array(bn),'rest':np.array([r.matrix_world@r.data.bones[n].matrix_local for n in bn]),'parent_names':np.array([r.data.bones[n].parent.name if r.data.bones[n].parent else '' for n in bn])}
 for ix,o in enumerate(meshes):
  out[f'p{ix}']=np.array([o.matrix_world@v.co for v in o.data.vertices]); w=np.zeros((len(o.data.vertices),len(bn)))
  for v in o.data.vertices:
   for g in v.groups:
    n=o.vertex_groups[g.group].name
    if n in bi:w[v.index,bi[n]]=g.weight
  out[f'w{ix}']=w; out[f'tris{ix}']=np.array([list(t.vertices) for t in o.data.loop_triangles])
 return out
meshes=[bpy.data.objects[n] for n in names]
for o in meshes:o.data.calc_loop_triangles()
S=static(r,meshes); RI=np.linalg.inv(S['rest']); source=[]; control=[]
for ci,c in enumerate(M['clips']):
 r.animation_data.action=bpy.data.actions[c['action']]; N=round(c['duration']*480); mats=[]
 for i in range(N+1):
  sf(i/480); mats.append(np.array([r.matrix_world@r.pose.bones[n].matrix for n in bn])@RI)
  if i in (0,N//2,N):
   for mi,o in enumerate(meshes):
    ev=o.evaluated_get(bpy.context.evaluated_depsgraph_get()); me=ev.to_mesh(); v=np.array([o.matrix_world@x.co for x in me.vertices]); ev.to_mesh_clear()
    np.save(T/f'source_skin_{ci}_{i}_{mi}.npy',v)
 S[f'd{ci}']=np.array(mats); print('SOURCE',c['source'],N+1,flush=True)
np.savez(T/'source.npz',**S)
bpy.ops.wm.read_factory_settings(use_empty=True); s=bpy.context.scene; s.render.fps=30; s.render.fps_base=1
bpy.ops.import_scene.gltf(filepath=E['output']); r=next(o for o in bpy.data.objects if o.type=='ARMATURE')
action_map={}
for tr in r.animation_data.nla_tracks:
 for st in tr.strips:action_map[tr.name]=st.action
for ac in bpy.data.actions:
 for c in M['clips']:
  if ac.name.startswith(c['action']):action_map[c['action']]=ac
inventory={'armature':r.name,'bones':[b.name for b in r.data.bones],'actions':[a.name for a in bpy.data.actions],'action_map':{k:v.name for k,v in action_map.items()},'objects':[(o.name,o.type) for o in bpy.data.objects]}
json.dump(inventory,open(Q/'reimport_inventory.json','w'),indent=2)
assert set(bn)==set(b.name for b in r.data.bones)
for tr in list(r.animation_data.nla_tracks):r.animation_data.nla_tracks.remove(tr)
meshes=[bpy.data.objects[n] for n in names]
for o in meshes:o.data.calc_loop_triangles()
I=static(r,meshes); II=np.linalg.inv(I['rest']); report={'source_sha256':M['library_sha256'],'glb_sha256':E['sha256'],'sample_hz':480,'bone_count':len(bn),'parent_identity':np.array_equal(S['parent_names'],I['parent_names']),'clips':[]}
for ci,c in enumerate(M['clips']):
 r.animation_data.action=action_map[c['action']]; N=round(c['duration']*480); mats=[]
 for i in range(N+1):
  sf(i/480); mats.append(np.array([r.matrix_world@r.pose.bones[n].matrix for n in bn])@II)
  if i in (0,N//2,N):
   for mi,o in enumerate(meshes):
    ev=o.evaluated_get(bpy.context.evaluated_depsgraph_get()); me=ev.to_mesh(); v=np.array([o.matrix_world@x.co for x in me.vertices]); ev.to_mesh_clear()
    np.save(T/f'reimport_skin_{ci}_{i}_{mi}.npy',v)
 I[f'd{ci}']=np.array(mats); err=np.abs(I[f'd{ci}']-S[f'd{ci}']); row={'name':c['action'],'samples':N+1,'duration':c['duration'],'frame_range':list(r.animation_data.action.frame_range),'max_world_deformation_matrix_element_error':float(err.max()),'endpoint_matrix_error':float(err[[0,-1]].max())}; report['clips'].append(row); print('REIMPORT',json.dumps(row),flush=True)
np.savez(T/'reimport.npz',**I)
report['max_world_deformation_matrix_element_error']=max(x['max_world_deformation_matrix_element_error'] for x in report['clips'])
report['notes']='World deformation matrices compare pose times inverse bind; raw bone axes may differ after import. Source/evaluated skin snapshots are saved for independent numeric skin verification.'
json.dump(report,open(Q/'reimport_deformation_report.json','w'),indent=2)
assert sha(M['base_blend'])==M['base_sha256'] and sha(M['library'])==M['library_sha256'] and sha(E['output'])==E['sha256']
print('EXTRACT_DONE',flush=True)
