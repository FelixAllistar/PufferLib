# Independent NEW16 export gate: PASS

NEW16 rebuilt upright FREE off-shoulder low-ready locomotion only

Verified actual GLB: 48,220,152 bytes; SHA-256 dd39631831ba8895da00d43132d34f13e1283710be41cddff372d0067e8e06bd.

Compared all rendered body/rifle/magazine vertices at 480 Hz over 5,776 samples, including every endpoint, against the exact base plus action library. Standard glTF LINEAR quaternion shortest-path slerp and an actual Blender 4.3.2 reimport both pass.

Maximum skin difference: standard glTF 0.001291 mm; Blender reimport 0.001464 mm. Minimum exported sole clearance: 3.406791 mm.

All 16 exact animation names, eight 0.5-second runs, eight 1-second walks, native 60 Hz keys, 240 Hz correction keys, 70 skeleton joints/parents, seven body influences, source rendered triangles and all three props are preserved.

- Body export contains 31,687 vertices because of material/UV/normal seams; all 24,850 source vertices are represented.
- Rifle export omits exactly six loose source vertices unreferenced by any triangle; all 10,273 rendered triangles and their bind/weight data are preserved.
- Weights are normalized equivalents of source Blender weights, whose raw sums range from 0.998248212 to 1.000000045. Literal raw-weight bytes are not claimed identical.
- Quaternion sign flips in serialized channels are handled by standard shortest-path slerp; dense actual skin parity passes.

No engine/runtime parity claim. No new style approval, ADS, seated Ready or reload verification. Previous source/collision/ordered-frame gates remain separate evidence.
