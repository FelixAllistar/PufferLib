from pathlib import Path
exec(Path(__file__).with_name('check_glb.py').read_text().split('mesh=[];stat=[]')[0])

def canonical(v):
 x=[int(z) for z in v];return min(tuple(x[i:]+x[:i]) for i in range(3))
names=['Rebuilt SWAT full body','Rifle 7','Removed magazine','Fresh magazine'];rows=[]
for mi,name in enumerate(names):
 n=next(n for n in nodes if n.get('name')==name);primitives=G['meshes'][n['mesh']]['primitives'];ps=[];ws=[];tris=[];cnt=0
 for prim in primitives:
  a=prim['attributes'];p=acc(a['POSITION']).astype(float)@C[:3,:3].T;w=np.zeros((len(p),len(bn)))
  for group in range(2):
   if f'JOINTS_{group}' in a:
    j=acc(a[f'JOINTS_{group}']).astype(int);ww=acc(a[f'WEIGHTS_{group}']).astype(float)
    for k in range(4):np.add.at(w,(np.arange(len(p)),np.array(ji)[j[:,k]]),ww[:,k])
  tris.extend((acc(prim['indices']).reshape(-1,3)+cnt).tolist());cnt+=len(p);ps.append(p);ws.append(w)
 P=np.concatenate(ps);W=np.concatenate(ws);sp=S[f'p{mi}'];sw=S[f'w{mi}'];swn=sw/sw.sum(1)[:,None];wn=W/W.sum(1)[:,None];ids,pe,we=match(P,wn,sp,swn);iw=I[f'w{mi}'];im,ipe,iwe=match(I[f'p{mi}'],iw/iw.sum(1)[:,None],sp,swn)
 signatures={};sid=[]
 for p,w in zip(sp,swn):
  sig=tuple(p.tolist())+tuple(np.round(w,6).tolist());sid.append(signatures.setdefault(sig,len(signatures)))
 sid=np.array(sid);source_faces=collections.Counter(canonical(t) for t in sid[S[f'tris{mi}']]);glb_faces=collections.Counter(canonical(t) for t in sid[ids][np.array(tris)])
 row={'name':name,'all_glb_bind_positions_match_source_m':pe,'all_reimport_bind_positions_match_source_m':ipe,'all_glb_normalized_weight_max_error':we,'all_reimport_normalized_weight_max_error':iwe,'all_glb_nonzero_influence_sets_equal':bool(np.array_equal(W>0,sw[ids]>0)),'all_reimport_nonzero_influence_sets_equal':bool(np.array_equal(iw>0,sw[im]>0)),'source_raw_weight_sum_range':[float(sw.sum(1).min()),float(sw.sum(1).max())],'source_unique_bind_weight_signatures':len(signatures),'glb_unique_source_signatures':len(set(sid[ids].tolist())),'all_source_bind_weight_signatures_present':set(sid)==set(sid[ids]),'oriented_triangle_multiset_matches_after_seam_deduplication':source_faces==glb_faces,'maximum_influences':int((W>0).sum(1).max())};missing=set(sid)-set(sid[ids]);surface=set(sid[S[f'tris{mi}'].ravel()]);row.update({'omitted_source_vertex_signatures':len(missing),'all_omitted_vertices_are_unreferenced_by_triangles':not bool(missing & surface),'all_source_surface_bind_weight_signatures_present':surface<=set(sid[ids])});rows.append(row);print(row,flush=True)
report={'status':'PASS' if all(x['all_glb_normalized_weight_max_error']<1e-6 and x['all_reimport_normalized_weight_max_error']<1e-6 and x['all_glb_nonzero_influence_sets_equal'] and x['all_reimport_nonzero_influence_sets_equal'] and x['all_source_surface_bind_weight_signatures_present'] and x['all_omitted_vertices_are_unreferenced_by_triangles'] and x['oriented_triangle_multiset_matches_after_seam_deduplication'] for x in rows) else 'FAIL','meshes':rows,'normalization_note':'Source Blender armature evaluation normalizes weights. The glTF exporter serialized normalized equivalents (source raw sums 0.9982482–1.00000005). This is expected, not literal raw-weight byte identity. All nonzero influences must remain present.'}
json.dump(report,open(Q/'bind_weight_identity.json','w'),indent=2)
