"""Independent actual-GLB parser, standard LINEAR/slerp player and skin comparison."""
import json, struct, hashlib, collections
from pathlib import Path
import numpy as np
from scipy.spatial import cKDTree

O=Path('/workspace/scratch/eac4961518d4/animation_rebuild/upright_locomotion'); Q=O/'independent_export'; T=Path('/tmp/new16_upright_export_gate')
M=json.load(open(O/'all16_manifest.json')); E=json.load(open(O/'glb_export_manifest.json')); S=np.load(T/'source.npz'); I=np.load(T/'reimport.npz')
data=Path(E['output']).read_bytes(); assert hashlib.sha256(data).hexdigest()==E['sha256']
magic,version,length=struct.unpack_from('<4sII',data); assert magic==b'glTF' and version==2 and length==len(data)
size,kind=struct.unpack_from('<II',data,12); G=json.loads(data[20:20+size]); off=20+size; bs,bk=struct.unpack_from('<II',data,off); B=data[off+8:off+8+bs]
def acc(i):
 a=G['accessors'][i]; b=G['bufferViews'][a['bufferView']]; dt={5126:'<f4',5125:'<u4',5123:'<u2',5121:'u1',5122:'<i2',5120:'i1'}[a['componentType']]; count={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4,'MAT4':16}[a['type']]; stride=b.get('byteStride',np.dtype(dt).itemsize*count)
 x=np.ndarray((a['count'],count),dtype=dt,buffer=B,offset=b.get('byteOffset',0)+a.get('byteOffset',0),strides=(stride,np.dtype(dt).itemsize)).copy()
 assert not a.get('sparse')
 if a.get('normalized'):x=x.astype(float)/np.iinfo(dt).max
 return x
C=np.array([[1,0,0,0],[0,0,-1,0],[0,1,0,0],[0,0,0,1]],dtype=float)
bn=list(S['bone_names']); bi={n:i for i,n in enumerate(bn)}; nodes=G['nodes']; skin=G['skins'][0]; joints=skin['joints']; ji=[bi[nodes[j]['name']] for j in joints]
parent={ch:i for i,n in enumerate(nodes) for ch in n.get('children',[])}
IBM=acc(skin['inverseBindMatrices']).reshape(-1,4,4).transpose(0,2,1).astype(float)
def rotate(q):
 q=q/np.linalg.norm(q,axis=-1,keepdims=True); x,y,z,w=np.moveaxis(q,-1,0); a=np.zeros(q.shape[:-1]+(3,3)); a[...,0,0]=1-2*(y*y+z*z);a[...,0,1]=2*(x*y-z*w);a[...,0,2]=2*(x*z+y*w);a[...,1,0]=2*(x*y+z*w);a[...,1,1]=1-2*(x*x+z*z);a[...,1,2]=2*(y*z-x*w);a[...,2,0]=2*(x*z-y*w);a[...,2,1]=2*(y*z+x*w);a[...,2,2]=1-2*(x*x+y*y);return a
def globals_at(animation,times):
 N=len(times); tr=np.broadcast_to(np.array([n.get('translation',[0,0,0]) for n in nodes]),(N,len(nodes),3)).copy(); ro=np.broadcast_to(np.array([n.get('rotation',[0,0,0,1]) for n in nodes]),(N,len(nodes),4)).copy(); sc=np.broadcast_to(np.array([n.get('scale',[1,1,1]) for n in nodes]),(N,len(nodes),3)).copy()
 if animation:
  for channel in animation['channels']:
   sam=animation['samplers'][channel['sampler']]; assert sam.get('interpolation','LINEAR')=='LINEAR'; t=acc(sam['input']).ravel().astype(float); v=acc(sam['output']).astype(float); j=np.clip(np.searchsorted(t,times,side='right')-1,0,len(t)-2); alpha=np.clip((times-t[j])/(t[j+1]-t[j]),0,1)[:,None]; p=channel['target']['path']; idx=channel['target']['node']
   if p=='rotation':
    q0=v[j]/np.linalg.norm(v[j],axis=1,keepdims=True);q1=v[j+1]/np.linalg.norm(v[j+1],axis=1,keepdims=True);dot=np.sum(q0*q1,axis=1,keepdims=True);q1=np.where(dot<0,-q1,q1);dot=np.clip(np.abs(dot),0,1);theta=np.arccos(dot);den=np.sin(theta);small=den<1e-6;den=np.where(small,1,den);out=np.where(small,q0*(1-alpha)+q1*alpha,np.sin((1-alpha)*theta)/den*q0+np.sin(alpha*theta)/den*q1);ro[:,idx]=out/np.linalg.norm(out,axis=1,keepdims=True)
   elif p=='translation':tr[:,idx]=v[j]*(1-alpha)+v[j+1]*alpha
   elif p=='scale':sc[:,idx]=v[j]*(1-alpha)+v[j+1]*alpha
   else:raise AssertionError(p)
 local=np.zeros((N,len(nodes),4,4));local[...,:3,:3]=rotate(ro)*sc[...,None,:];local[...,:3,3]=tr;local[...,3,3]=1
 for ni,n in enumerate(nodes):
  if 'matrix' in n:local[:,ni]=np.array(n['matrix']).reshape(4,4).T
 world=np.empty_like(local);seen=set()
 def solve(j):
  if j in seen:return
  if j in parent:solve(parent[j]);world[:,j]=world[:,parent[j]]@local[:,j]
  else:world[:,j]=local[:,j]
  seen.add(j)
 for j in range(len(nodes)):solve(j)
 return world
rest=globals_at(None,np.array([0.]))[0]; restD=C@rest[joints]@IBM@C.T
def match(P,W,Ps,Ws):
 dist,idx=cKDTree(Ps).query(P,k=min(16,len(Ps)));we=np.max(np.abs(W[:,None,:]-Ws[idx]),axis=2);score=dist+we;pick=np.argmin(score,axis=1); ids=idx[np.arange(len(P)),pick];return ids,float(np.linalg.norm(P-Ps[ids],axis=1).max()),float(np.max(np.abs(W-Ws[ids])))
mesh=[];stat=[]
names=['Rebuilt SWAT full body','Rifle 7','Removed magazine','Fresh magazine']
for mi,name in enumerate(names):
 ni=next(i for i,n in enumerate(nodes) if n.get('name')==name);n=nodes[ni];primitives=G['meshes'][n['mesh']]['primitives'];ps=[];ws=[];indices=[];cnt=0
 for prim in primitives:
  a=prim['attributes'];p=acc(a['POSITION']).astype(float)@C[:3,:3].T;w=np.zeros((len(p),len(bn)))
  for group in range(2):
   if f'JOINTS_{group}' in a:
    j=acc(a[f'JOINTS_{group}']).astype(int);ww=acc(a[f'WEIGHTS_{group}']).astype(float)
    for k in range(4):np.add.at(w,(np.arange(len(p)),np.array(ji)[j[:,k]]),ww[:,k])
  indices.append(acc(prim['indices']).ravel()+cnt);cnt+=len(p);ps.append(p);ws.append(w)
 P=np.concatenate(ps);W=np.concatenate(ws);ids,pe,we=match(P,W,S[f'p{mi}'],S[f'w{mi}']);im,ipe,iwe=match(I[f'p{mi}'],I[f'w{mi}'],S[f'p{mi}'],S[f'w{mi}'])
 row={'name':name,'source_vertices':len(S[f'p{mi}']),'glb_vertices_including_seams':len(P),'reimport_vertices':len(im),'position_max_error_m':pe,'weight_max_error':we,'max_influences_source':int((S[f'w{mi}']>0).sum(axis=1).max()),'max_influences_glb':int((W>0).sum(axis=1).max()),'vertices_over_four_influences_glb':int(((W>0).sum(axis=1)>4).sum()),'weight_sum_max_error':float(np.abs(W.sum(axis=1)-1).max()),'triangle_count_source':len(S[f'tris{mi}']),'triangle_count_glb':int(sum(len(x) for x in indices)//3),'reimport_bind_position_error_m':ipe,'reimport_weight_error':iwe}
 stat.append(row);mesh.append((P,W,ids,im)); print('MESH',json.dumps(row),flush=True)
report={'status':'checking','carry_intent':M['carry_intent'],'base_sha256':M['base_sha256'],'library_sha256':M['library_sha256'],'glb_sha256':E['sha256'],'glb_bytes':len(data),'node_count':len(nodes),'joint_count':len(joints),'joint_names_match':set(nodes[j]['name'] for j in joints)==set(bn),'parents_match':all((nodes[parent[j]]['name'] if parent.get(j) in joints else '')==S['parent_names'][bi[nodes[j]['name']]] for j in joints),'inverse_bind_rest_identity_element_error':float(np.abs(restD-np.eye(4)).max()),'meshes':stat,'clips':[],'sample_hz':480,'engine_runtime_parity_claim':False}
animations={a['name']:a for a in G['animations']};report['exact_animation_names_match']=set(animations)==set(c['action'] for c in M['clips'])
def skin_points(P,W,D):
 # Group by joint: process every nonzero weight, keeping all seven influences.
 out=np.zeros((len(D),len(P),3));W=W/W.sum(axis=1)[:,None]
 for j in range(W.shape[1]):
  ids=np.flatnonzero(W[:,j]);
  if len(ids):out[:,ids]+=(np.einsum('nij,vj->nvi',D[:,j,:3,:3],P[ids])+D[:,j,None,:3,3])*W[ids,j][None,:,None]
 return out
for ci,c in enumerate(M['clips']):
 a=animations[c['action']];times=np.arange(round(c['duration']*480)+1)/480; world=globals_at(a,times);d=np.empty((len(times),len(bn),4,4));d[:,ji]=C@world[:,joints]@IBM@C.T;ds=S[f'd{ci}'];di=I[f'd{ci}'];hist=collections.Counter();end=[];griderr=0.;gridpass=True;mindot=1.
 for sam in a['samplers']:
  ts=acc(sam['input']).ravel();hist[len(ts)]+=1;end.append((float(ts[0]),float(ts[-1])));griderr=max(griderr,float(np.max(np.abs(ts*240-np.round(ts*240)))));target=round(c['duration']*60)+1;dense=round(c['duration']*240)+1
  if len(ts)>2:gridpass &= len(ts) in (target,dense) and np.max(np.abs(ts-np.linspace(0,c['duration'],len(ts))))<1e-7
 for ch in a['channels']:
  if ch['target']['path']=='rotation':
   qs=acc(a['samplers'][ch['sampler']]['output']);qs=qs/np.linalg.norm(qs,axis=1,keepdims=True);mindot=min(mindot,float(np.sum(qs[:-1]*qs[1:],axis=1).min()))
 row={'name':c['action'],'samples':len(times),'duration':c['duration'],'all_channels_exact_endpoints':all(x==(0.,c['duration']) for x in end),'key_count_histogram':dict(hist),'native_60hz_or_correction_240hz_complete_grids':bool(gridpass),'timestamp_240hz_tick_max_error':griderr,'minimum_adjacent_quaternion_dot':mindot,'max_world_deformation_matrix_element_error_standard_slerp':float(np.abs(d-ds).max()),'max_world_deformation_matrix_element_error_reimport':float(np.abs(di-ds).max()),'endpoint_deformation_matrix_element_error_standard_slerp':float(np.abs(d[[0,-1]]-ds[[0,-1]]).max()),'skin':[]}
 for mi,(P,W,ids,im) in enumerate(mesh):
  maxerr=0.;maxierr=0.;sole=999.;soleS=999.;soleI=999.;ends=0.;eval_source=0.;eval_import=0.;sp=S[f'p{mi}'];sw=S[f'w{mi}'];ip=I[f'p{mi}'];iw=I[f'w{mi}'];feet=np.array([j for j,n in enumerate(bn) if any(n.startswith('mixamorig:'+side+part) for side in ('Left','Right') for part in ('Foot','ToeBase','Toe_End'))]);mask=sw[:,feet].sum(axis=1)>.65;maskg=W[:,feet].sum(axis=1)>.65;maski=iw[:,feet].sum(axis=1)>.65
  for start in range(0,len(times),24):
   stop=min(start+24,len(times));src=skin_points(sp,sw,ds[start:stop]);raw=skin_points(P,W,d[start:stop]);imp=skin_points(ip,iw,di[start:stop]);err=np.linalg.norm(raw-src[:,ids],axis=2);ierr=np.linalg.norm(imp-src[:,im],axis=2);maxerr=max(maxerr,float(err.max()));maxierr=max(maxierr,float(ierr.max()))
   if start==0:ends=max(ends,float(err[0].max()))
   if stop==len(times):ends=max(ends,float(err[-1].max()))
   if mi==0:sole=min(sole,float(raw[:,maskg,2].min()));soleS=min(soleS,float(src[:,mask,2].min()));soleI=min(soleI,float(imp[:,maski,2].min()))
   for frame in (0,(len(times)-1)//2,len(times)-1):
    if start<=frame<stop:
     ev=np.load(T/f'source_skin_{ci}_{frame}_{mi}.npy');iev=np.load(T/f'reimport_skin_{ci}_{frame}_{mi}.npy');eval_source=max(eval_source,float(np.linalg.norm(src[frame-start]-ev,axis=1).max()));eval_import=max(eval_import,float(np.linalg.norm(imp[frame-start]-iev,axis=1).max()))
  sr={'name':names[mi],'all_vertex_max_difference_standard_slerp_m':maxerr,'all_vertex_max_difference_reimport_m':maxierr,'endpoint_skin_max_difference_m':ends,'source_skin_formula_vs_blender_evaluated_max_m':eval_source,'import_skin_formula_vs_blender_evaluated_max_m':eval_import}
  if mi==0:sr.update({'source_sole_min_m':soleS,'glb_standard_slerp_sole_min_m':sole,'reimport_sole_min_m':soleI})
  row['skin'].append(sr)
 report['clips'].append(row);json.dump(report,open(Q/'actual_glb_gate.json','w'),indent=2);print('CLIP',json.dumps(row),flush=True)
report['max_skin_difference_standard_slerp_m']=max(s['all_vertex_max_difference_standard_slerp_m'] for c in report['clips'] for s in c['skin']);report['max_skin_difference_reimport_m']=max(s['all_vertex_max_difference_reimport_m'] for c in report['clips'] for s in c['skin']);report['minimum_glb_sole_m']=min(c['skin'][0]['glb_standard_slerp_sole_min_m'] for c in report['clips']);report['status']='PASS' if report['exact_animation_names_match'] and report['joint_names_match'] and report['parents_match'] and report['max_skin_difference_standard_slerp_m']<.0001 and report['max_skin_difference_reimport_m']<.0001 and report['minimum_glb_sole_m']>0 and all(c['all_channels_exact_endpoints'] and c['native_60hz_or_correction_240hz_complete_grids'] for c in report['clips']) else 'FAIL'
report['limitations']='Numerical file, standard glTF interpolation and Blender import validation only. No engine/runtime evaluation, new style judgment, ADS, seated Ready or reload claims.'
for key,path in [('base_sha256',M['base_blend']),('library_sha256',M['library']),('glb_sha256',E['output'])]:assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==report[key]
json.dump(report,open(Q/'actual_glb_gate.json','w'),indent=2);print('FINAL',report['status'],report['max_skin_difference_standard_slerp_m'],report['max_skin_difference_reimport_m'],report['minimum_glb_sole_m'],flush=True)
