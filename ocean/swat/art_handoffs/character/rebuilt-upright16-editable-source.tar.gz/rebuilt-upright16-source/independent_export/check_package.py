"""Read-only independent compact dependency and portable rebuild verification."""
import bpy, hashlib, json, math, sys
from pathlib import Path
import numpy as np
O=Path('/workspace/scratch/eac4961518d4/animation_rebuild/upright_locomotion');Q=O/'independent_export';P=Path('/tmp/upright16-source-checkpoint');N=Path('/tmp/upright16-forward-rebuild-smoke/run_forward_actions.blend')
M=json.load(open(O/'all16_manifest.json'));C=json.load(open(P/'compact_geometry_manifest.json'));names=['Rebuilt SWAT full body','Rifle 7','Removed magazine','Fresh magazine'];sha=lambda p:hashlib.file_digest(open(p,'rb'),'sha256').hexdigest()
def digest(x):return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def ma(x):return [list(row) for row in x]
def action(a):
 return sorted([(f.data_path,f.array_index,f.extrapolation,[(tuple(k.co),k.interpolation,tuple(k.handle_left),tuple(k.handle_right),k.handle_left_type,k.handle_right_type) for k in f.keyframe_points],[(m.type,m.mute) for m in f.modifiers]) for f in a.fcurves])
def inspect(path):
 bpy.ops.wm.open_mainfile(filepath=str(path));r=bpy.data.objects['SWAT_Mixamo_Rig'];s=bpy.context.scene;payload={};info={}
 for n in names:
  o=bpy.data.objects[n];m=o.data;m.calc_loop_triangles()
  raw={'matrix':ma(o.matrix_world),'parent':o.parent.name if o.parent else None,'parent_type':o.parent_type,'parent_bone':o.parent_bone,'parent_inverse':ma(o.matrix_parent_inverse),'groups':[(g.index,g.name,g.lock_weight) for g in o.vertex_groups],'vertices':[(list(v.co),[(g.group,g.weight) for g in v.groups]) for v in m.vertices],'edges':[list(e.vertices) for e in m.edges],'polygons':[(list(p.vertices),p.material_index,p.use_smooth) for p in m.polygons],'triangles':[list(t.vertices) for t in m.loop_triangles],'uvs':[(u.name,[list(d.uv) for d in u.data]) for u in m.uv_layers],'corner_normals':[list(n.vector) for n in m.corner_normals],'shape_keys':bool(m.shape_keys),'modifiers':[(mod.name,mod.type,mod.object.name if mod.type=='ARMATURE' and mod.object else None,mod.show_viewport,mod.show_render,mod.use_deform_preserve_volume if mod.type=='ARMATURE' else None,mod.use_vertex_groups if mod.type=='ARMATURE' else None) for mod in o.modifiers]}
  payload[n]=digest(raw);info[n]={'vertices':len(m.vertices),'triangles':len(m.loop_triangles),'max_influences':max(len(v.groups) for v in m.vertices),'uvs':[u.name for u in m.uv_layers]}
 payload['rig']=digest({'matrix':ma(r.matrix_world),'bones':[(b.name,b.parent.name if b.parent else None,ma(b.matrix_local),list(b.head_local),list(b.tail_local),b.use_deform,b.use_connect,b.inherit_scale,b.use_inherit_rotation,b.use_local_location) for b in r.data.bones],'pose_settings':[(p.name,p.rotation_mode,[(c.name,c.type,c.mute,c.influence) for c in p.constraints]) for p in r.pose.bones]})
 payload['carry_actions']={a.name:digest(action(a)) for a in bpy.data.actions};images=len(bpy.data.images);source_actions=list(payload['carry_actions'])
 for tr in list(r.animation_data.nla_tracks):r.animation_data.nla_tracks.remove(tr)
 s.render.fps=30;s.render.fps_base=1
 with bpy.data.libraries.load(str(P/'all16_actions.blend'),link=False) as (src,dst):dst.actions=[c['action'] for c in M['clips']]
 frames={}
 for ac,c in zip(dst.actions,M['clips']):
  r.animation_data.action=ac
  for t in (0,c['duration']/2,c['duration']):
   f=t*30;s.frame_set(math.floor(f),subframe=f%1);row={}
   for n in names:
    o=bpy.data.objects[n].evaluated_get(bpy.context.evaluated_depsgraph_get());m=o.to_mesh();v=np.empty(len(m.vertices)*3,dtype=np.float32);m.vertices.foreach_get('co',v);row[n]=hashlib.sha256(v.tobytes()+np.array(o.matrix_world,dtype=np.float32).tobytes()).hexdigest();o.to_mesh_clear()
   row['rig_world_pose']=digest([ma(r.matrix_world@p.matrix) for p in r.pose.bones]);frames[c['source']+' @ '+str(t)]=row
 return {'payload':payload,'mesh_inventory':info,'image_count':images,'action_names':source_actions,'frames':frames,'bone_count':len(r.data.bones)}
report={'status':'checking','package':str(P),'base_sha256':sha(M['base_blend']),'compact_sha256':sha(P/C['output']),'compact_bytes':(P/C['output']).stat().st_size,'library_sha256':sha(P/'all16_actions.blend'),'rebuild_output_sha256':sha(N),'native_sources':[]}
assert report['base_sha256']==M['base_sha256'] and report['compact_sha256']==C['sha256'] and report['library_sha256']==M['library_sha256']
for c in M['clips']:
 path=P/'native_sources'/(c['source']+'.fbx');actual=sha(path);report['native_sources'].append({'name':c['source'],'sha256':actual,'matches_original':actual==c['source_sha256']})
origin=(O/'build_upright_reconstructed.py').read_text();portable=(P/'rebuild_from_pack.py').read_text();marker='bpy.ops.wm.open_mainfile(filepath=BASE)';report['rebuild_recipe_body_exactly_equal']=origin[origin.index(marker):]==portable[portable.index(marker):];report['archival_recipe_copy_exactly_equal']=sha(O/'build_upright_reconstructed.py')==sha(P/'build_upright_reconstructed.py')
before=inspect(M['base_blend']);after=inspect(P/C['output']);report['compact_payload_exactly_equal']=before['payload']==after['payload'];report['mesh_payload_sha256']=after['payload'];report['mesh_inventory']=after['mesh_inventory'];report['bone_count']=after['bone_count'];report['images_before_after']=[before['image_count'],after['image_count']];report['evaluated_geometry_and_world_bone_poses_exactly_equal']=before['frames']==after['frames'];report['evaluated_frame_count']=len(after['frames']);report['evaluated_mesh_snapshots']=len(after['frames'])*4;report['frame_mismatches']=[k for k in before['frames'] if before['frames'][k]!=after['frames'][k]];print('COMPACT',report['compact_payload_exactly_equal'],report['evaluated_geometry_and_world_bone_poses_exactly_equal'],flush=True)
bpy.ops.wm.open_mainfile(filepath=str(P/C['output']));r=bpy.data.objects['SWAT_Mixamo_Rig'];s=bpy.context.scene;s.render.fps=30;s.render.fps_base=1
for tr in list(r.animation_data.nla_tracks):r.animation_data.nla_tracks.remove(tr)
name=next(c['action'] for c in M['clips'] if c['source']=='run forward')
with bpy.data.libraries.load(str(P/'all16_actions.blend'),link=False) as (src,dst):dst.actions=[name]
a=dst.actions[0]
with bpy.data.libraries.load(str(N),link=False) as (src,dst):report['rebuild_library_inventory']={k:list(getattr(src,k)) for k in ['actions','objects','meshes','materials']};dst.actions=[name]
b=dst.actions[0];sa,sb=action(a),action(b);report['run_forward_curve_signature_exactly_equal']=sa==sb;report['run_forward_original_curve_sha256']=digest(sa);report['run_forward_rebuilt_curve_sha256']=digest(sb);report['run_forward_fcurve_count']=len(sa);poses=[]
for ac in (a,b):
 r.animation_data.action=ac;row=[]
 for i in range(241):
  f=i/480*30;s.frame_set(math.floor(f),subframe=f%1);row.append(np.array([ma(r.matrix_world@p.matrix) for p in r.pose.bones]))
 poses.append(np.array(row))
report['run_forward_480hz_pose_max_element_difference']=float(np.abs(poses[0]-poses[1]).max());report['run_forward_samples']=241;report['scope']='Compact untextured geometry and portable source package verification; no motion edits or new GLB checks';report['portability_review']='All rebuild calculations and output code are byte-identical after scene-load marker. Only documentation, argparse, package-relative paths, output-directory creation, compact dependency selection/hash check and bundled FBX path substitution differ.'
report['status']='PASS' if all(x['matches_original'] for x in report['native_sources']) and report['rebuild_recipe_body_exactly_equal'] and report['archival_recipe_copy_exactly_equal'] and report['compact_payload_exactly_equal'] and report['evaluated_geometry_and_world_bone_poses_exactly_equal'] and report['run_forward_curve_signature_exactly_equal'] and report['run_forward_480hz_pose_max_element_difference']==0 else 'FAIL'
assert sha(M['base_blend'])==report['base_sha256'] and sha(P/C['output'])==report['compact_sha256'] and sha(P/'all16_actions.blend')==report['library_sha256'] and sha(N)==report['rebuild_output_sha256']
json.dump(report,open(Q/'package_gate.json','w'),indent=2);print('PACKAGE_GATE',report['status'],report['run_forward_curve_signature_exactly_equal'],report['run_forward_480hz_pose_max_element_difference'],flush=True)
