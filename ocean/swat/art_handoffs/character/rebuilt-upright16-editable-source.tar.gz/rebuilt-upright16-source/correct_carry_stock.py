"""One bounded coupled hold correction for the measured inherited20.5mm stock burial."""
import bpy,json,math,hashlib
from pathlib import Path
from mathutils import Vector,Matrix
from mathutils.bvhtree import BVHTree
O=Path('/workspace/scratch/eac4961518d4/animation_rebuild/upright_locomotion');fm=json.load(open(O/'foundation_manifest.json'));sha=lambda p:hashlib.file_digest(open(p,'rb'),'sha256').hexdigest();assert sha(fm['output'])==fm['sha256'];bpy.ops.wm.open_mainfile(filepath=fm['output']);s=bpy.context.scene;r=bpy.data.objects[fm['rig']];body=bpy.data.objects[fm['body']];r.animation_data.action=bpy.data.actions[fm['carry_action']];s.frame_set(0);P='mixamorig:';before={b.name:b.matrix.copy() for b in r.pose.bones};basis_before={b.name:b.matrix_basis.copy() for b in r.pose.bones};lateral=before[P+'LeftArm'].translation-before[P+'RightArm'].translation;lateral.z=0;lateral.normalize();forward=Vector((lateral.y,-lateral.x,0));delta=-lateral*.060+forward*.022+Vector((0,0,.015))
def basis(v,n):
 y=v.normalized();x=(n-y*n.dot(y)).normalized();return Matrix((x,y,x.cross(y))).transposed()
rows={}
for side in ['Left','Right']:
 names=[P+side+x for x in ['Arm','ForeArm','Hand']];A,F,H=[before[n] for n in names];a,f,h=[r.pose.bones[n] for n in names];target=H.copy();target.translation+=delta;S=A.translation;T=target.translation;v1=F.translation-S;v2=H.translation-F.translation;l1=v1.length;l2=v2.length;u=(T-S).normalized();d=(T-S).length;assert d<l1+l2-.005
 x=(l1*l1-l2*l2+d*d)/(2*d);C=S+x*u;guide=F.translation+delta*.5;pole=guide-C;pole=(pole-u*pole.dot(u)).normalized();E=C+math.sqrt(max(0,l1*l1-x*x))*pole;n0=v1.cross(v2).normalized();n=(E-S).cross(T-E).normalized();AA=(basis(E-S,n)@basis(v1,n0).transposed()).to_4x4()@A;AA.translation=S;FF=(basis(T-E,n)@basis(v2,n0).transposed()).to_4x4()@F;FF.translation=E;a.matrix=AA;bpy.context.view_layer.update();f.matrix=FF;bpy.context.view_layer.update();h.matrix=target;bpy.context.view_layer.update();hand_forward=r.pose.bones[P+side+'HandMiddle1'].head-h.head;rows[side]={'reach_margin_m':l1+l2-d,'arm_length_error_m':abs((f.head-a.head).length-l1),'forearm_length_error_m':abs((h.head-f.head).length-l2),'wrist_bend_degrees':math.degrees((h.head-f.head).angle(hand_forward)),'target_error_m':(h.head-target.translation).length}
for name in ['Prop_Rifle','Prop_Magazine_A']:
 M=before[name].copy();M.translation+=delta;r.pose.bones[name].matrix=M
bpy.context.view_layer.update();newpose={b.name:b.matrix_basis.copy() for b in r.pose.bones};hand_gun=max(max(abs((r.pose.bones[P+side+'Hand'].matrix.inverted()@r.pose.bones['Prop_Rifle'].matrix)[i][j]-(before[P+side+'Hand'].inverted()@before['Prop_Rifle'])[i][j]) for i in range(4) for j in range(4)) for side in ['Left','Right'])
carry=bpy.data.actions.new('Rebuild Carry Reference / Stock Cleared FPS Idle');carry.use_fake_user=True
for n,M in newpose.items():
 for field,values in zip(['location','rotation_quaternion','scale'],M.decompose()):
  for j,v in enumerate(values):
   fc=carry.fcurves.new('pose.bones["'+n+'"].'+field,index=j,action_group=n)
   for frame in [0,30]:fc.keyframe_points.insert(frame,float(v)).interpolation='LINEAR'
r.animation_data.action=carry;s.frame_set(0);out=O/'upright_foundation_stockcleared.blend';bpy.context.preferences.filepaths.save_version=0;bpy.ops.wm.save_as_mainfile(filepath=str(out),compress=True);lib=O/'stock_cleared_carry.actions.blend';bpy.data.libraries.write(str(lib),{carry},fake_user=True,compress=True)
rec={**fm,'output':str(out),'sha256':sha(out),'carry_action':carry.name,'carry_source':'Older recovered FPS Idle plus new coupled stock-clearance correction, not prior latest-bank parity','parent_foundation':fm['output'],'parent_foundation_sha256':fm['sha256'],'carry_action_library':str(lib),'carry_action_library_sha256':sha(lib),'correction':{'reason':'Independent gate measured20.5mm stock burial at chest/shoulder boundary in older recovered FPS Idle','body_frame_translation_m':{'outward_right':.060,'forward':.022,'up':.015},'world_translation_m':list(delta),'arm_solver':'Native affine two-bone chains, original elbow branch guide transported halfway with the wrists','both_hand_to_gun_matrix_max_error':hand_gun,'arms':rows},'status':'new_carry_correction_pending_contact_gate'};json.dump(rec,open(O/'foundation_stockcleared_manifest.json','w'),indent=2);print('CARRY_CORRECTION',json.dumps(rec['correction']),flush=True);assert sha(fm['output'])==fm['sha256']
