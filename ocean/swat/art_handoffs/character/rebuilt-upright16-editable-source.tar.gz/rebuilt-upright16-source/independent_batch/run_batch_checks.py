import json,time,subprocess,hashlib
from pathlib import Path
O=Path('/workspace/scratch/eac4961518d4/animation_rebuild/upright_locomotion');Q=O/'independent_batch'
while True:
 try:
  if not any(x.startswith('DONE ') for x in (O/'build_all16.log').read_text().splitlines()):time.sleep(5);continue
  m=json.load(open(O/'all16_manifest.json'))
  if len(m['clips'])==16 and hashlib.file_digest(open(m['library'],'rb'),'sha256').hexdigest()==m['library_sha256']:break
 except (FileNotFoundError,json.JSONDecodeError):pass
 time.sleep(5)
print('STABLE_LIBRARY',m['library_sha256'],flush=True)
rows=[]
for c in m['clips']:
 tag=c['source'].replace(' ','_')
 with open(Q/(tag+'_check.log'),'w') as f:r=subprocess.run(['blender','-b','-t','1','--python',str(Q/'check_batch_clip.py'),'--',c['source']],stdout=f,stderr=subprocess.STDOUT)
 assert r.returncode==0,(c['source'],r.returncode)
 d=json.load(open(Q/(tag+'_independent.json')));row={'source':c['source'],'sole_min_m':d['sole_min_m'],'grip_drift_m':d['hand_skin_prop_relative_max_drift_m'],'prop_position_error_m':d['prop_from_right_hand_max_position_error_m'],'prop_angle_error_deg':d['prop_from_right_hand_max_rotation_error_deg'],'collisions':len(d['collision_samples']),'source_fps':d['independent_source']['fps'],'source_duration':d['independent_source']['duration'],'source_hip_position_error_m':d['independent_source']['hip_position_max_error_m'],'source_gaze_error_deg':max(d['independent_source']['world_rotation_max_error_deg'][n] for n in ['Neck','Head']),'source_shoulder_error_deg':d['independent_source']['anatomical_shoulder_frame_max_error_deg'],'source_root_delta_error_m':d['direction_root_delta_error_m'],'rest_error':d['human_rest_matrix_max_difference'],'key_quaternion_min_dot':d['quaternion_min_adjacent_key_dot']};rows.append(row);json.dump({'library_sha256':m['library_sha256'],'clips':rows,'complete':len(rows)==16},open(Q/'batch_summary.json','w'),indent=2);print('CLIP_QA',json.dumps(row),flush=True)
print('BATCH_QA_DONE',flush=True)
