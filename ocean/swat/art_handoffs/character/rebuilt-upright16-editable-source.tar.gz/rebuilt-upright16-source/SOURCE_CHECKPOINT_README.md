# Rebuilt upright locomotion: editable source checkpoint

This is a new reconstruction of 16 upright clips: walk and run in eight directions. It uses the original per-direction 60 Hz FBXs, the restored compatible SWAT body/skeleton, and a validated free low-ready rifle carry. It is not a byte recovery of the earlier lost animation bank.

The rifle is held off the shoulder. These actions are not ADS, shoulder-seated Ready, or reload poses. Crouch, prone, reloads and engine behavior are outside this checkpoint.

## Open and edit

Open `upright16_editable_untextured.blend` in Blender 4.3.2. The complete body, rifle, magazines, 70-bone rig, two static carry references and 16 rebuilt actions are included. The active action is `Rebuilt Upright Native Frame / run forward`. Choose another `Rebuilt Upright Native Frame / …` action in the Action Editor.

This compact scene deliberately has no texture images. Geometry, UVs, skin weights, skeleton and carry curves match the fully textured authoring foundation. Use the separate `rebuilt-upright16-free-lowready.glb` for the packed textured model and all 16 animations.

The Blender scene is 30 fps with fractional keys. Each walk is frames 0–30, exactly 1 second; each run is frames 0–15, exactly 0.5 second. Native source timing is 60 Hz; shoulder/gaze, grounding and prop corrections use 240 Hz. Preserve fractional times. A 30 Hz resample is not an equivalent serialization.

`all16_actions.blend` is the compact action-only bank. To load it on the included verified geometry dependency and save a fresh scene:

```sh
blender -b --python append_rebuilt_actions.py -- --clip "walk backward right" --output /absolute/new/scene.blend
```

The loader verifies file hashes and refuses to overwrite an existing output. It accepts the included compact base or the exact original textured foundation. It does not modify either dependency.

## Rebuild from original motion

All 16 original FBXs are included in `native_sources/` with their original verified bytes. To rebuild the full set from these sources and the included corrected carry seed:

```sh
blender -b -t 4 --python rebuild_from_pack.py -- --output-dir /absolute/new/rebuild-folder
```

For a single representative clip, add `--clip "run forward"`. The output folder must not already exist. The portable builder differs from the original author script only in path, command-line and dependency plumbing. It uses each direction's own source frame rather than pasting the forward pose into other directions.

The builder removes each clip's horizontal root displacement to make in-place animation. Original root vectors and nominal motion speeds are in `all16_manifest.json`; a runtime must supply appropriate movement. Ground clearance does not imply fixed-world foot planting.

## Evidence

- `compact_geometry_manifest.json`: exact body/prop geometry, UVs, weights, rest skeleton and static-carry signature match; all four core meshes have identical evaluated vertex hashes at start, midpoint and endpoint for all 16 clips
- `independent_batch/final_gate.json`: 5,776 dense source/ground samples; 1,456 collision samples with no tested rifle/magazine crossings; all native-time ordered frames inspected
- `independent_export/final_export_gate.json`: actual GLB and actual Blender reimport parity at 480 Hz, all 16 durations/names, all 70 joints, and all seven body influences preserved
- `independent_export/package_gate.json`: all 16 clips rebuilt from the included sources with exactly identical action curves; direct-open scene inventory, compact geometry and forward dense poses independently verified
- `rebuilt-upright-walk-run-16.mp4`: 8-second, 60 fps labeled overview at original speed, walk8 then run8

Maximum actual Blender-reimport skin difference is 0.001464 mm. Minimum exported sole clearance is 3.406791 mm. The exporter splits body vertices at UV/material/normal seams and normalizes equivalent weight sums. It omits six loose rifle vertices not used by any triangle; every rendered surface triangle is retained.

The full geometry retains the source rig and all seven weights. Free carry preserves hand contact; stock-to-shoulder seating is intentionally not claimed. Small inherited endpoint residuals remain, including about 0.938 degrees on some toes and about 0.253 degrees on the walk-forward shin. Arm motion is tied closely to the chest/carry, so these checks do not establish ideal natural timing or weight.

No engine/controller/blending test has been performed. Ordered frames and numerical evaluation were reviewed; live playback observation is not claimed. The final GLB report supersedes the earlier batch report's then-pending export parity limit.

## Provenance and recovery

`SOURCEPACK_MANIFEST.json` records every packaged file's hash, original authoring dependencies, verified deliverables, and archive scope. `source_registry.json` preserves the original source paths and hashes; the portable builder resolves the same bytes from `native_sources/`.

The original author and inspection scripts are retained as evidence. Scripts other than `append_rebuilt_actions.py` and `rebuild_from_pack.py` may contain the original workspace paths and require those dependencies; do not assume all historical scripts are portable. The compact base makes opening, editing and native-motion reconstruction self-contained. The packed texture images remain in the separate GLB and full textured foundation, rather than this source archive.
