"""Load the verified16 actions on either exact verified foundation. Never overwrite files."""
import argparse
import hashlib
import json
import math
from pathlib import Path
import re
import sys
import bpy
from mathutils import Vector

HERE = Path(__file__).resolve().parent
p = argparse.ArgumentParser()
p.add_argument('--manifest', default=str(HERE / 'all16_manifest.json'))
p.add_argument('--base')
p.add_argument('--library')
p.add_argument('--clip', default='run forward')
p.add_argument('--output')
args = p.parse_args(sys.argv[sys.argv.index('--') + 1:] if '--' in sys.argv else [])
m = json.load(open(args.manifest))
folder = Path(args.manifest).resolve().parent
sha = lambda x: hashlib.file_digest(open(x, 'rb'), 'sha256').hexdigest()
allowed = {m['base_sha256']}
compact_file = folder / 'compact_geometry_manifest.json'
compact = json.load(open(compact_file)) if compact_file.exists() else None
if compact:
    assert compact['status'] == 'PASS'
    assert compact['source_base_sha256'] == m['base_sha256']
    assert compact['library_sha256'] == m['library_sha256']
    allowed.add(compact['sha256'])
base = Path(args.base) if args.base else folder / compact['output'] if compact and (folder / compact['output']).exists() else Path(m['base_blend'])
library = Path(args.library) if args.library else folder / Path(m['library']).name
if not library.exists():
    library = Path(m['library'])
base_hash = sha(base)
assert base_hash in allowed, 'Foundation identity mismatch'
assert sha(library) == m['library_sha256'], 'Action library identity mismatch'
bpy.ops.wm.open_mainfile(filepath=str(base))
r = bpy.data.objects['SWAT_Mixamo_Rig']
names = [c['action'] for c in m['clips']]
with bpy.data.libraries.load(str(library), link=False) as (src, dst):
    assert set(src.actions) == set(names) and not src.objects and not src.meshes and not src.materials
    dst.actions = names.copy()
actions = dict(zip(names, dst.actions))
chosen = next(c for c in m['clips'] if args.clip in [c['source'], c['action']])
for a in actions.values():
    a.use_fake_user = True
    for fc in a.fcurves:
        match = re.match(r'pose\.bones\["([^\"]+)"\]', fc.data_path)
        assert match and match.group(1) in r.pose.bones
for tr in r.animation_data.nla_tracks:
    tr.mute = True
r.animation_data.action = actions[chosen['action']]
s = bpy.context.scene
s.render.fps = 30
s.render.fps_base = 1
s.frame_start = 0
s.frame_end = round(chosen['duration'] * 30)
s.frame_set(0)
if s.camera:
    target = Vector((0, -.15, .88))
    s.camera.data.type = 'ORTHO'
    s.camera.data.ortho_scale = 2.4
    s.camera.location = target + Vector((3, -4, .35))
    s.camera.rotation_euler = (target - s.camera.location).to_track_quat('-Z', 'Y').to_euler()
print('APPEND_VERIFIED', len(actions), 'actions; active', chosen['action'], 'duration', chosen['duration'], 'seconds', flush=True)
if args.output:
    out = Path(args.output).resolve()
    assert not out.exists(), 'Refusing to overwrite an existing file'
    assert out not in [base.resolve(), library.resolve()]
    bpy.context.preferences.filepaths.save_version = 0
    bpy.ops.wm.save_as_mainfile(filepath=str(out), compress=True)
assert sha(base) == base_hash and sha(library) == m['library_sha256']
