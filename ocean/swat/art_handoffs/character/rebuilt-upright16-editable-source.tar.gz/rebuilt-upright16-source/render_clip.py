import bpy,json,sys,math,hashlib,os
from pathlib import Path
from mathutils import Vector
O=Path('/workspace/scratch/eac4961518d4/animation_rebuild/upright_locomotion');args=sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else [];tag=args[0] if args else 'run_forward';mode=args[1] if len(args)>1 else 'keys';m=json.load(open(O/(tag+'_manifest.json')));assert hashlib.file_digest(open(m['base_blend'],'rb'),'sha256').hexdigest()==m['base_sha256'];assert hashlib.file_digest(open(m['library'],'rb'),'sha256').hexdigest()==m['library_sha256'];bpy.ops.wm.open_mainfile(filepath=m['base_blend']);s=bpy.context.scene;r=bpy.data.objects['SWAT_Mixamo_Rig']
with bpy.data.libraries.load(m['library'],link=False) as (src,dst):dst.actions=[c['action'] for c in m['clips']]
for tr in r.animation_data.nla_tracks:tr.mute=True
s.render.fps=30;s.render.fps_base=1;s.render.engine='BLENDER_WORKBENCH';s.render.resolution_x=360;s.render.resolution_y=480;s.render.resolution_percentage=100;s.render.image_settings.file_format='PNG';s.world.color=(.055,.065,.085);sh=s.display.shading;sh.light='STUDIO';sh.color_type='MATERIAL';sh.show_shadows=True;sh.show_cavity=True;sh.cavity_type='BOTH';sh.show_object_outline=True;sh.background_type='WORLD';s.view_settings.view_transform='Standard';s.render.film_transparent=False
bpy.ops.mesh.primitive_plane_add(size=8,location=(0,0,0));floor=bpy.context.object;floor.name='Rebuild diagnostic ground';floor.color=(.12,.13,.15,1)
c=s.camera;c.data.type='ORTHO';c.data.ortho_scale=2.4;target=Vector((0,-.23,.9));out=O/(tag+'_'+mode);out.mkdir(exist_ok=True)
for clip,a in zip(m['clips'],dst.actions):
 r.animation_data.action=a;D=clip['duration'];times=[i/60 for i in range(round(D*60))] if mode=='video' else [D*x for x in [0,.25,.5,.75,1]]
 for view,off in [('front',(0,-4,.1)),('right',(4,0,.1))]:
  c.location=target+Vector(off);c.rotation_euler=(target-c.location).to_track_quat('-Z','Y').to_euler();folder=out/(clip['source'].replace(' ','_')+'_'+view);folder.mkdir(exist_ok=True)
  for i,t in enumerate(times):
   f=t*30;s.frame_set(math.floor(f),subframe=f%1);s.render.filepath=str(folder/('%04d.png'%i));bpy.ops.render.render(write_still=True)
print('RENDER_COMPLETE',str(out),flush=True)
