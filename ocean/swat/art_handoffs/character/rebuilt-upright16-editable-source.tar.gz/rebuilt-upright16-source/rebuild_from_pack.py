"""Portable copy of build_upright_reconstructed.py; only path/CLI/dependency plumbing differs."""
import bpy,json,math,os,sys,hashlib,time
from mathutils import Matrix,Vector,Quaternion
from pathlib import Path
import argparse
R=str(Path(__file__).resolve().parent)
parser=argparse.ArgumentParser(description='Rebuild native-source upright locomotion into a new directory')
parser.add_argument('--output-dir',required=True)
parser.add_argument('--clip',action='append',default=[])
args=parser.parse_args(sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else [])
O=str(Path(args.output_dir).resolve())
assert not Path(O).exists(), 'Output directory must not already exist'
Path(O).mkdir(parents=True)
compact=json.load(open(R+'/compact_geometry_manifest.json'))
BASE=R+'/'+compact['output'];P='mixamorig:';RATE=240
sources=json.load(open(R+'/source_registry.json'));upright=json.load(open(R+'/clip_registry.json'));wanted=args.clip or ['all'];allclips=[c for c in upright if c['family']!='crouch'];clips=allclips if wanted==['all'] else [c for c in allclips if c['source'] in wanted];tag='all16' if wanted==['all'] else '_'.join(x.replace(' ','_') for x in wanted);assert len(clips)==(16 if wanted==['all'] else len(wanted))
foundation=compact;assert hashlib.sha256(open(BASE,'rb').read()).hexdigest()==foundation['sha256']
for source in sources:source['local_path']=str(Path(R)/'native_sources'/(source['name']+'.fbx'))
bpy.ops.wm.open_mainfile(filepath=BASE);s=bpy.context.scene;r=bpy.data.objects['SWAT_Mixamo_Rig'];body=bpy.data.objects['Rebuilt SWAT full body'];
for tr in r.animation_data.nla_tracks:tr.mute=True
r.animation_data.action=bpy.data.actions['Rebuild Carry Reference / Stock Cleared FPS Idle'];s.frame_set(0)
# Recovered FPS prop bones are roots: explicitly bake their rigid hand relationship.
prop_relative={n:r.pose.bones[P+'RightHand'].matrix.inverted()@r.pose.bones[n].matrix for n in ['Prop_Rifle','Prop_Magazine_A']}
assert not any(b.constraints for b in r.pose.bones)
LOWER=[P+'Hips']+[P+side+part for side in ['Left','Right'] for part in ['UpLeg','Leg','Foot','ToeBase','Toe_End']];NATIVE=LOWER+[P+'Spine',P+'Spine1'];EDITUP=[P+n for n in ['Spine2','Neck','Head']]
footverts={}
for side in ['Left','Right']:
 groups={v.index for v in body.vertex_groups if any(v.name.startswith(P+side+part) for part in ['Foot','ToeBase','Toe_End'])};footverts[side]=[v.index for v in body.data.vertices if sum(g.weight for g in v.groups if g.group in groups)>.65]
def setf(f):s.frame_set(math.floor(f),subframe=f%1)
def foot_mins():
 ev=body.evaluated_get(bpy.context.evaluated_depsgraph_get());mesh=ev.to_mesh();v={side:min(mesh.vertices[i].co.z for i in ids) for side,ids in footverts.items()};ev.to_mesh_clear();return v
def lift_boot(side,amount):
 a=r.pose.bones[P+side+'UpLeg'];f=r.pose.bones[P+side+'Leg'];h=r.pose.bones[P+side+'Foot'];S=a.head.copy();E=f.head.copy();W=h.head.copy();H=h.matrix.copy();H.translation.z+=amount;T=H.translation.copy();qa=a.matrix.to_quaternion();qf=f.matrix.to_quaternion();v=T-S;d=v.length;u=v.normalized();l1=(E-S).length;l2=(W-E).length
 if d>=l1+l2-.00001:raise Exception('Grounding reach failure '+side)
 pole=E-S;pole=(pole-u*pole.dot(u)).normalized();along=(l1*l1-l2*l2+d*d)/(2*d);newE=S+u*along+pole*math.sqrt(max(0,l1*l1-along*along));A=((E-S).rotation_difference(newE-S)@qa).to_matrix().to_4x4();A.translation=S;a.matrix=A;bpy.context.view_layer.update();F=((W-E).rotation_difference(T-newE)@qf).to_matrix().to_4x4();F.translation=newE;f.matrix=F;bpy.context.view_layer.update();h.matrix=H;bpy.context.view_layer.update()
def knee_info(side):
 a=r.pose.bones[P+side+'UpLeg'];f=r.pose.bones[P+side+'Leg'];h=r.pose.bones[P+side+'Foot'];axis=(h.head-a.head).normalized();v=f.head-a.head;return axis,(v-axis*v.dot(axis)).normalized()
def key_values(action,samples):
 for n in samples[0][1]:
  for field,ix,dim in [('location',0,3),('rotation_quaternion',1,4),('scale',2,3)]:
   rows=[];prev=None
   for f,bones in samples:
    v=list(bones[n][ix])
    if field=='rotation_quaternion' and prev and sum(a*b for a,b in zip(prev,v))<0:v=[-x for x in v]
    prev=v;rows.append((f,v))
   path='pose.bones["'+n+'"].'+field
   for j in range(dim):
    fc=action.fcurves.find(path,index=j)
    if fc:action.fcurves.remove(fc)
    fc=action.fcurves.new(path,index=j,action_group=n);fc.keyframe_points.add(len(rows));fc.keyframe_points.foreach_set('co',[x for f,v in rows for x in (f,v[j])]);
    for k in fc.keyframe_points:k.interpolation='LINEAR'
def anatomy(left,right,chestq):
 x=(left-right).normalized();z=chestq@Vector((0,1,0));z=(z-x*z.dot(x)).normalized();return Matrix((x,z.cross(x).normalized(),z)).transposed()
def qangle(q,p):
 dot=abs(sum(float(a)*float(b) for a,b in zip(q,p)))/math.sqrt(sum(float(a)*float(a) for a in q)*sum(float(b)*float(b) for b in p));return math.degrees(2*math.acos(min(1,dot)))
def curvehash(a):
 return {(f.data_path,f.array_index):hashlib.sha256(repr([(tuple(k.co),k.interpolation,tuple(k.handle_left),tuple(k.handle_right)) for k in f.keyframe_points]).encode()).hexdigest() for f in a.fcurves}
reports=[];created=[]
for ci,c in enumerate(clips):
 t0=time.time();srcinfo=next(x for x in sources if x['name']==c['source']);assert hashlib.sha256(open(srcinfo['local_path'],'rb').read()).hexdigest()==srcinfo['sha256'];baseline=bpy.data.actions[c['action']];original_hashes=curvehash(baseline);before=set(bpy.data.objects);bpy.ops.import_scene.fbx(filepath=srcinfo['local_path']);added=set(bpy.data.objects)-before;sr=next(o for o in added if o.type=='ARMATURE');sa=sr.animation_data.action;lo,hi=sa.frame_range;fps=s.render.fps;dur=(hi-lo)/fps;setf(lo);p0=(sr.matrix_world@sr.pose.bones[P+'Hips'].matrix).translation.copy();setf(hi);p1=(sr.matrix_world@sr.pose.bones[P+'Hips'].matrix).translation.copy();delta=p1-p0
 # Native60 rest/axis mapping uses the exact per-clip source, never a forward-pose substitution.
 native=[];source_ref=[];rest_err=max(max(abs((sr.matrix_world@sr.data.bones[n].matrix_local).to_quaternion().to_matrix()[i][j]-r.data.bones[n].matrix_local.to_quaternion().to_matrix()[i][j]) for i in range(3) for j in range(3)) for n in NATIVE)
 for i in range(round(dur*RATE)+1):
  t=i/RATE;setf(lo+t*fps);world={n:sr.matrix_world@sr.pose.bones[n].matrix for n in NATIVE+EDITUP+[P+'LeftArm',P+'RightArm']};source_ref.append({'chest':world[P+'Spine2'].to_quaternion(),'left':world[P+'LeftArm'].translation,'right':world[P+'RightArm'].translation,'neck':world[P+'Neck'].to_quaternion(),'head':world[P+'Head'].to_quaternion(),'feet':{side:world[P+side+'Foot'].to_quaternion() for side in ['Left','Right']},'hip':world[P+'Hips'].to_quaternion()})
  if i%(RATE//fps):continue
  offset=Vector((p0.x,p0.y,0))+Vector((delta.x,delta.y,0))*(t/dur);W={n:Matrix.LocRotScale(world[n].translation-offset,world[n].to_quaternion(),Vector((1,1,1))) for n in NATIVE};bdata={}
  for n in NATIVE:
   b=r.data.bones[n];kwargs={}
   if b.parent and b.parent.name in W:kwargs={'parent_matrix':W[b.parent.name],'parent_matrix_local':b.parent.matrix_local}
   bdata[n]=b.convert_local_to_pose(W[n],b.matrix_local,invert=True,**kwargs).decompose()
  native.append((t*30,bdata))
 for ob in added:bpy.data.objects.remove(ob,do_unlink=True)
 a=baseline.copy();a.name='Rebuilt Upright Native Frame / '+c['source'];a.use_fake_user=True
 # Static seed ends at30; shorten unchanged carry keys to each actual clip duration.
 for fc in a.fcurves:
  for k in fc.keyframe_points:
   for coord in [k.co,k.handle_left,k.handle_right]:coord.x*=dur
 original_hashes=curvehash(a) # Compare channels against the duration-normalized static seed.
 key_values(a,native);r.animation_data.action=a
 # Upperbody anatomical frame; original healthy rigid carry local transforms remain intact.
 upper=[];source_shoulder=[];actual_shoulder=[];gaze_errors=[]
 for i,ref in enumerate(source_ref):
  f=i/RATE*30;setf(f);ch=r.pose.bones[P+'Spine2'];cur=anatomy(r.pose.bones[P+'LeftArm'].head,r.pose.bones[P+'RightArm'].head,ch.matrix.to_quaternion());target=anatomy(ref['left'],ref['right'],ref['chest']);M=((target@cur.transposed()).to_quaternion()@ch.matrix.to_quaternion()).to_matrix().to_4x4();M.translation=ch.head.copy();ch.matrix=M;bpy.context.view_layer.update()
  for n,key in [('Neck','neck'),('Head','head')]:
   b=r.pose.bones[P+n];M=ref[key].to_matrix().to_4x4();M.translation=b.head.copy();b.matrix=M;bpy.context.view_layer.update()
  upper.append((f,{n:r.pose.bones[n].matrix_basis.decompose() for n in EDITUP}));x=r.pose.bones[P+'LeftArm'].head-r.pose.bones[P+'RightArm'].head;xx=ref['left']-ref['right'];actual_shoulder.append(math.degrees(math.atan2(x.y,x.x)));source_shoulder.append(math.degrees(math.atan2(xx.y,xx.x)));gaze_errors.append(max(qangle(r.pose.bones[P+n].matrix.to_quaternion(),ref[k]) for n,k in [('Neck','neck'),('Head','head')]))
 key_values(a,upper)
 # Existing bounded loop overlays for the two source clips with known endpoint seams.
 end=dur*30;setf(0);first={side:knee_info(side) for side in ['Left','Right']};toe_first={side:r.pose.bones[P+side+'ToeBase'].rotation_quaternion.copy() for side in ['Left','Right']};setf(end);angles={}
 for side in first:
  axis,last=knee_info(side);fv=first[side][1];fv=(fv-axis*fv.dot(axis)).normalized();angles[side]=math.atan2(axis.dot(last.cross(fv)),last.dot(fv)) if c['source'] in ['run right','walk backward left'] else 0
 toes={side:toe_first[side]@r.pose.bones[P+side+'ToeBase'].rotation_quaternion.inverted() for side in ['Left','Right']};samples=[];lifts=[];mins=[]
 for i in range(round(dur*RATE)+1):
  f=i/RATE*30;setf(f);u=(f/end);u=u*u*(3-2*u)
  if c['source'] in ['run right','walk backward left']:
   for side in ['Left','Right']:
    aa=r.pose.bones[P+side+'UpLeg'];ff=r.pose.bones[P+side+'Leg'];hh=r.pose.bones[P+side+'Foot'];S=aa.head.copy();E=ff.head.copy();H=hh.matrix.copy();W=hh.head.copy();axis=(W-S).normalized();qa=aa.matrix.to_quaternion();qf=ff.matrix.to_quaternion();newE=S+Quaternion(axis,angles[side]*u)@(E-S);M=((E-S).rotation_difference(newE-S)@qa).to_matrix().to_4x4();M.translation=S;aa.matrix=M;bpy.context.view_layer.update();M=((W-E).rotation_difference(W-newE)@qf).to_matrix().to_4x4();M.translation=newE;ff.matrix=M;bpy.context.view_layer.update();hh.matrix=H;bpy.context.view_layer.update()
  if c['source']=='walk backward left':
   for side in ['Left','Right']:r.pose.bones[P+side+'ToeBase'].rotation_quaternion=Quaternion((1,0,0,0)).slerp(toes[side],u)@r.pose.bones[P+side+'ToeBase'].rotation_quaternion
   bpy.context.view_layer.update()
  total=0
  for repeat in range(3):
   for side,low in foot_mins().items():
    lift=max(0,.004-low)
    if lift>.00002:lift_boot(side,lift);total=max(total,lift)
  samples.append((f,{n:r.pose.bones[n].matrix_basis.decompose() for n in LOWER if n!=P+'Hips'}));lifts.append(total);mins.append(min(foot_mins().values()))
 roll={}
 if c['source'] in ['run right','walk backward left']:
  endpoints=[]
  for f,bones in [samples[0],samples[-1]]:
   setf(f)
   for n,(l,q,sc) in bones.items():r.pose.bones[n].matrix_basis=Matrix.LocRotScale(l,q,sc)
   bpy.context.view_layer.update();endpoints.append({P+side+part:r.pose.bones[P+side+part].matrix.to_quaternion().copy() for side in ['Left','Right'] for part in ['UpLeg','Leg']})
  for n,q in endpoints[0].items():roll[n]=(endpoints[1][n].inverted()@q).to_swing_twist('Y')[1]
  revised=[]
  for f,bones in samples:
   setf(f)
   for n,(l,q,sc) in bones.items():r.pose.bones[n].matrix_basis=Matrix.LocRotScale(l,q,sc)
   bpy.context.view_layer.update();u=f/end;u=u*u*(3-2*u)
   for side in ['Left','Right']:
    for part,child in [('UpLeg','Leg'),('Leg','Foot')]:
     bb=r.pose.bones[P+side+part];hh=r.pose.bones[P+side+child];H=hh.matrix.copy();bb.matrix=bb.matrix@Quaternion((0,1,0),roll[bb.name]*u).to_matrix().to_4x4();bpy.context.view_layer.update();hh.matrix=H;bpy.context.view_layer.update()
   for rep in range(2):
    for side,low in foot_mins().items():
     if low<.00398:lift_boot(side,.004-low)
   revised.append((f,{n:r.pose.bones[n].matrix_basis.decompose() for n in LOWER if n!=P+'Hips'}))
  samples=revised
 key_values(a,samples);r.animation_data.action=a
 prop_samples=[]
 for i in range(round(dur*RATE)+1):
  f=i/RATE*30;setf(f);H=r.pose.bones[P+'RightHand'].matrix.copy();values={}
  for n,rel in prop_relative.items():
   b=r.data.bones[n];assert b.parent is None;values[n]=b.convert_local_to_pose(H@rel,b.matrix_local,invert=True).decompose()
  prop_samples.append((f,values))
 key_values(a,prop_samples);r.animation_data.action=a
 assert abs(a.frame_range.x)<1e-6 and abs(a.frame_range.y-dur*30)<1e-5
 # Dense subframe checks, with actual skinned soles. No claimed fixed-world planting in in-place clips.
 densemin=99.;footerr=0.;hiperr=0.;gazeerr=0.;firstlast=[]
 for i in range(round(dur*RATE*2)+1):
  f=i/(RATE*2)*30;setf(f);densemin=min(densemin,min(foot_mins().values()))
  if i%2==0:
   ref=source_ref[i//2];footerr=max(footerr,*[qangle(r.pose.bones[P+side+'Foot'].matrix.to_quaternion(),ref['feet'][side]) for side in ['Left','Right']]);hiperr=max(hiperr,qangle(r.pose.bones[P+'Hips'].matrix.to_quaternion(),ref['hip']));gazeerr=max(gazeerr,*[qangle(r.pose.bones[P+n].matrix.to_quaternion(),ref[k]) for n,k in [('Neck','neck'),('Head','head')]])
  if i in [0,round(dur*RATE*2)]:firstlast.append({n:r.pose.bones[n].matrix.copy() for n in NATIVE+EDITUP})
 loop=max(abs(firstlast[0][n][i][j]-firstlast[1][n][i][j]) for n in firstlast[0] for i in range(4) for j in range(4));now=curvehash(a);changes=[k for k in set(now)|set(original_hashes) if now.get(k)!=original_hashes.get(k)];unexpected=[k for k in changes if not any('"'+n+'"' in k[0] for n in NATIVE+EDITUP+list(prop_relative))]
 rec={'source':c['source'],'source_path':srcinfo['local_path'],'source_sha256':hashlib.sha256(open(srcinfo['local_path'],'rb').read()).hexdigest(),'source_fps':fps,'source_frames':[lo,hi],'duration':dur,'native_key_spacing_target_frames':30/fps,'action':a.name,'baseline_action':c['action'],'grounding_hz':RATE,'dense_check_hz':RATE*2,'root_vector_removed_m':list(delta),'nominal_speed_m_s':math.hypot(delta.x,delta.y)/dur,'rest_world_rotation_element_max_difference':rest_err,'ground_policy':'Same native-plane knee IK and4mm sole target; solve density240Hz instead of prior120Hz; no XY foot pin or deliberate source style change','source_shoulder_yaw_range_deg':max(source_shoulder)-min(source_shoulder),'candidate_shoulder_yaw_range_deg':max(actual_shoulder)-min(actual_shoulder),'source_shoulder_yaw_max_error_deg':max(abs(a-b) for a,b in zip(source_shoulder,actual_shoulder)),'gaze_world_max_error_deg':gazeerr,'hips_source_world_max_error_deg':hiperr,'feet_source_world_max_error_deg':footerr,'minimum_dense_sole_z_m':densemin,'minimum_solver_sole_z_m':min(mins),'maximum_single_pass_boot_lift_m':max(lifts),'knee_pole_loop_overlay_deg':{k:math.degrees(v) for k,v in angles.items()},'axial_loop_overlay_deg':{k:math.degrees(v) for k,v in roll.items()},'endpoint_matrix_max_difference':loop,'unexpected_channel_changes':unexpected,'changed_curve_count':len(changes),'status':'candidate_pending_visual_and_library_parity_gate','elapsed_s':time.time()-t0};reports.append(rec);created.append(a);print('CLIP_DONE',json.dumps(rec),flush=True)
 # Save just authored action datablocks. Body/rig/gear remain in the immutable dependency.
 path=O+'/'+tag+'_actions.blend';bpy.data.libraries.write(path,set(created),fake_user=True,compress=True)
 # Exact library serialization check against authored in-memory actions, including subframes.
 with bpy.data.libraries.load(path,link=False) as (libsrc,libdst):libdst.actions=[x.name for x in created]
 parity=[]
 for orig,loaded,rr in zip(created,libdst.actions,reports):
  sig_equal=curvehash(orig)==curvehash(loaded);maxdiff=0.;ref=[];ts=[i/120 for i in range(round(rr['duration']*120)+1)]
  for ac in [orig,loaded]:
   r.animation_data.action=ac
   for ix,t in enumerate(ts):
    setf(t*30);pose={b.name:b.matrix.copy() for b in r.pose.bones}
    if ac==orig:ref.append(pose)
    else:maxdiff=max(maxdiff,max(abs(pose[n][i][j]-ref[ix][n][i][j]) for n in pose for i in range(4) for j in range(4)))
  rr['action_library_parity']={'curve_signatures_equal':sig_equal,'samples':len(ts),'all_bone_matrix_max_difference':maxdiff};assert sig_equal and maxdiff==0
  bpy.data.actions.remove(loaded)
 json.dump({'base_blend':BASE,'base_sha256':hashlib.sha256(open(BASE,'rb').read()).hexdigest(),'library':path,'library_sha256':hashlib.sha256(open(path,'rb').read()).hexdigest(),'fps':30,'clips':reports,'scope':'NEW reconstruction from surviving FBXs and exact-rest-compatible recovered FPS carry; not recovered prior bank bytes; only upright locomotion; requires separately rebuilt foundation','prop_relative_matrices':{n:[list(x) for x in M] for n,M in prop_relative.items()},'carry_reference':'Older recovered FPS Idle plus coupled stock clearance; rebuilt/new, not prior latest parity','new_reconstruction':True,'carry_intent':'Free low-ready off-shoulder locomotion only; not ADS, seated Ready or reloads','carry_correction_manifest':R+'/foundation_stockcleared_manifest.json'},open(O+'/'+tag+'_manifest.json','w'),indent=2)
print('DONE',path,os.path.getsize(path),flush=True)
