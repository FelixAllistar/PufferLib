"""Static labels and exact-speed cycles; no rendering or animation changes."""
from pathlib import Path
import json,subprocess,hashlib
from PIL import Image,ImageDraw,ImageFont
O=Path(__file__).resolve().parent;m=json.load(open(O/'all16_manifest.json'));font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',25);small=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',21);tiny=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',17);sha=lambda p:hashlib.file_digest(open(p,'rb'),'sha256').hexdigest();outputs=[]
for family in ['walk','run']:
 meta=json.load(open(O/(family+'_grid_metadata.json')));assert meta['library_sha256']==m['library_sha256'];assert meta['rendered_frames']==meta['frames'];assert meta['all_conservative_bounds_in_view'];N=meta['frames'];assert len(list((O/(family+'_grid_frames')).glob('*.png')))==N
 label=Image.new('RGBA',(1280,848),(0,0,0,0));d=ImageDraw.Draw(label);d.rectangle((0,0,1279,47),fill=(24,29,37,255));d.text((16,8),'Rebuilt upright '+family+' | 1x speed | free low-ready',font=font,fill=(240,240,240,255))
 for i,name in enumerate(meta['clips']):
  title=name.split(' ',1)[1].title();col=i%4;row=i//4;box=d.textbbox((0,0),title,font=small);x=col*320+(320-(box[2]-box[0]))/2;y=61 if row==0 else 431;d.rectangle((col*320+10,y-3,col*320+309,y+28),fill=(25,30,38,255));d.text((x,y),title,font=small,fill=(236,226,203,255))
 d.rectangle((0,813,1279,847),fill=(24,29,37,255));d.text((16,821),'New reconstruction | Original directional source motion | Off-shoulder carry, not aimed or seated',font=tiny,fill=(209,215,224,255));lp=O/(family+'_labels.png');label.save(lp);out=O/('rebuilt-'+family+'8-overview.mp4');loops=round(4/meta['native_cycle_duration'])-1
 cmd=['ffmpeg','-y','-framerate','60','-i',str(O/(family+'_grid_frames/%04d.png')),'-loop','1','-i',str(lp),'-filter_complex',f'[0:v]loop=loop={loops}:size={N}:start=0,setpts=N/(60*TB),pad=1280:848:0:48:color=0x181d25[base];[base][1:v]overlay=0:0:shortest=1[out]','-map','[out]','-an','-c:v','libx264','-preset','fast','-crf','22','-pix_fmt','yuv420p','-r','60','-frames:v','240','-bf','0','-g','60',str(out)]
 with open(O/('encode_'+family+'_overview.log'),'w') as f:subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,check=True)
 outputs.append(out)
concat=O/'overview_concat.txt';concat.write_text(''.join("file '"+str(p)+"'\n" for p in outputs));out=O/'rebuilt-upright-walk-run-16.mp4'
with open(O/'encode_combined_overview.log','w') as f:subprocess.run(['ffmpeg','-y','-f','concat','-safe','0','-i',str(concat),'-c','copy','-movflags','+faststart',str(out)],stdout=f,stderr=subprocess.STDOUT,check=True)
probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-select_streams','v:0','-show_entries','stream=width,height,r_frame_rate,nb_frames,duration','-of','json',str(out)]));p=probe['streams'][0];assert p['width']==1280 and p['height']==848 and p['r_frame_rate']=='60/1' and p['nb_frames']=='480' and abs(float(p['duration'])-8)<1e-6
subprocess.run(['ffmpeg','-v','error','-i',str(out),'-f','null','-'],check=True)
meta={'output':str(out),'sha256':sha(out),'bytes':out.stat().st_size,'video':p,'action_library_sha256':m['library_sha256'],'source_overviews':[{'path':str(p),'sha256':sha(p)} for p in outputs],'timing':'Walk8 directions0–4s, run8 directions4–8s. True1x native time; loops repeated, no retiming.','carry':'Validated free low-ready, explicitly off-shoulder; not ADS/seated/Ready/reload carry','full_decode_passed':True,'new_reconstruction':True};json.dump(meta,open(O/'overview_delivery_metadata.json','w'),indent=2);print(json.dumps(meta),flush=True)
