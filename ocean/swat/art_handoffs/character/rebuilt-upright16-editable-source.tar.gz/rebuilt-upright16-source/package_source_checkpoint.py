"""Package verified source dependencies, actions and reproducible scripts without texture images."""
from pathlib import Path
import gzip
import hashlib
import json
import shutil
import tarfile

O = Path(__file__).resolve().parent
STAGE = Path('/tmp/upright16-final-package')
OUT = O / 'rebuilt-upright16-editable-source.tar.gz'
sha = lambda p: hashlib.file_digest(open(p, 'rb'), 'sha256').hexdigest()
assert not STAGE.exists() and not OUT.exists()
gate = json.load(open(O / 'independent_export/package_gate.json'))
assert gate.get('status') == 'PASS', 'Package gate must pass before packaging'
STAGE.mkdir()
root_files = [
    'upright16_editable_untextured.blend', 'upright16_editable_geometry_base.blend',
    'all16_actions.blend', 'stock_cleared_carry.actions.blend',
    'rebuilt-upright-walk-run-16.mp4', 'SOURCE_CHECKPOINT_README.md',
    'append_rebuilt_actions.py', 'rebuild_from_pack.py', 'build_upright_reconstructed.py',
    'build_foundation.py', 'correct_carry_stock.py', 'build_compact_geometry.py',
    'export_rebuilt_glb.py', 'render_clip.py', 'render_grid.py', 'encode_overview.py',
    'inspect_native_sources.py', 'probe_base_compatibility.py', 'package_source_checkpoint.py',
    'all16_manifest.json', 'compact_geometry_manifest.json', 'source_registry.json',
    'clip_registry.json', 'foundation_manifest.json', 'foundation_stockcleared_manifest.json',
    'base_compatibility.json', 'native_source_inventory.json', 'glb_export_manifest.json',
    'overview_delivery_metadata.json', 'walk_grid_metadata.json', 'run_grid_metadata.json',
]
for name in root_files:
    shutil.copy2(O / name, STAGE / name)
for folder in ['historical_recipe', 'independent_batch', 'independent_export', 'independent_stage_stockcleared']:
    dest = STAGE / folder
    dest.mkdir()
    for f in (O / folder).iterdir():
        if f.suffix in ['.json', '.py', '.md', '.txt'] and f.stat().st_size < 2_000_000:
            shutil.copy2(f, dest / f.name)
(STAGE / 'native_sources').mkdir()
source_rows = []
for row in json.load(open(O / 'source_registry.json')):
    dest = STAGE / 'native_sources' / (row['name'] + '.fbx')
    shutil.copy2(row['local_path'], dest)
    assert sha(dest) == row['sha256']
    source_rows.append({**row, 'packaged_path': dest.relative_to(STAGE).as_posix(), 'bytes': dest.stat().st_size})
preview = json.load(open(O / 'overview_delivery_metadata.json'))
glb = json.load(open(O / 'glb_export_manifest.json'))
files = [{'path': f.relative_to(STAGE).as_posix(), 'bytes': f.stat().st_size, 'sha256': sha(f)} for f in sorted(STAGE.rglob('*')) if f.is_file()]
manifest = {
    'status': 'PASS',
    'scope': 'New rebuilt upright walk/run16, free off-shoulder low-ready only',
    'new_reconstruction_not_prior_bank_bytes': True,
    'direct_open': 'upright16_editable_untextured.blend',
    'load_action_bank': 'append_rebuilt_actions.py',
    'rebuild_native_motion': 'rebuild_from_pack.py',
    'self_contained_for': ['Opening and editing included Blender actions', 'Reconstructing16 upright motions from original native FBXs and exact compatible corrected carry seed'],
    'excluded_payload': 'Texture images; available in separate verified GLB and original full foundation',
    'sources': source_rows,
    'textured_glb_external': {k: glb[k] for k in ['output', 'sha256', 'bytes', 'status']},
    'preview_library_delivery': preview['library_delivery'],
    'authoring_base': {'path': glb['base'], 'sha256': glb['base_sha256']},
    'limits': ['No engine, controller or runtime blend verification', 'No ADS, seated Ready, reload, crouch or prone work', 'Ordered-frame review; no live playback observation claim'],
    'package_validation': 'independent_export/package_gate.json',
    'files': files,
    'manifest_self_excluded_from_file_hash_list': True,
}
(STAGE / 'SOURCEPACK_MANIFEST.json').write_text(json.dumps(manifest, indent=2) + '\n')
with open(OUT, 'wb') as raw:
    with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0, compresslevel=9) as gz:
        with tarfile.open(fileobj=gz, mode='w') as tar:
            for f in sorted(STAGE.rglob('*')):
                if not f.is_file():
                    continue
                info = tar.gettarinfo(str(f), arcname='rebuilt-upright16-source/' + f.relative_to(STAGE).as_posix())
                info.uid = info.gid = 0
                info.uname = info.gname = ''
                info.mtime = 0
                with open(f, 'rb') as content:
                    tar.addfile(info, content)
assert OUT.stat().st_size < 20_000_000
# Read every archived payload and compare its content hash, without trusting a listing alone.
with tarfile.open(OUT, 'r:gz') as tar:
    expected = {f['path']: f for f in files}
    expected['SOURCEPACK_MANIFEST.json'] = {'sha256': sha(STAGE / 'SOURCEPACK_MANIFEST.json'), 'bytes': (STAGE / 'SOURCEPACK_MANIFEST.json').stat().st_size}
    assert len(tar.getmembers()) == len(expected)
    for member in tar:
        relative = member.name.removeprefix('rebuilt-upright16-source/')
        assert relative in expected and member.isfile()
        data = tar.extractfile(member).read()
        assert len(data) == expected[relative]['bytes']
        assert hashlib.sha256(data).hexdigest() == expected[relative]['sha256']
sidecar = {'status': 'PASS', 'path': str(OUT), 'sha256': sha(OUT), 'bytes': OUT.stat().st_size, 'file_count': len(expected), 'uncompressed_bytes': sum(v['bytes'] for v in expected.values()), 'archive_all_payload_hashes_verified': True, 'package_manifest_sha256': sha(STAGE / 'SOURCEPACK_MANIFEST.json'), 'package_gate': gate, 'sourcepack_manifest_local': str(O / 'SOURCEPACK_MANIFEST.json')}
shutil.copy2(STAGE / 'SOURCEPACK_MANIFEST.json', O / 'SOURCEPACK_MANIFEST.json')
(O / 'source_checkpoint_archive_manifest.json').write_text(json.dumps(sidecar, indent=2) + '\n')
print(json.dumps({k: sidecar[k] for k in ['status', 'path', 'sha256', 'bytes', 'file_count', 'uncompressed_bytes']}, indent=2))
