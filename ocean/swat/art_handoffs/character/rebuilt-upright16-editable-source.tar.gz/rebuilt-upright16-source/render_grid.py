"""Render eight native-direction clips at once; animation/data are read-only."""
import bpy,json,math,sys,hashlib,os
from pathlib import Path
from mathutils import Vector,Matrix
from bpy_extras.object_utils import world_to_camera_view
O=Path('/workspace/scratch/eac4961518d4/animation_rebuild/upright_locomotion');args=sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else [];family=args[0] if args else 'walk';m=json.load(open(O/'all16_manifest.json'));sha=lambda p:hashlib.file_digest(open(p,'rb'),'sha256').hexdigest();assert sha(m['base_blend'])==m['base_sha256'] and sha(m['library'])==m['library_sha256'];bpy.ops.wm.open_mainfile(filepath=m['base_blend']);s=bpy.context.scene;rig=bpy.data.objects['SWAT_Mixamo_Rig'];originals=[bpy.data.objects[n] for n in ['Rebuilt SWAT full body','Rifle 7','Removed magazine','Fresh magazine']];clips=[c for c in m['clips'] if c['source'].startswith(family+' ')];assert len(clips)==8
with bpy.data.libraries.load(m['library'],link=False) as (src,dst):dst.actions=[c['action'] for c in clips]
right=Vector((.832050294,.554700196,0));forward=Vector((.554700196,-.832050294,0));clones=[];visible_meshes=[]
for i,(c,a) in enumerate(zip(clips,dst.actions)):
 col=i%4;row=i//4;off=right*((col-1.5)*2.0)+Vector((0,0,2.15*(1-row)));rr=rig.copy();rr.name='Grid rig '+c['source'];s.collection.objects.link(rr);rr.matrix_world=Matrix.Translation(off);rr.animation_data.action=a
 for tr in rr.animation_data.nla_tracks:tr.mute=True
 for obj in originals:
  oo=obj.copy();oo.name='Grid '+c['source']+' '+obj.name;s.collection.objects.link(oo);oo.parent=rr;oo.parent_type='OBJECT';oo.matrix_parent_inverse=Matrix.Identity(4);oo.matrix_basis=obj.matrix_world.copy();oo.hide_render=False;oo.hide_viewport=False;oo.hide_set(False)
  if obj.name!='Fresh magazine':visible_meshes.append(oo)
  for mod in oo.modifiers:
   if mod.type=='ARMATURE':mod.object=rr
 clones.append(rr)
 verts=[off+right*x+forward*y for x,y in [(-.78,-.5),(.78,-.5),(.78,.5),(-.78,.5)]];mesh=bpy.data.meshes.new('Grid floor mesh');mesh.from_pydata(verts,[],[(0,1,2,3)]);ob=bpy.data.objects.new('Grid floor '+str(i),mesh);s.collection.objects.link(ob);ob.color=(.12,.13,.15,1)
for obj in originals+[rig]:obj.hide_render=True
s.render.fps=30;s.render.fps_base=1;s.render.engine='BLENDER_WORKBENCH';s.render.resolution_x=1280;s.render.resolution_y=800;s.render.resolution_percentage=100;s.render.image_settings.file_format='PNG';s.world.color=(.055,.065,.085);sh=s.display.shading;sh.light='STUDIO';sh.color_type='MATERIAL';sh.show_shadows=True;sh.show_cavity=True;sh.cavity_type='BOTH';sh.show_object_outline=True;sh.background_type='WORLD';s.view_settings.view_transform='Standard';s.render.film_transparent=False;cam=s.camera;cam.data.type='ORTHO';cam.data.ortho_scale=8.0;target=Vector((0,0,1.85));cam.location=target+forward*12+Vector((0,0,.5));cam.rotation_euler=(target-cam.location).to_track_quat('-Z','Y').to_euler();out=O/(family+'_grid_frames');out.mkdir(exist_ok=True);D=clips[0]['duration'];assert all(c['duration']==D for c in clips)
bounds=[1.,1.,0.,0.];rendered=1 if os.environ.get('GRID_ONE_FRAME')=='1' else round(D*60)
for i in range(rendered):
 f=i/60*30;s.frame_set(math.floor(f),subframe=f%1);dg=bpy.context.evaluated_depsgraph_get()
 for ob in visible_meshes:
  ev=ob.evaluated_get(dg)
  for corner in ev.bound_box:
   p=world_to_camera_view(s,cam,ev.matrix_world@Vector(corner));bounds=[min(bounds[0],p.x),min(bounds[1],p.y),max(bounds[2],p.x),max(bounds[3],p.y)]
 s.render.filepath=str(out/('%04d.png'%i));bpy.ops.render.render(write_still=True)
json.dump({'family':family,'fps':60,'native_cycle_duration':D,'frames':round(D*60),'rendered_frames':rendered,'conservative_projected_bounds':bounds,'all_conservative_bounds_in_view':min(bounds[0],bounds[1])>=0 and max(bounds[2],bounds[3])<=1,'clips':[c['source'] for c in clips],'library_sha256':m['library_sha256'],'source_times':[i/60 for i in range(round(D*60))]},open(O/(family+'_grid_metadata.json'),'w'),indent=2);print('GRID_DONE',family,flush=True)
