"""Make a separate image-free editable base and verify its deformation payload exactly."""
import bpy, json, hashlib, math
from pathlib import Path
import numpy as np
O=Path(__file__).resolve().parent
M=json.load(open(O/'all16_manifest.json'))
BASE=Path(M['base_blend']); OUT=O/'upright16_editable_geometry_base.blend'
CORE=['Rebuilt SWAT full body','Rifle 7','Removed magazine','Fresh magazine']
sha=lambda p:hashlib.file_digest(open(p,'rb'),'sha256').hexdigest()
assert sha(BASE)==M['base_sha256'] and sha(M['library'])==M['library_sha256']
assert not OUT.exists(), 'Refusing to overwrite the compact dependency'
def digest(x):return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def mat(x):return [list(r) for r in x]
def signature():
 r=bpy.data.objects['SWAT_Mixamo_Rig']; meshes={}
 for n in CORE:
  o=bpy.data.objects[n];m=o.data
  payload={'object_matrix':mat(o.matrix_world),'parent':o.parent.name if o.parent else None,'parent_inverse':mat(o.matrix_parent_inverse),'groups':[(g.index,g.name,g.lock_weight) for g in o.vertex_groups], 'vertices':[(list(v.co),[(g.group,g.weight) for g in v.groups]) for v in m.vertices], 'edges':[list(e.vertices) for e in m.edges], 'polygons':[(list(p.vertices),p.material_index,p.use_smooth) for p in m.polygons], 'uv':[(u.name,[list(x.uv) for x in u.data]) for u in m.uv_layers], 'corner_normals':[list(n.vector) for n in m.corner_normals], 'modifiers':[(x.name,x.type,x.object.name if x.type=='ARMATURE' and x.object else None,x.show_viewport,x.show_render, x.use_deform_preserve_volume if x.type=='ARMATURE' else None) for x in o.modifiers], 'shape_keys':bool(m.shape_keys)}
  assert not m.shape_keys
  meshes[n]={'sha256':digest(payload),'vertices':len(m.vertices),'triangles':sum(len(p.vertices)-2 for p in m.polygons),'max_weights':max(len(v.groups) for v in m.vertices),'uv_layers':[u.name for u in m.uv_layers]}
 bones=[(b.name,b.parent.name if b.parent else None,mat(b.matrix_local),list(b.head_local),list(b.tail_local),b.use_deform,b.use_connect,b.inherit_scale,b.use_inherit_rotation,b.use_local_location) for b in r.data.bones]
 poses=[(p.name,p.rotation_mode,p.bone.name,len(p.constraints)) for p in r.pose.bones]
 actions={a.name:digest([(f.data_path,f.array_index,f.extrapolation,[(list(k.co),k.interpolation,list(k.handle_left),list(k.handle_right),k.handle_left_type,k.handle_right_type) for k in f.keyframe_points]) for f in a.fcurves]) for a in bpy.data.actions}
 return {'meshes':meshes,'rig_sha256':digest([mat(r.matrix_world),bones,poses]),'bone_count':len(bones),'action_curves':actions}
def pose_hashes():
 r=bpy.data.objects['SWAT_Mixamo_Rig'];s=bpy.context.scene
 with bpy.data.libraries.load(M['library'],link=False) as (src,dst):dst.actions=[c['action'] for c in M['clips']]
 out={}
 for a,c in zip(dst.actions,M['clips']):
  r.animation_data.action=a
  for t in [0,c['duration']/2,c['duration']]:
   f=t*30;s.frame_set(math.floor(f),subframe=f%1);h=hashlib.sha256()
   for n in CORE:
    ob=bpy.data.objects[n].evaluated_get(bpy.context.evaluated_depsgraph_get());mesh=ob.to_mesh();vs=np.empty(len(mesh.vertices)*3,dtype=np.float32);mesh.vertices.foreach_get('co',vs);h.update(vs.tobytes());h.update(np.array(ob.matrix_world,dtype=np.float32).tobytes());ob.to_mesh_clear()
   out[c['source']+' @ '+str(t)]=h.hexdigest()
 r.animation_data.action=bpy.data.actions['Rebuild Carry Reference / Stock Cleared FPS Idle']
 for a in dst.actions:bpy.data.actions.remove(a)
 s.frame_set(0)
 return out
bpy.ops.wm.open_mainfile(filepath=str(BASE));before=signature();poses_before=pose_hashes()
image_count=len(bpy.data.images)
# Remove only image data and image texture nodes. Geometry, UVs, skin, skeleton and carry are unchanged.
for ma in bpy.data.materials:
 if ma.use_nodes:
  for n in list(ma.node_tree.nodes):
   if n.type=='TEX_IMAGE':ma.node_tree.nodes.remove(n)
for im in list(bpy.data.images):bpy.data.images.remove(im,do_unlink=True)
bpy.context.scene['checkpoint_intent']='Untextured exact-geometry editable base for rebuilt16 FREE off-shoulder low-ready locomotion. Use standalone GLB for packed textures.'
bpy.context.preferences.filepaths.save_version=0
bpy.ops.wm.save_as_mainfile(filepath=str(OUT),compress=True)
bpy.ops.wm.open_mainfile(filepath=str(OUT));after=signature();poses_after=pose_hashes()
assert before==after, 'Compact geometry/rest/weights/carry identity mismatch'
assert poses_before==poses_after, 'Compact deformation mismatch'
assert len(bpy.data.images)==0
assert sha(BASE)==M['base_sha256'] and sha(M['library'])==M['library_sha256']
report={'status':'PASS','intent':'Untextured editable geometry; newly saved derivative, exact geometry/rest/skin/carry payload and sampled deformation identity, not byte-identical full foundation','output':OUT.name,'sha256':sha(OUT),'bytes':OUT.stat().st_size,'source_base':str(BASE),'source_base_sha256':M['base_sha256'],'removed_image_count':image_count,'remaining_images':len(bpy.data.images),'semantic_signature':after,'sampled_deformation_frames':len(poses_after),'sampled_deformation_equal':True,'sampling':'All16 clips at start, midpoint, endpoint with original verified action library; all4 core mesh evaluated positions exact float32 hash equality','library_sha256':M['library_sha256']}
json.dump(report,open(O/'compact_geometry_manifest.json','w'),indent=2)
print('COMPACT_VERIFIED',OUT.stat().st_size,report['sha256'],flush=True)
